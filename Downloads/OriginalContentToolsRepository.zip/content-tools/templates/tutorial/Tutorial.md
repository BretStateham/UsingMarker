<a name="title" />
# (TODO: Insert a descriptive title here) #

---

<a name="Overview" />
## Overview ##

(TODO: Include an overview text here. For example:)  
In this tutorial you will open Notepad.

<a id="goals" />
### Goals ###
In this tutorial you will see three things:

1. (TODO: Insert objective 1 here)

1. (TODO: Insert objective 2 here)

1. (TODO: Insert objective 3 here)

<a name="technologies" />
### Key Technologies ###

- [TODO: Insert technology 1 here][1]
- [TODO: Insert technology 2 here][2]
- [TODO: Insert technology 3 here][3]

[1]: http://insert_link_to_technology_1_here/
[2]: http://insert_link_to_technology_2_here/
[3]: http://insert_link_to_technology_3_here/

<a name="setup" />
### Setup and Configuration ###

(TODO: Insert setup steps here)

---

<a name="Tutorial" />
## Tutorial ##

This tutorial is composed of the following segments:

1. [TODO: Insert segment1 title here](#segment1).
1. [TODO: Insert segment2 title here](#segment2).

<a name="segment1" />
### TODO: Insert segment1 title here ###

(TODO: Insert a tutorial segment text here. For example:)  
Let's start by launching Notepad. Click the Start button and type _"Notepad"_, then press **ENTER**.

![TODO: Insert an alternative text here](images/insert_your_notepad_image_here.png?raw=true)

_TODO: Insert caption text here_

<a name="segment2" />
### TODO: Insert segment2 title here ###

(TODO: Insert a tutorial segment text here. For example:)  
Let's start by launching Notepad. Click the Start button and type _"Notepad"_, then press **ENTER**.

![TODO: Insert an alternative text here](images/insert_your_notepad_image_here.png?raw=true)

_TODO: Insert caption text here_

---

<a name="summary" />
## Summary ##

(TODO: Insert a summary text here. For example:)  
In this tutorial, you saw how to easily start Notepad.