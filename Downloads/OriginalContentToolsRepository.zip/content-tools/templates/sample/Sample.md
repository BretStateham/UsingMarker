﻿<a name="Title" />
# (TODO: Insert a descriptive title here) #

---
<a name="Overview" />
## Overview ##

(TODO: Include an overview text here. For example:)  
The {insert title here} is a simple file sharing application that demonstrates the storage services of the Windows Azure Platform, together with the authentication and authorization capabilities of AppFabric Access Control Service (ACS).

![architecture-diagram](images/architecture-diagram.png?raw=true)

_Solution Architecture Diagram_

<a name="Prerequisites" />
### Prerequisites ###

The following software is required to run this sample:

- [TODO: Insert prerequisite 1 here][1]
- [TODO: Insert prerequisite 2 here][2]
- [TODO: Insert prerequisite 3 here][3]

[1]: http://insert_link_to_prerequisite_1_here/
[2]: http://insert_link_to_prerequisite_2_here/
[3]: http://insert_link_to_prerequisite_3_here/

<a name="Learn-More" />
### Learning more about {insert additional technologies here} ###
To learn more about the Windows Azure Platform and AppFabric, check the following resources:

- Hands-on labs in the Windows Azure Platform Training Course available online on [MSDN][4].
- Learn how to build applications with the Windows Azure Platform Training Kit you can [download here][5]. 

[4]: http://insert_link_to_technology_1_here/
[5]: http://insert_link_to_technology_2_here/

---

<a name="Getting-Started" />
## Getting Started ##

(TODO: Customize the getting started section with the required steps)
To get started with the this sample, you can run it locally using the Windows Azure compute emulator and your local SQL Server. If you want to deploy the sample to Windows Azure, please follow the instructions in the **Deployment** section.

---

<a name="Deployment" />
## Deployment ##

This section provides guidance on setting up the {insert sample title here} sample for deployment to the Windows Azure Platform.

1. (TODO: Insert step 1 here)
1. (TODO: Insert step 2 here)
1. (TODO: Insert step 3 here)


> **Note:** Make sure you have checked all the dependencies for this lab before running the setup.


---
<a name="Appendix" />
##Appendix##
(TODO: Write Appendix content here)
