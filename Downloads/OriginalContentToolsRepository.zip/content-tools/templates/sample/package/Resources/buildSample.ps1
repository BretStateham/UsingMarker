#------------------------------------------------------------
# Evangelism Content Framework. PowerShell implementation
#------------------------------------------------------------

# Functions
# Force-Resolve-Path deals with the problem that Resolve-Path throws an error if Path does not exists
# This function provides the 'resolving' feature without the 'validation'
function Force-Resolve-Path($filename)
{
  $filename = Resolve-Path $filename -ErrorAction SilentlyContinue -ErrorVariable _frperror
  if (!$filename)
  {
    return $_frperror[0].TargetObject
  }
  return $filename
}

# Arguments
[string] $sampleManifestPath = Resolve-Path $args[0]
[string] $outputFolder = Force-Resolve-Path $args[1]
[string] $conversionType = $args[2]
[string] $assetsFolder = Resolve-Path $args[3]

[bool] $createSeftExtracting = $conversionType -ieq "SelfExtracting" # -ieq is case insensitive comparison

# Directories
[string] $sampleFolder = Split-Path $sampleManifestPath # Original Sample location
[string] $tempFolder = Join-Path $outputFolder "temp" # Temp folder where to process files

$reader = [xml] (Get-Content $sampleManifestPath) # Read Sample.xml file
[string] $sampleId = $reader.Sample.Id # Take sample ID for naming folders
[string] $document = $reader.Sample.Document."#text"
[string] $documentFile = Split-Path -Leaf $document # Gets the name of the doc (Sample.md)
[string] $workingFolder = Join-Path $tempFolder $sampleId # Working folder wil be Ziped/Exed at the end of the script

# Files
[string] $sampleManifestFile = Split-Path -Leaf $sampleManifestPath # GetFilename: 'Sample.xml'
[string] $tempSampleFile = Join-Path $workingFolder $relativeSample # This is the copied and processed Sample.xml file

#Remove the Log.xml file if it exists
[string] $logFile = "Log.xml"
if(test-path $logFile)
{
    Remove-item $logFile
}

#This script registers the SnapIn
add-pssnapin ContentFrameworkSnapInv4

$ErrorActionPreference = "Stop"

#---------------------------------------------------------------------------
#-| Check for WinRar installation ------------------------------------------
#---------------------------------------------------------------------------
if($createSeftExtracting)
{
    Write "Checking for WinRar installation..."
    $winrarPath = Get-WinRarInstallPath
    if(!($winrarPath))
    {
        Write-Host "You must install WinRar in order to create Self-Extract Sample packages!" -ForegroundColor Red
        Write-Host "Press [ENTER] key to close."
        Read-Host
        Exit
    }
}
#---------------------------------------------------------------------------
#-| CopySample Step -------------------------------------------------------
#---------------------------------------------------------------------------
write "Copy sample to temp folder [$tempFolder]..."

[string] $beginExcludes = "package .svn obj bin" # 'package' folder should always be excluded

Copy-Sample $sampleManifestPath $tempFolder $beginExcludes ""

write "Copy sample done!"
#---------------------------------------------------------------------------

#---------------------------------------------------------------------------
#-| RemoveSoucreCodeBindings Step ------------------------------------------
#---------------------------------------------------------------------------
write "Removing source control bindings..."

Remove-SourceControlBindings $tempFolder

write "Source control bindings removal done!"
#---------------------------------------------------------------------------

#---------------------------------------------------------------------------
#-| AddHeaders Step --------------------------------------------------------
#---------------------------------------------------------------------------
write "Adding copyright headers to source code files..."

[string] $copyrightFile = Join-Path $assetsFolder "Copyright.txt"

Add-Headers $copyrightFile $tempFolder

write "Adding copyright headers done!"
#---------------------------------------------------------------------------

#---------------------------------------------------------------------------
#-| Convert Documents Step --------------------------------------------------
#---------------------------------------------------------------------------
write "Converting documents using Markercmd..."

# Use Cmdlet to resolve where the Markercmd binary is located
[string] $markercmdPath = Get-MarkercmdPath
# We'll process the copied MD file (instead of the original one)
[string] $sampleDocument = Join-Path $workingFolder $documentFile
# By default content.tt is the main T4 file
[string] $templatePath = Join-Path $assetsFolder 'MarkdownConversion\Content.tt'
# HTML output will be generated in .\Sample.md.html\
[string] $conversionOutputFolder = Join-Path $workingFolder "$documentFile.html\"

Write-Verbose "Executing: [$markercmdPath] to convert documents. Please wait until the process completes..."
Write-Verbose "MDSourcePath: $sampleDocument"
Write-Verbose "T4TemplatePath: $templatePath"
Write-Verbose "OutputFolder: $conversionOutputFolder"

# Arguments are quoted to support paths with spaces
Start-Process $markercmdPath -ArgumentList """$sampleDocument""", """$templatePath""", """$conversionOutputFolder""" -Wait

# Generate Sample.html as a redirect to the converted document
[string] $redirectFile = (Get-Item $sampleDocument).BaseName + ".html"
set-content -path "$workingFolder\$redirectFile" `
    -value "<html><head><meta http-equiv='REFRESH' content='0; url=$documentFile.html/$redirectFile'></head><body></body></html>"
Write "Generated redirect file $redirectFile"

Write "Converting documents done!"

#---------------------------------------------------------------------------
#-| Create Zip or Self Extracting ------------------------------------------
#---------------------------------------------------------------------------
if($createSeftExtracting)
{
	write "Creating self extracting ..."

	[string] $name = $sampleId + ".Setup.exe"
	[string] $licenseFile = Join-Path $assetsFolder "LicenseAgreement.txt"
	[string] $imageFile = Join-Path $assetsFolder "vertical.bmp"
	[string] $excludeFile = Join-Path $assetsFolder "Exclude.txt"

	Create-SelfExtract $name $tempSampleFile $outputFolder $licenseFile $imageFile $excludeFile
}
else
{
	write "Creating Zip file ..."
	[string] $name = $sampleId + ".zip"
	[string] $zipName = [System.IO.Path]::Combine($outputFolder, $name)
	[string] $excludeFile = Join-Path $assetsFolder "Exclude.txt"

	Create-Zip $workingFolder $zipName $excludeFile
}

write "Packaging Sample Finished!"
#---------------------------------------------------------------------------
