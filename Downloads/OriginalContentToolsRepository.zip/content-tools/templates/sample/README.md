﻿# {insert-sample-title} #

## Sample ##

### Introduction ###

For many developers, the easiest way to learn is to take existing code and either view it directly or run it and try it to see how it works. Samples applications and code samples are a perfect approach to directly run and test an specific idea or technique.

In this Sample, you will explore the basic elements of {insert-sample-overview}.

> **Note:** You can download the latest build of the {insert-sample-title} Sample which includes a tested version of this Sample from here: http://{insert-sample-download-url}.

### Repository Structure ###

In the **root** folder of this repository you will find the Sample document, **Sample.md**. Before running the sample code, make sure you have followed all the required steps indicated at the setup section of the Sample document. 

In the **Source** folder you will find the source code of the sample as well as the assets and setup scripts. Throughout the sample document you might be instructed to open and explore the different solutions from the source folder.

### Get Started ###

In order to run the solution provided by this sample you will first need configure your environment and install any necessary prerequisites such as runtimes, components, or libraries. For your ease, you can download and run the dependency checker [here](http://go.microsoft.com/fwlink/?LinkId=245702) to automatically check and install all the requirements.  

### Contributing to the Repository ###

If you find any issues or opportunities for improving this sample, fix them!  Feel free to contribute to this project by [forking](http://help.github.com/fork-a-repo/) this repository and make changes to the content.  Once you've made your changes, share them back with the community by sending a pull request. Please see [How to send pull requests](http://help.github.com/send-pull-requests/) for more information about contributing to Github projects.

### Reporting Issues ###

If you find any issues with this sample that you can't fix, feel free to report them in the [issues](https://github.com/{insert-the-github-url}/issues) section of this repository.