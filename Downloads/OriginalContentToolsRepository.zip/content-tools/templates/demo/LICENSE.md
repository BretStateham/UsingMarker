Copyright 2012 Microsoft

The **{insert_demo_title} Demo** is licensed under the terms of the Apache License, Version 2.0.
You may use it according to the license as is most appropriate for your project on a case-by-case basis.

The terms of this license can be found in http://www.apache.org/licenses/LICENSE-2.0