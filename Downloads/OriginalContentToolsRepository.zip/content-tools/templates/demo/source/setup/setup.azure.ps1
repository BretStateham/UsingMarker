Param([string] $localSettingsFile, [string] $azureSettingsFile)

$scriptDir = (split-path $myinvocation.mycommand.path -parent)
Set-Location $scriptDir

# "========= Initialization =========" #
if(-not $localSettingsFile)
{
	$localSettingsFile = "config.local.xml"
}
[xml] $xmlLocalSettings = Get-Content $localSettingsFile
# Import required settings from config.local.xml if neccessary #

if(-not $azureSettingsFile)
{
	$azureSettingsFile = "config.azure.xml"
}
[xml] $xmlAzureSettings = Get-Content $azureSettingsFile
# Import required settings from config.azure.xml if neccessary
[string] $queuename = $xmlAzureSettings.configuration.queuename


# "========= Main Script =========" #

# Include setup steps here. It is recommended to place task scripts in the tasks\ folder to maintain readability #
