Param([string] $demoSettingsFile, [string] $userSettingsFile)

$scriptDir = (split-path $myinvocation.mycommand.path -parent)
Set-Location $scriptDir

# "========= Initialization =========" #

# Get settings from demo configuration file
if($demoSettingsFile -eq $nul -or $demoSettingsFile -eq "")
{
	$demoSettingsFile = "setup.xml"
}

[xml] $xmlDemoSettings = Get-Content $demoSettingsFile
[string] $CSharpSnippets = $xmlDemoSettings.configuration.codeSnippets.cSharp
[string] $htmlSnippets = $xmlDemoSettings.configuration.codeSnippets.html


# Get settings from user configuration file
if($userSettingsFile -eq $nul -or $userSettingsFile -eq "")
{
	$userSettingsFile = "..\Config.Local.xml"
}

[xml]$xmlUserSettings = Get-Content $userSettingsFile
# Import required settings from config.local.xml if neccessary #
[string] $workingDir = $xmlUserSettings.configuration.localPaths.workingDir

[string] $sourceCodeDir = Resolve-Path "..\Code"

# "========= Main Script =========" #

write-host "========= Copying assets code to working directory... ========="
if (!(Test-Path "$workingDir"))
{
	New-Item "$workingDir" -type directory | Out-Null
}
Copy-Item "$sourceCodeDir\Assets\*" "$workingDir\Assets" -Recurse -Force
write-host "Copying Assets code to working directory done!"

# Include setup steps here. It is recommended to place task scripts in the tasks\ folder to maintain readability #
