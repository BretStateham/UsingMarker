﻿<a name="title" />
# (TODO: Insert a descriptive title here) #

---
<a name="Overview" />
## Overview ##

(TODO: Include an overview text here. For example:)  
In this demo lab you will open Notepad.

<a id="goals" />
### Goals ###
In this demo, you will see how to:

1. (TODO: Insert goal 1 here)
1. (TODO: Insert goal 2 here)
1. (TODO: Insert goal 3 here)

<a name="technologies" />
### Key Technologies ###

- {TODO: Include technology name here} [here][1]
- {TODO: Include technology name here}
- [{TODO: Include technology name here}][2]

[1]: http://insert_link_to_technology_1_here/
[2]: http://insert_link_to_technology_2_here/

<a name="Setup" />
### Setup and Configuration ###
(TODO: Customize the setup section with the required steps)
In order to execute this demo you need to set up your environment.

1. Open Windows Explorer and browse to the demo's **Source** folder.

1. Run the **Setup.Local.cmd** script as an administrator.

1. Execute the **Setup.Azure.cmd** file with Administrator privileges to initialize the Azure Service Bus queue required for the demo.

>**Note 1:** Make sure you have checked all the dependencies for this demo before running the setup.

>**Note 2:** The setup script copies the source code for this demo to a working folder that can be configured in the **Config.Local.xml** file (by default, C:\Projects). From now on, this folder will be referenced in this document as the **working folder**.

1. (TODO: Insert additional step 1 here)

1. (TODO: Insert additional step 2 here)

<a name="Demo" />
## Demo ##
This demo is composed of the following segments:

1. [(TODO: Insert Segment 1 title here)](#segment1).
1. [(TODO: Insert Segment 2 title here)](#segment2).

<a name="Segment1" />
### (TODO: Insert Segment 1 title here) ###

1. (TODO: Write step 1 here).

	> 	**Speaking Point:** 
	>
	(TODO: Write speaking points to help showcase the demo here. For example:) In this exercise, you will use preinstalled software to showcase a demo.

1. (TODO: Write step 2 here).

	![TODO: Insert an alternative text here](images/insert_your_notepad_image_here.png?raw=true "TODO: insert image description here")

	_TODO: Insert caption text here_

1. (TODO: Write step 3 here).

	> **Speaking point:** 
	>
	(TODO: Write speaking points to help showcase the demo here. For example:) In this exercise, you will use preinstalled software to showcase a demo.

	![TODO: Insert an alternative text here](images/insert_your_notepad_image_here.png?raw=true "TODO: insert image description here")

	_TODO: Insert caption text here_

1. (TODO: Write step 4 here also referring to a highlighted code section).

	<!-- mark:3-5 -->
	````C#
public ActionResult Index()
{
		ViewBag.Message = "Hello World";

		return View();
}
````

---

<a name="summary" />
## Summary ##

(TODO: Insert a summary text here. For example:)  
By completing this demo lab you have learned how to:

 * (TODO: Insert outcome 1 here)
 * (TODO: Insert outcome 2 here)
 * (TODO: Insert outcome 3 here)

---