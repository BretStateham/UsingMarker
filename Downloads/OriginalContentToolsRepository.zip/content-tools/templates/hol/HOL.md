﻿<a name="Title" />
# (TODO: Insert a descriptive title here) #

---
<a name="Overview" />
## Overview ##

(TODO: Include an overview text here. For example:)  
In this hands-on lab you will open Notepad.

<a name="Objectives" />
### Objectives ###

In this hands-on lab, you will learn how to:

(TODO: Insert bullets describing what the user will accomplish in this HOL)

* (TODO: Insert objective 1 here)
* (TODO: Insert objective 2 here)
* (TODO: Insert objective 3 here)

<a name="Prerequisites" />
### Prerequisites ###

The following is required to complete this hands-on lab:

- [TODO: Insert prerequisite 1 here][1]
- [TODO: Insert prerequisite 2 here][2]
- [TODO: Insert prerequisite 3 here][3]

[1]: http://insert_link_to_prerequisite_1_here/
[2]: http://insert_link_to_prerequisite_2_here/
[3]: http://insert_link_to_prerequisite_3_here/

<a name="Setup" />
### Setup ###
(TODO: Customize the setup section with the required steps)

In order to execute the exercises in this hands-on lab you need to set up your environment.

1. (TODO: Insert step 1 here)
1. (TODO: Insert step 2 here)
1. (TODO: Insert step 3 here)


> **Note:** Make sure you have checked all the dependencies for this lab before running the setup.

<a name="UsingCodeSnippets" />
### Using the Code Snippets ###
(TODO: Remove the code snippets section if your Lab does not include them)

Throughout the lab document, you will be instructed to insert code blocks. For your convenience, most of that code is provided as Visual Studio Code Snippets, which you can use from within Visual Studio 2010 to avoid having to add it manually. 

---
<a name="Exercises" />
## Exercises ##

This hands-on lab includes the following exercises:

1.	[(TODO: Insert Exercise 1 title here)](#Exercise1)
1.	[(TODO: Insert Exercise 2 title here)](#Exercise2)
1.	[(TODO: Insert Exercise 3 title here)](#Exercise3)


> **Note:** Each exercise is accompanied by a starting solution. These solutions are missing some code sections that are completed through each exercise and therefore will not necessarily work if running them directly.
Inside each exercise you will also find an end folder where you find the resulting solution you should obtain after completing the exercises. You can use this solution as a guide if you need additional help working through the exercises.

Estimated time to complete this lab: **(TODO: insert estimated time in minutes here)** minutes.

> **Note:** When you first start Visual Studio, you must select one of the predefined settings collections. Every predefined collection is designed to match a particular development style and determines window layouts, editor behavior, IntelliSense code snippets, and dialog box options. The procedures in this lab describe the actions necessary to accomplish a given task in Visual Studio when using the **General Development Settings** collection. If you choose a different settings collection for your development environment, there may be differences in these procedures that you need to take into account.

<a name="Exercise1" />
### Exercise 1: (TODO: Insert Exercise 1 title here) ###

(TODO: Write Exercise introduction here. For example:)  
In the first exercise you will open Notepad.

<a name="Ex1Task1" />
#### Task 1 – (TODO: Insert Task description here) ####

(TODO: Write a task introduction here. For example:)
In this exercise, you will use preinstalled software to showcase a hands-on lab.

1. (TODO: Write step 1 here) 

	![TODO: Insert an alternative text here](images/insert_your_notepad_image_here.png?raw=true)

	_TODO: Insert caption text here_

1. (TODO: Write step 2 here) 
1. (TODO: Write step 3 here) 

<a name="Exercise2"></a>
###Exercise 2: (TODO: Insert Exercise 2 title here) ###

(TODO: Write Exercise introduction here.)

<a name="Ex2Task1" />
#### Task 1 – (TODO: Insert Task description here) ####

(TODO: Write a task introduction here.)

1. (TODO: Write step 1 here) 

	| **ColHeader1** | **ColHeader2** |
	|----------------|----------------|
	| Field1         | Field2         |
	| Field3         | Field4         |
	| Field5         | Field6         |

---

<a name="summary" />
## Summary ##

(TODO: Insert a summary text here. For example:)  
By completing this hands-on lab you have learned how to:

 * (TODO: Insert outcome 1 here)
 * (TODO: Insert outcome 2 here)
 * (TODO: Insert outcome 3 here)

---

<a name="Appendix" />
##Appendix##
(TODO: Write Appendix content here)
