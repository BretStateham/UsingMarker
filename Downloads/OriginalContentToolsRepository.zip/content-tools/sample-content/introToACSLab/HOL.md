##Overview##
Connecting one application to its users is one of the most basic requirements of any solution, whether deployed on-premises, in the cloud or on both.

The emergence of standards is helping to break the silos which traditionally isolate accounts stored by different web sites and business entities, however offering application access to users coming from multiple sources can still be a daunting task. As of today, if you want to open your application to users coming from Facebook, Live ID, Google and business directories the brute-force approach demands you to lean and implement four different authentication protocols. Changes in today’s world happen fast and often, forcing you to keep updating your protocol implementations to chase the latest evolutions of the authentication mechanisms of the user repositories. All this can require a disproportionate amount of energy, leaving you with fewer resources to focus on your business.

![A functional view of the Access Control Service](images/cf60e43b-1dbe-48fd-ace5-54f0f25ba60e.png "A functional view of the Access Control Service")

Windows Azure Access Control Service (ACS) offers you a way to outsource authentication and decouple your application from all the complexity of maintaining a direct relationship with all the identity providers you want to tap from. ACS takes care of engaging every identity provider with its own authentication protocol, normalizing the authentication results in a protocol supported by the .NET framework tooling (namely the Windows Identity Foundation technology, or WIF) regardless of from where the user is coming from. WIF allows you in just few clicks to elect the ACS as the authentication manager for your application; from that moment on ACS takes care of everything, including providing a UI for the user to choose among all the recognized identity providers. 

Furthermore, ACS offers you greater control over which user attributes should be assigned for every authentication event; again in synergy with WIF, those attributes (called claims) can be easily accessed for taking authorization decisions without forcing the developer do understand or even be aware of the lower level mechanisms that the authentication protocols entail.

In this introductory hands-on lab you will learn how to take advantage of the ACS for outsourcing authentication, managing multiple identity sources, performing some basic authorization tasks and take control of the authentication experience. You will discover that it takes less to do it than to describe it!

##Objectives##

In this Hands-On Lab, you will learn how to:

- Configure your application to outsource authentication to ACS
- Configure ACS to include the identity providers you want to leverage
- Configure ACS to process incoming identities and add new claims
- Modify your application to consume claims from ACS and drive authorization decisions
- Customize the default authentication user experience provided by ACS

##System Requirements##

You must have the following items to complete this lab:

- Microsoft® Windows® Vista SP2 (32-bits or 64-bits) , Microsoft® Windows Server 2008 SP2 (32-bits or 64-bits), Microsoft® Windows Server 2008 R2, or Microsoft® Windows® 7 RTM (32-bits or 64-bits)
- Microsoft® Internet Information Services (IIS) 7.0
- Microsoft® .NET Framework 4
- Microsoft® Visual Studio 2010
- Microsoft® Windows Identity Foundation Runtime
- Microsoft® Windows Identity Foundation SDK
- Microsoft® Windows PowerShell

##Setup##
In order to execute the exercises in this hands-on lab you need to set up your environment.

1. Open a Windows Explorer window and browse to the lab’s Source folder.
2. Double-click the Setup.cmd file in this folder to launch the setup process that will configure your environment and install the Visual Studio code snippets for this lab.
3. If the User Account Control dialog is shown, confirm the action to proceed.


	> Make sure you have checked all the dependencies for this lab before running the setup.
	
	>If you have never run Visual Studio before on the machine, please make sure to do so before running the setup of this lab.

	>When you first start Visual Studio, you must select one of the predefined settings collections. Every predefined collection is designed to match a particular development style and determines window layouts, editor behavior, IntelliSense code snippets, and dialog box options. The procedures in this lab describe the actions necessary to accomplish a given task in Visual Studio when using the General Development Settings collection. If you choose a different settings collection for your development environment, there may be differences in these procedures that you need to take into account.

###Using the Code Snippets###
Throughout the lab document, you will be instructed to insert code blocks. For your convenience, most of that code is provided as Visual Studio Code Snippets, which you can use from within Visual Studio 2010 to avoid having to add it manually. 

If you are not familiar with the Visual Studio Code Snippets, and want to learn how to use them, you can refer to the **Setup** document in the **Assets** folder, which contains a section describing how to use them.

##Exercises##
The following exercises make up this Hands-On Lab:

1.	[Outsource Authentication to multiple Identity Providers](#Exercise1)
2.	Create claims mapping rules and add claims-driven authorization to an application
3.	Take control of the Sign-In experience


> **Note:** Each exercise is accompanied by a starting solution. These solutions are missing some code sections that are completed through each exercise and therefore will not necessarily work if running them directly.
Inside each exercise you will also find an end folder where you find the resulting solution you should obtain after completing the exercises. You can use this solution as a guide if you need additional help working through the exercises.

Estimated time to complete this lab: **45 minutes**

###Exercise 1: Use Access Control Service for Accepting Users from Multiple Identity Providers###

In the first exercise you will familiarize with ACS’ basic settings and terminology. Your task is to secure access to a newly created ASP.NET Web site. The Web site will accept users from Google, Yahoo! and Windows Live ID. As you will see in a minute, ACS makes it real easy.

####Task 1 – Creating the Initial Solution####


1. Open Microsoft Visual Studio 2010 with administrator privileges. From Start | All Programs | Microsoft Visual Studio 2010, right-click Microsoft Visual Studio 2010 and select Run as administrator.
2. Open the WebSiteACS.sln empty solution file located inside the \Source\Ex01-AcceptUsersFromMultipleIPs\Begin folder of this Lab.
3. Create a new empty website. To do this, right-click the WebSiteACS solution and select Add | New Web Site, select Visual C# in Installed Templates section and then click ASP.NET Web Site. Change the Web location field to use HTTP and set the value with https://localhost/WebSiteACS and click OK.
    ![Add New Web Site](images/9b815d24-f9c5-42a2-b702-288800d7f88f.png "Add New Web Site")

4. Go to Solution Explorer and delete the following folders from the web site: 
 - Account
 - Scripts
5. Also delete the the following files:
 - About.aspx
 - Global.asax
6. Solution explorer should appear as follows:

    ![Solution Explorer](images/c321097f-126e-4d25-b26c-e4ebb6d44a0b.png "Solution Explorer")

7. Open Site.master file and remove the DIV with class named “loginDisplay” and the NavigationMenu menu control.

	<span class="codeLanguage">HTML</span>

		<div class="page">
 		<div class="header">
	    	<div class="title">
      		<h1>
	        	My ASP.NET Application
      		</h1>
	    	</div>
	    	<div class="clear hideSkiplink">
 		</div>
		</div>


8. Another bullet
9. Yet another one

A lot more content goes here..

---


##Summary##
By completing this Hands-On Lab you have learned how to:

 - Configure your application to outsource authentication to ACS
 - Configure ACS to include the identity providers you want to leverage
 - Configure ACS to process incoming identities and add new claims
 - Modify your application to consume claims from ACS and drive authorization decisions
 - Customize the default authentication user experience provided by ACS

The notion of outsourcing authentication to an external entity, instead of taking care of the details yourself, is an extremely powerful one. Windows Identity Foundation makes it easy to configure .NET applications to trust their authentication needs to external authorities.

The Windows Azure Access Control Service is a great service to outsource authentication to, as it can easily abstract away the complexity of dealing with mutiple identity providers such as Windows Live ID, Facebook, Google, Yahoo! and even business providers such as directories enhanced by Active Directory Federation Services or equivalent. Furthermore, ACS offers powerful tools for manipulating the way in which the user’s identity is processed before reaching your application.

This introductory lab barely begun to explore the capabilities of ACS. Here we focused on Web sites, but ACS can handle just as well SOAP and REST web services; we used the portal, but ACS offers a rich management API which can be used to automate provisioning tasks; we focused on Web identities, but ACS offers comprehensive support for business identity providers and processing capabilites for the richer claims set they generate. If you are interested in knowing more about those capabilites, please refer to the upcoming intermerdiate and advanced hands-on labs.


