﻿namespace Microsoft.Dpe.Ecf.Core
{
    using System.IO;

    public interface IModelSerializer<TModel>
    {
        TModel Deserialize(FileStream stream);

        Stream Serialize(TModel model);
    }
}
