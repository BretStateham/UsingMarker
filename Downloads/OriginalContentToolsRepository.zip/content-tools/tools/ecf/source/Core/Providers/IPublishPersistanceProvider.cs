﻿namespace Microsoft.Dpe.Ecf.Core.Providers
{
    using System;
    using System.Collections.ObjectModel;
    using Microsoft.Dpe.Ecf.Model;

    public interface IPublishPersistenceProvider
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1704:IdentifiersShouldBeSpelledCorrectly", MessageId = "ecf", Justification = "ecf is the solution name")]
        void PersistElementPosts(string xmlFile, EcfElement ecfElement, Collection<PublishedPost> publishedPosts, string blog, string userName);

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1704:IdentifiersShouldBeSpelledCorrectly", MessageId = "ecf", Justification = "ecf is the solution name")]
        void PersistElementPosts(string xmlFile, string ecfElementId, Type ecfType, Collection<PublishedPost> publishedPosts, string blog, string userName);

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1704:IdentifiersShouldBeSpelledCorrectly", MessageId = "ecf", Justification = "ecf is the solution name")]
        Collection<PublishedPost> GetPersistedElementPosts(string xmlFile, EcfElement ecfElement);

        IPublishedElementsDictionary GetPersistedElementPosts(string xmlFile);

        void CreateEmpty(string xmlFile);
    }
}
