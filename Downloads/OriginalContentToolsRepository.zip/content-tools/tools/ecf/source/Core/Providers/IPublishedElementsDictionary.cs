﻿namespace Microsoft.Dpe.Ecf.Core.Providers
{
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using Microsoft.Dpe.Ecf.Model;

    [Serializable]
    public abstract class IPublishedElementsDictionary : Dictionary<PublishedElementsDictionaryKey, Collection<PublishedPost>>
    {
        public abstract PublishedElementsDictionary FilterObsoletePosts(bool obsolete);

        public abstract PublishedElementsDictionary FilterDraftPosts(bool draft);

        public abstract IPublishedElementsDictionary Clone();
    }
}
