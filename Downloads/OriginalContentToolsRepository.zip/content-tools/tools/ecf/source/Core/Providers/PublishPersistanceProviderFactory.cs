﻿namespace Microsoft.Dpe.Ecf.Core.Providers
{
    public sealed class PublishPersistenceProviderFactory
    {
        private PublishPersistenceProviderFactory()
        {
        }

        public static IPublishPersistenceProvider Instance
        {
            get
            {
                // TODO: change to take the Provider Type from configuration
                return new XmlPublishPersistenceProvider();
            }
        }
    }
}
