﻿namespace Microsoft.Dpe.Ecf.Core.Providers
{
    using System;
    using System.Xml.Serialization;
    using Microsoft.Dpe.Ecf.Model;

    public class PublishedElementsDictionaryKey
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1704:IdentifiersShouldBeSpelledCorrectly", MessageId = "ecf", Justification = "ECF is the name of the solution")]
        public PublishedElementsDictionaryKey(EcfElement ecfElement)
            : this(ecfElement, null, null)
        {
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1704:IdentifiersShouldBeSpelledCorrectly", MessageId = "ecf", Justification = "ECF is the name of the solution")]
        public PublishedElementsDictionaryKey(EcfElement ecfElement, string blog, string userName)
        {
            this.EcfType = ecfElement.GetType();
            this.Id = ecfElement.Id;
            this.Blog = blog;
            this.UserName = userName;            
        }

        protected PublishedElementsDictionaryKey()
        {
        }

        [XmlAttribute]
        public string Id
        {
            get;
            set;
        }

        [XmlAttribute]
        public string UserName
        {
            get;
            set;
        }

        [XmlAttribute]
        public string Blog
        {
            get;
            set;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1704:IdentifiersShouldBeSpelledCorrectly", MessageId = "Ecf", Justification = "ECF is the name of the solution")]
        [XmlIgnore]
        public Type EcfType
        {
            get;
            set;
        }

        public override int GetHashCode()
        {            
            return this.Id.GetHashCode(); // Just the Id
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (this.GetType() != obj.GetType())
            {
                return false; 
            }

            // safe because of the GetType check
            PublishedElementsDictionaryKey otherKey = (PublishedElementsDictionaryKey)obj;

            // use this pattern to compare reference members
            if (!String.Equals(this.Id, otherKey.Id))
            {
                return false; 
            }

            // use this pattern to compare value members            
            return true;
        }        
    }
}
