﻿namespace Microsoft.Dpe.Ecf.Core.Providers
{
    using System;
    using System.Collections.ObjectModel;
    using System.Linq;
    using System.Reflection;
    using System.Xml;
    using System.Xml.Schema;
    using System.Xml.Serialization;
    using Microsoft.Dpe.Ecf.Model;

    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2229:ImplementSerializationConstructors", Justification = "Class implements an abstract class, so cant call to XMLSerializable contructor")]
    [XmlRoot(ElementName = "PublishedElements")]
    [Serializable]
    public class PublishedElementsDictionary : IPublishedElementsDictionary, IXmlSerializable
    {
        public PublishedElementsDictionary() 
        {            
        }        

        public override PublishedElementsDictionary FilterObsoletePosts(bool obsolete)
        {
            PublishedElementsDictionary filteredDictonary = new PublishedElementsDictionary();
            foreach (var key in this.Keys)
            {
                Collection<PublishedPost> posts = new Collection<PublishedPost>(this[key].Where(p => p.Obsolete == obsolete).ToList());
                if (posts.Count > 0)
                {
                    filteredDictonary.Add(key, posts);
                }
            }

            return filteredDictonary;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1002:DoNotExposeGenericLists", Justification = "Returned value must be ordered")]
        public override PublishedElementsDictionary FilterDraftPosts(bool draft)
        {
            PublishedElementsDictionary filteredDictonary = new PublishedElementsDictionary();
            foreach (var key in this.Keys)
            {
                Collection<PublishedPost> posts = new Collection<PublishedPost>(this[key].Where(p => p.Draft == draft).ToList());
                if (posts.Count > 0)
                {
                    filteredDictonary.Add(key, posts);
                }
            }

            return filteredDictonary;
        }

        public override IPublishedElementsDictionary Clone()
        {
            PublishedElementsDictionary clone = new PublishedElementsDictionary();
            foreach (var key in this.Keys)
            {                
                clone.Add(key, new Collection<PublishedPost>(this[key].ToList()));                
            }

            return clone;
        }

        public XmlSchema GetSchema()
        {
            return null;
        }

        public void ReadXml(XmlReader reader)
        {
            // Clear all elements
            this.Clear();

            if (reader.IsEmptyElement)
            {
                return;
            }

            // Read <PublishedElements>
            reader.ReadStartElement("PublishedElements");

            // read each property
            while (!(reader.NodeType == XmlNodeType.EndElement && reader.Name == "PublishedElements"))
            {
                if (reader.AttributeCount < 1)
                {
                    throw new XmlException("ECFElement elements should should contain an Id attribute");
                }

                // Read Id attributes
                string ecfElementId = reader.GetAttribute("Id");
                string blog = reader.GetAttribute("Blog");
                string userName = reader.GetAttribute("Username");
                string ecfTypeName = reader.Name;

                // Advance to next node
                reader.Read();

                // Read Posts
                Collection<PublishedPost> posts = ReadPosts(reader);

                // Add value to the dictinary
                var key = new PublishedElementsDictionaryKey(GetEcfElement(ecfElementId, ecfTypeName));
                key.UserName = userName;
                key.Blog = blog;
                this.Add(key, posts);

                // Read </ECFElement>
                reader.ReadEndElement();
            }

            // Read </PublishedElements>
            reader.ReadEndElement();
        }

        public void WriteXml(XmlWriter writer)
        {
            // Write each element            
            foreach (PublishedElementsDictionaryKey key in this.Keys)
            {
                // Write element
                writer.WriteStartElement(key.EcfType.Name);
                writer.WriteAttributeString("Id", key.Id);                
                writer.WriteAttributeString("Username", key.UserName);
                writer.WriteAttributeString("Blog", key.Blog);

                // Write each Post
               SerializePosts(writer,  this[key]);

               writer.WriteEndElement();
            }
        }

        private static EcfElement GetEcfElement(string ecfElemnetId, string ecfTypeName)
        {
            Assembly assembly = Assembly.GetAssembly(typeof(EcfElement));
            string ecfTypeFullName = typeof(EcfElement).FullName.Replace(typeof(EcfElement).Name, ecfTypeName);
            Type type = assembly.GetType(ecfTypeFullName, true, true);

            EcfElement newElement = (EcfElement)type.GetConstructor(new Type[0]).Invoke(new object[0]);
            newElement.Id = ecfElemnetId;

            return newElement;
        }

        private static Collection<PublishedPost> ReadPosts(XmlReader reader)
        {
            Collection<PublishedPost> list = new Collection<PublishedPost>();
            if (reader.IsEmptyElement)
            {
                // Read <Posts />
                reader.ReadStartElement("Posts");
                return list;
            }

            // Read <Posts>
            reader.ReadStartElement("Posts");
            
            // read each property
            while (!(reader.NodeType == XmlNodeType.EndElement && reader.Name == "Posts"))
            {
                XmlSerializer postSerializer = new XmlSerializer(typeof(PublishedPost));
                PublishedPost post = (PublishedPost)postSerializer.Deserialize(reader);

                list.Add(post);
            }

            // Read </Posts>
            reader.ReadEndElement();

            return list;
        }

        private static void SerializePosts(XmlWriter writer, Collection<PublishedPost> list)
        {
            writer.WriteStartElement("Posts");
            XmlSerializer postSerializer = new XmlSerializer(typeof(PublishedPost));
            foreach (var post in list)
            {
                postSerializer.Serialize(writer, post);
            }

            writer.WriteEndElement();             
        }       
    }
}
