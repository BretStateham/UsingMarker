﻿namespace Microsoft.Dpe.Ecf.Core.Providers
{
    using System;
    using System.Collections.ObjectModel;
    using System.IO;
    using System.Xml.Serialization;
    using Microsoft.Dpe.Ecf.Model;

    public class XmlPublishPersistenceProvider : IPublishPersistenceProvider
    {
        public void PersistElementPosts(string xmlFile, EcfElement ecfElement, Collection<PublishedPost> publishedPosts, string blog, string userName)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(PublishedElementsDictionary));
            PublishedElementsDictionaryKey key = new PublishedElementsDictionaryKey(ecfElement, blog, userName);

            // Read current model
            PublishedElementsDictionary current;
            if (File.Exists(xmlFile))
            {                
                current = (PublishedElementsDictionary)this.GetPersistedElementPosts(xmlFile);
            }
            else
            {
                current = new PublishedElementsDictionary();
            }             

            // Add element (replacing old one)
            if (current.ContainsKey(key))
            {
                current[key] = publishedPosts;
            }
            else
            {
                current.Add(key, publishedPosts);
            }

            using (FileStream file = new FileStream(xmlFile, FileMode.Create))
            {
                serializer.Serialize(file, current);
            }
        }

        public void PersistElementPosts(string xmlFile, string ecfElementId, Type ecfType, Collection<PublishedPost> publishedPosts, string blog, string userName)
        {
            // Construct ECFElement
            EcfElement ecfElement = (EcfElement)ecfType.GetConstructor(new Type[0]).Invoke(new object[0]);
            ecfElement.Id = ecfElementId;

            // Call persistElementPosts
            this.PersistElementPosts(xmlFile, ecfElement, publishedPosts, blog, userName);
        }

        public Collection<PublishedPost> GetPersistedElementPosts(string xmlFile, EcfElement ecfElement)
        {
            var allElements = this.GetPersistedElementPosts(xmlFile);
            var key = new PublishedElementsDictionaryKey(ecfElement);
            if (allElements.ContainsKey(key))
            {
                return allElements[key];
            }
            else
            {
                return new Collection<PublishedPost>();
            }
        }

        public IPublishedElementsDictionary GetPersistedElementPosts(string xmlFile)
        {
            if (!File.Exists(xmlFile))
            {
                return new PublishedElementsDictionary();
            }

            XmlSerializer serializer = new XmlSerializer(typeof(PublishedElementsDictionary));
            PublishedElementsDictionary pesistedElements;
            using (FileStream file = new FileStream(xmlFile, FileMode.Open))
            {
                pesistedElements = (PublishedElementsDictionary)serializer.Deserialize(file);
            }

            return pesistedElements;
        }

        public void CreateEmpty(string xmlFile)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(PublishedElementsDictionary));

            PublishedElementsDictionary emptyDictionary = new PublishedElementsDictionary();

            using (FileStream file = new FileStream(xmlFile, FileMode.Create))
            {
                serializer.Serialize(file, emptyDictionary);
            }
        }
    }
}
