﻿namespace ContentFramework.Core.Models
{
    using System;
    using System.ComponentModel;
    using System.Xml.Serialization;

    [XmlType(TypeName = "Post")]
    public class PublishedPost
    {
        public PublishedPost(string postId, Uri postUri, string postTitle, bool published, DateTime lastModified)
        {
            this.PostUri = postUri;
            this.PostId = postId;
            this.PostTitle = postTitle;
            this.Draft = !published;
            this.LastModified = lastModified;
        }

        public PublishedPost(string postId, Uri postUri, string postTitle, bool published) : this(postId, postUri, postTitle, published, DateTime.Now)
        {            
        }

        protected PublishedPost()
        {
        }               

        [XmlIgnore]
        public Uri PostUri
        {
            get;
            set;
        }

        [XmlElement]
        public string Link
        {
            get
            {
                return this.PostUri.ToString();
            }

            set 
            {
                this.PostUri = new Uri(value);
            }
        }

        [XmlElement(ElementName = "Id")]
        public string PostId
        {
            get;
            set;
        }

        [XmlElement(ElementName = "Title")]
        public string PostTitle
        {
            get;
            set;
        }

        [XmlElement(ElementName = "LastModified", DataType = "dateTime")]
        public DateTime LastModified
        {
            get;
            set;
        }

        [XmlAttribute]
        public bool Draft
        {
            get;
            set;
        }

        [XmlAttribute()]
        [DefaultValueAttribute(false)]
        public bool Obsolete
        {
            get;
            set;
        }
    }   
}
