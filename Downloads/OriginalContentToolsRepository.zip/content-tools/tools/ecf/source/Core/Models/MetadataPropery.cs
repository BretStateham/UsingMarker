﻿namespace Microsoft.Dpe.Ecf.Core.Models
{
    using System.Xml.Linq;

    public class MetadataProperty
    {
        public XName XWordProperty
        {
            get;
            set;
        }

        public string Value
        {
            get;
            set;
        }
    }
}
