﻿namespace Microsoft.Dpe.Ecf.Core.Models
{
    using System.Xml.Linq;

    /// <summary>
    /// This class provide a list of properties.
    /// </summary>
    internal static class XMetadataProperties
    {
        public const string CPNamespace = "http://schemas.openxmlformats.org/package/2006/metadata/core-properties";
        public const string DCNamespace = "http://purl.org/dc/elements/1.1/";

        public static XName Author
        {
            get { return XName.Get("creator", DCNamespace); }
        }

        public static XName Title
        {
            get { return XName.Get("title", DCNamespace); }
        }

        public static XName Comments
        {
            get { return XName.Get("description", DCNamespace); }
        }

        public static XName Version
        {
            get { return XName.Get("version", CPNamespace); }
        }
    }
}
