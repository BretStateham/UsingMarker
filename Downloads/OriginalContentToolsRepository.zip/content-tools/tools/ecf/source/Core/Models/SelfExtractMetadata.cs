﻿namespace Microsoft.Dpe.Ecf.Core.Models
{
    using Microsoft.Dpe.Ecf.Model;

    public class SelfExtractMetadata
    {
        public Package Package { get; set; }

        public Sample Sample { get; set; }

        public string OutputDirectory { get; set; }

        public string Name { get; set; }

        public string ImageFile { get; set; }

        public string LicenseAgreementFile { get; set; }

        public string ExcludeFiles { get; set; }

        public string StartCommand { get; set; }

        public string ShortcutFile { get; set; }

        public string FolderToCompress { get; set; }
    }
}
