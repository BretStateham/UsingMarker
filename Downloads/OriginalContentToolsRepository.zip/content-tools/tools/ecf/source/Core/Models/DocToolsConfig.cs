﻿namespace Microsoft.Dpe.Ecf.Core.Models
{
    using System;
    using System.Globalization;

    public class DocToolsConfig
    {
        private string copyright = "Copyright © {0} by Microsoft Corporation. All rights reserved.";

        public DocToolsConfig(string header, string feedback)
        {
            this.Feedback = feedback;
            this.Header = header;            
        }

        public string Feedback
        {
            get;
            set;
        }

        public string Header
        {
            get;
            set;
        }

        public string Copyright
        {
            get
            {
                return String.Format(CultureInfo.InvariantCulture, this.copyright, DateTime.Now.Year);
            }
        }
    }
}
