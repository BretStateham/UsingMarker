﻿namespace Microsoft.Dpe.Ecf.Core.Models
{
    public static class CompressCommands
    {
        public static string AddToAnArchive
        {
            get { return "a"; }
        }
    }
}
