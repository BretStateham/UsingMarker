﻿namespace Microsoft.Dpe.Ecf.Core.Helpers
{
    using System.IO;
    using Microsoft.Dpe.Ecf.Common;
    using Microsoft.Dpe.Ecf.Model;

    public class XmlHelper<T>
    {
        /* UNCOMMENT This constructor to use DataContract Serializarion instead of XML Serialiazation
         public XmlHelper() : this(new DataContractModelSerializer<T>())
         {
         }
         */

        public XmlHelper()
            : this(new XMLModelSerializer<T>())
        {
        }

        public XmlHelper(IModelSerializer<T> serializer)
        {
            this.Serializer = serializer;
        }

        protected IModelSerializer<T> Serializer
        {
            get;
            set;
        }

        protected string ManifestFilePath
        {
            get;
            set;
        }

        public virtual T ReadMetadata(string filePath)
        {
            T entity = default(T);

            if (!File.Exists(filePath))
            {
                throw new ContentFrameworkException("Metadata file does not exist: " + filePath, "Ensure the Package.xml metadata has a valid path to the content folder on each unit section that uses the content");
            }

            this.ManifestFilePath = Path.GetDirectoryName(filePath);
            using (FileStream stream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
            {
                entity = this.Serializer.Deserialize(stream);
            }

            Presentation presentation = entity as Presentation;

            if (presentation != null)
            {
                if (presentation.SlideThumbnail != 0)
                {
                    Logger.Log(LogLevel.Warning, "SlideThumbnail in Presentation is deprecated");
                }
            }

            return entity;
        }
    }
}
