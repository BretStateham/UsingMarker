﻿namespace Microsoft.Dpe.Ecf.Core.Helpers
{
    using System;

    public static class HtmlHelper
    {
        public static string GetInnerHtml(string htmlText, string tagName)
        {
            if (htmlText == null)
            {
                throw new ArgumentNullException("htmlText");
            }

            int ptag = htmlText.IndexOf("<" + tagName, StringComparison.OrdinalIgnoreCase);

            if (ptag < 0)
            {
                return htmlText;
            }

            int ptag1 = htmlText.IndexOf(">", ptag, StringComparison.OrdinalIgnoreCase);

            int ptag2 = htmlText.IndexOf("</" + tagName, StringComparison.OrdinalIgnoreCase);

            return htmlText.Substring(ptag1 + 1, ptag2 - ptag1 - 1);
        }

        public static string GetTitleContent(string htmlText)
        {
            return GetInnerHtml(htmlText, "title");
        }

        public static string GetBodyContent(string htmlText)
        {
            return GetInnerHtml(htmlText, "body");
        }
    }
}
