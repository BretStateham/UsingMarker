﻿namespace Microsoft.Dpe.Ecf.Core.Helpers
{
    using System;
    using System.Globalization;
    using System.Text;

    public class CompressArgumentsBuilder
    {
        private StringBuilder builder = new StringBuilder();

        public string SourcePath
        {
            get;
            set;
        }

        public string OutputFileName
        {
            get;
            set;
        }

        public string Command
        {
            get;
            set;
        }

        public string ImageFileName
        {
            get;
            set;
        }

        public bool RecurseFolders
        {
            get;
            set;
        }

        public bool AssumeYesOnQueries 
        { 
            get; 
            set; 
        }

        public bool CreateSelfExtracting
        {
            get;
            set;
        }

        public string CommentsFileName
        {
            get;
            set;
        }

        public string ExcludeFileName 
        { 
            get; 
            set; 
        }

        public override string ToString()
        {
            this.builder.Append(this.Command);

            if (this.RecurseFolders)
            {
                this.builder.Append(" -r");
            }

            if (this.AssumeYesOnQueries)
            {
                this.builder.Append(" -y");
            }

            if (this.CreateSelfExtracting)
            {
                this.builder.Append(" -sfx");
            }

            if (!String.IsNullOrEmpty(this.ImageFileName))
            {
                this.builder.AppendFormat(" -iimg\"{0}\"", this.ImageFileName);
            }

            if (!String.IsNullOrEmpty(this.CommentsFileName))
            {
                this.builder.AppendFormat(" -z\"{0}\"", this.CommentsFileName);
            }

            if (!String.IsNullOrEmpty(this.ExcludeFileName))
            {
                this.builder.AppendFormat(" -x@\"{0}\"", this.ExcludeFileName);
            }

            this.builder.AppendFormat(CultureInfo.InstalledUICulture, " \"{0}\" \"{1}\"", this.OutputFileName, this.SourcePath);

            return this.builder.ToString();
        }
    }
}
