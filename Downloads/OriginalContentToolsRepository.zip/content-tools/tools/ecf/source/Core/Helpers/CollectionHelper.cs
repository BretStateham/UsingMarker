﻿namespace Microsoft.Dpe.Ecf.Core.Helpers
{
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;

    public static class CollectionHelper
    {
        public static void AddRange<T>(this Collection<T> collection, IEnumerable<T> values)
        {
            foreach (var item in values)
            {
                collection.Add(item);
            }
        }

        public static T Find<T>(this Collection<T> collection, Predicate<T> predicate)
        {
            foreach (var item in collection)
            {
                if (predicate(item))
                {
                    return item;
                }
            }

            return default(T);
        }
    }
}
