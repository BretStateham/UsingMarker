﻿namespace Microsoft.Dpe.Ecf.Core.Helpers
{
    internal enum ConverstionTypeOLD
    {
        WebPage,
        Weblog
    }
}
