﻿namespace Microsoft.Dpe.Ecf.Core.Helpers
{
    using System.Collections.Generic;
    using System.IO;
    using System.Text.RegularExpressions;
    using Microsoft.Dpe.Ecf.Model;

    public static class PublishStepHelper
    {
        public static string ChangeTopicLinks(string content, Dictionary<string, PublishedPost> publishedPosts)
        {
            foreach (string filePath in publishedPosts.Keys)
            {
                content = Regex.Replace(content, Path.GetFileName(filePath), publishedPosts[filePath].PostUri.ToString(), RegexOptions.IgnoreCase);
            }

            return content;
        }

        public static string ChangeImagesLinks(string content, string relativePath, Dictionary<string, string> uploadedImages)
        {
            foreach (string imageName in uploadedImages.Keys)
            {
                content = Regex.Replace(content, relativePath + @"\\" + imageName, uploadedImages[imageName], RegexOptions.IgnoreCase);
            }

            return content;
        }

        public static string ChangeLocalFilesLinks(string content, Dictionary<string, string> uploadedLocalFiles)
        {
            foreach (string fileName in uploadedLocalFiles.Keys)
            {
                content = Regex.Replace(content, "src=\"../local/" + fileName, "src=\"" + uploadedLocalFiles[fileName], RegexOptions.IgnoreCase);
            }

            return content;
        }
    }
}
