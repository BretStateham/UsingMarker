﻿namespace Microsoft.Dpe.Ecf.Core.Helpers
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Reflection;
    using System.Text.RegularExpressions;
    using System.Xml;
    using System.Xml.Schema;
    using Microsoft.Dpe.Ecf.Common;
    using Microsoft.Dpe.Ecf.Common.Helpers;
    using Microsoft.Dpe.Ecf.Model;

    public class MetadataHelper
    {
        private XmlHelper<Package> packageHelper;
        private XmlHelper<Lab> labHelper;
        private XmlHelper<Presentation> presentationHelper;
        private XmlHelper<Demo> demoHelper;
        private XmlHelper<Sample> sampleHelper;
        private XmlHelper<Video> videoHelper;
        private XmlHelper<Whitepaper> whitepaperHelper;
        private bool validXml;

        public MetadataHelper()
            : this(new XmlHelper<Package>(), new XmlHelper<Lab>(), new XmlHelper<Presentation>(), new XmlHelper<Demo>(), new XmlHelper<Sample>(), new XmlHelper<Video>(), new XmlHelper<Whitepaper>())
        {
        }

        public MetadataHelper(
            XmlHelper<Package> packageHelper,
            XmlHelper<Lab> labHelper,
            XmlHelper<Presentation> presentationHelper,
            XmlHelper<Demo> demoHelper,
            XmlHelper<Sample> sampleHelper,
            XmlHelper<Video> videoHelper,
            XmlHelper<Whitepaper> whitepaperHelper)
        {
            this.packageHelper = packageHelper;
            this.labHelper = labHelper;
            this.presentationHelper = presentationHelper;
            this.demoHelper = demoHelper;
            this.sampleHelper = sampleHelper;
            this.videoHelper = videoHelper;
            this.whitepaperHelper = whitepaperHelper;
        }

        public virtual Package ReadMetadata(string filePath)
        {
            if (filePath == null)
            {
                throw new ArgumentNullException("filePath");
            }

            string contentDirectory = Path.GetDirectoryName(filePath);

            Package package = this.packageHelper.ReadMetadata(filePath);
            package.Location = filePath;

            foreach (Unit unit in package.Units)
            {
                this.ReadUnit(unit, contentDirectory);
            }

            return package;
        }

        public virtual Package ReadPlainMetadata(string filePath)
        {
            if (filePath == null)
            {
                throw new ArgumentNullException("filePath");
            }

            string contentDirectory = Path.GetDirectoryName(filePath);

            Package package = this.packageHelper.ReadMetadata(filePath);
            package.Location = filePath;

            return package;
        }

        public ICollection<string> GetPackageDirectories(Package package)
        {
            List<string> directories = new List<string>();

            foreach (Unit unit in package.Units)
            {
                directories.AddRange(unit.LabDirectories);
                directories.AddRange(unit.PresentationDirectories);
                directories.AddRange(unit.VideoDirectories);
                directories.AddRange(unit.WhitepaperDirectories);
                directories.AddRange(unit.SampleDirectories);
                directories.AddRange(unit.DemoDirectories);
            }

            return directories;
        }

        public virtual bool CheckSchema(string filePath)
        {
            if (!File.Exists(filePath))
            {
                throw new ContentFrameworkException("Could not find metadata file " + filePath, "Verify the path in the Package.xml is valid and the metadata for the content exist");
            }

            Logger.Log(LogLevel.Information, "Validating metadata file: " + filePath);

            var xsdStream1 = Assembly.GetExecutingAssembly().GetManifestResourceStream("ContentFramework.Core.Schema.ECF.xsd");
            var xsdStream2 = Assembly.GetExecutingAssembly().GetManifestResourceStream("ContentFramework.Core.Schema.Arrays.xsd");
            var schema1 = XmlSchema.Read(new XmlTextReader(xsdStream1), null);
            var schema2 = XmlSchema.Read(new XmlTextReader(xsdStream2), null);
            
            this.validXml = true;

            try
            {
                XmlReaderSettings settings = new XmlReaderSettings();
                settings.Schemas.Add(schema1);
                settings.Schemas.Add(schema2);
                settings.ValidationType = ValidationType.Schema;
                settings.ValidationEventHandler += new ValidationEventHandler(this.Settings_ValidationEventHandler);

                using (XmlReader x = XmlReader.Create(filePath, settings))
                {
                    while (x.Read())
                    {
                    }
                }
            }
            catch (Exception ex)
            {
                this.validXml = false;

                Logger.Log(LogLevel.Warning, ex.Message);
            }

            return this.validXml;
        }

        public virtual bool CheckSchemaFromSource(string filePath)
        {
            var result = true;

            if (filePath == null)
            {
                throw new ArgumentNullException("filePath");
            }

            if (!this.CheckSchema(filePath))
            {
                return false;
            }

            string contentDirectory = Path.GetDirectoryName(filePath);

            var ecfElement = this.ReadEcfElement(filePath);

            Package package = ecfElement as Package;

            if (package == null)
            {
                return true;
            }

            package.Location = filePath;

            foreach (Unit unit in package.Units)
            {
                foreach (string labDirectory in unit.LabDirectories)
                {
                    if (!this.CheckSchema(GetElementFilePath(contentDirectory, labDirectory, "Lab.xml")))
                    {
                        result = false;
                    }
                }

                foreach (string demoDirectory in unit.DemoDirectories)
                {
                    if (!this.CheckSchema(GetElementFilePath(contentDirectory, demoDirectory, "Demo.xml")))
                    {
                        result = false;
                    }
                }

                foreach (string presentationDirectory in unit.PresentationDirectories)
                {
                    if (!this.CheckSchema(GetElementFilePath(contentDirectory, presentationDirectory, "Presentation.xml")))
                    {
                        result = false;
                    }
                }

                foreach (string sampleDirectory in unit.SampleDirectories)
                {
                    if (!this.CheckSchema(GetElementFilePath(contentDirectory, sampleDirectory, "Sample.xml")))
                    {
                        result = false;
                    }
                }

                foreach (string videoDirectory in unit.VideoDirectories)
                {
                    if (!this.CheckSchema(GetElementFilePath(contentDirectory, videoDirectory, "Video.xml")))
                    {
                        result = false;
                    }
                }

                foreach (string whitepaperDirectory in unit.WhitepaperDirectories)
                {
                    if (!this.CheckSchema(GetElementFilePath(contentDirectory, whitepaperDirectory, "Whitepaper.xml")))
                    {
                        result = false;
                    }
                }
            }

            return result;
        }

        public virtual bool CheckSchemaFromWorkingDirectory(string filePath)
        {
            var result = true;

            if (filePath == null)
            {
                throw new ArgumentNullException("filePath");
            }

            if (!this.CheckSchema(filePath))
            {
                return false;
            }

            var ecfElement = this.ReadEcfElementFromWorkingDirectory(filePath);

            Package package = ecfElement as Package;

            if (package == null)
            {
                return true;
            }

            package.Location = filePath;

            foreach (Unit unit in package.Units)
            {
                var workingDirectory = Path.GetDirectoryName(filePath);

                foreach (string labDirectory in unit.LabDirectories)
                {
                    string labDirectoryName = (new System.IO.DirectoryInfo(labDirectory)).Name;
                    if (!this.CheckSchema(GetElementFilePath(Path.Combine(workingDirectory, "Labs"), labDirectoryName, "Lab.xml")))
                    {
                        result = false;
                    }
                }

                foreach (string demoDirectory in unit.DemoDirectories)
                {
                    string demoDirectoryName = (new System.IO.DirectoryInfo(demoDirectory)).Name;
                    if (!this.CheckSchema(GetElementFilePath(Path.Combine(workingDirectory, "Demos"), demoDirectoryName, "Demo.xml")))
                    {
                        result = false;
                    }
                }

                foreach (string presentationDirectory in unit.PresentationDirectories)
                {
                    string presentationDirectoryName = (new System.IO.DirectoryInfo(presentationDirectory)).Name;
                    if (!this.CheckSchema(GetElementFilePath(Path.Combine(workingDirectory, "Presentations"), presentationDirectoryName, "Presentation.xml")))
                    {
                        result = false;
                    }
                }

                foreach (string sampleDirectory in unit.SampleDirectories)
                {
                    string sampleDirectoryName = (new System.IO.DirectoryInfo(sampleDirectory)).Name;
                    if (!this.CheckSchema(GetElementFilePath(Path.Combine(workingDirectory, "Samples"), sampleDirectoryName, "Sample.xml")))
                    {
                        result = false;
                    }
                }

                foreach (string videoDirectory in unit.VideoDirectories)
                {
                    string videoDirectoryName = (new System.IO.DirectoryInfo(videoDirectory)).Name;
                    if (!this.CheckSchema(GetElementFilePath(Path.Combine(workingDirectory, "Videos"), videoDirectoryName, "Video.xml")))
                    {
                        result = false;
                    }
                }

                foreach (string whitepaperDirectory in unit.WhitepaperDirectories)
                {
                    string videoDirectoryName = (new System.IO.DirectoryInfo(whitepaperDirectory)).Name;
                    if (!this.CheckSchema(GetElementFilePath(Path.Combine(workingDirectory, "Whitepapers"), videoDirectoryName, "Whitepaper.xml")))
                    {
                        result = false;
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// Reads the file depending on the value of the root elements.      
        /// If reading a Package it expects to find content (labs, ppts, etc) inside their corresponding folders and loads them.
        /// </summary>
        /// <param name="filePath"></param>
        /// <returns>It might return a Package, Unit, Sample, Lab, Demos, etc.</returns>
        public virtual EcfElement ReadEcfElementFromWorkingDirectory(string filePath)
        {
            XmlDocument metadata = new XmlDocument();
            metadata.Load(filePath);
            XmlNode rootElement = metadata.DocumentElement;

            EcfElement ecfElementRead = null;

            if (rootElement.Name.Equals(typeof(Package).Name))
            {
                ecfElementRead = this.ReadMetadataFromWorkingDirectory(filePath);
            }
            else
            {
                return this.ReadEcfElement(filePath);
            }
            
            return ecfElementRead;
        }

        /// <summary>
        /// Reads the file depending on the value of the root elements.       
        /// If reading a package it trys to load contentTypes directly from the specified path
        /// </summary>
        /// <param name="filePath"></param>
        /// <returns>It might return a Package, Unit, Sample, Lab, Demos, etc.</returns>
        public virtual EcfElement ReadEcfElement(string filePath)
        {
            XmlDocument metadata = new XmlDocument();
            metadata.Load(filePath);
            XmlNode rootElement = metadata.DocumentElement;

            EcfElement ecfElementRead = null;

            if (rootElement.Name.Equals(typeof(Package).Name))
            {
                ecfElementRead = this.ReadMetadata(filePath);
            }
            else if (rootElement.Name.Equals(typeof(Sample).Name))
            {
                ecfElementRead = this.ReadSample(filePath);
            }
            else if (rootElement.Name.Equals(typeof(Lab).Name))
            {
                ecfElementRead = this.ReadLab(filePath);
            }
            else if (rootElement.Name.Equals(typeof(Demo).Name))
            {
                ecfElementRead = this.ReadDemo(filePath);
            }
            else if (rootElement.Name.Equals(typeof(Video).Name))
            {
                ecfElementRead = this.ReadVideo(filePath);                
            }
            else if (rootElement.Name.Equals(typeof(Presentation).Name))
            {
                ecfElementRead = this.ReadPresentation(filePath);
            }
            else if (rootElement.Name.Equals(typeof(Whitepaper).Name))
            {
                ecfElementRead = this.ReadWhitepaper(filePath);
            }

            return ecfElementRead;
        }

        public virtual Package ReadMetadataFromWorkingDirectory(string filePath)
        {
            if (filePath == null)
            {
                throw new ArgumentNullException("filePath");
            }

            Package package = this.packageHelper.ReadMetadata(filePath);
            package.Location = filePath;

            foreach (Unit unit in package.Units)
            {
                string unitDirectory = Path.Combine(Path.GetDirectoryName(filePath), "Assets\\Overviews\\" + unit.Id);

                if (unit.Overview != null)
                {
                    unit.Overview.OriginalDirectory = unitDirectory;
                    unit.Overview.BasePath = unitDirectory;

                    if (unit.Overview.Document != null)
                    {
                        unit.Overview.Document.RelativePath = Path.GetFileName(unit.Overview.Document.RelativePath);
                    }
                }

                this.ReadUnitFromWorkingDirectory(unit, Path.GetDirectoryName(filePath));
            }

            return package;
        }
        
        public virtual void UpdateAssetPaths(string metadataPath, string oldAssetsPath)
        {
            var tags = "Thumbnail|Logo|LicenseAgreementFile|Icon|DocumentThumbnail|Document|VideoPlayerUrl";
            var newAssetsPath = "Assets";
            if (oldAssetsPath.EndsWith("\\", StringComparison.OrdinalIgnoreCase))
            {
                oldAssetsPath = oldAssetsPath.Substring(0, oldAssetsPath.Length - 1);
            }

            var oldFolder = Regex.Escape(oldAssetsPath);
            var regex = new Regex(@"(?<1><(?<tag>(" + tags + @")).*>)\.?\\?" + oldFolder + @"(?<2>[^>]*</\k<tag>>)", RegexOptions.IgnoreCase);
            
            var content = File.ReadAllText(metadataPath);
            content = regex.Replace(content, "$1" + newAssetsPath + "$2");

            File.WriteAllText(metadataPath, content);
        }

        public void ReadUnit(Unit unit, string contentDirectory)
        {
            foreach (string labDirectory in unit.LabDirectories)
            {
                unit.Labs.Add(this.ReadLab(GetElementFilePath(contentDirectory, labDirectory, "Lab.xml")));
            }

            foreach (string demoDirectory in unit.DemoDirectories)
            {
                unit.Demos.Add(this.ReadDemo(GetElementFilePath(contentDirectory, demoDirectory, "Demo.xml")));
            }

            foreach (string presentationDirectory in unit.PresentationDirectories)
            {
                unit.Presentations.Add(this.ReadPresentation(GetElementFilePath(contentDirectory, presentationDirectory, "Presentation.xml")));
            }

            foreach (string sampleDirectory in unit.SampleDirectories)
            {
                unit.Samples.Add(this.ReadSample(GetElementFilePath(contentDirectory, sampleDirectory, "Sample.xml")));
            }

            foreach (string videoDirectory in unit.VideoDirectories)
            {
                unit.Videos.Add(this.ReadVideo(GetElementFilePath(contentDirectory, videoDirectory, "Video.xml")));
            }

            foreach (string whitepaperDirectory in unit.WhitepaperDirectories)
            {
                unit.Whitepapers.Add(this.ReadWhitepaper(GetElementFilePath(contentDirectory, whitepaperDirectory, "Whitepaper.xml")));
            }
        }

        public void ReadUnitFromWorkingDirectory(Unit unit, string workingDirectory)
        {
            foreach (string labDirectory in unit.LabDirectories)
            {
                string labDirectoryName = (new System.IO.DirectoryInfo(labDirectory)).Name;
                unit.Labs.Add(this.ReadLab(GetElementFilePath(Path.Combine(workingDirectory, "Labs"), labDirectoryName, "Lab.xml")));
            }

            foreach (string demoDirectory in unit.DemoDirectories)
            {
                string demoDirectoryName = (new System.IO.DirectoryInfo(demoDirectory)).Name;
                unit.Demos.Add(this.ReadDemo(GetElementFilePath(Path.Combine(workingDirectory, "Demos"), demoDirectoryName, "Demo.xml")));
            }

            foreach (string presentationDirectory in unit.PresentationDirectories)
            {
                string presentationDirectoryName = (new System.IO.DirectoryInfo(presentationDirectory)).Name;
                unit.Presentations.Add(this.ReadPresentation(GetElementFilePath(Path.Combine(workingDirectory, "Presentations"), presentationDirectoryName, "Presentation.xml")));
            }

            foreach (string sampleDirectory in unit.SampleDirectories)
            {
                string sampleDirectoryName = (new System.IO.DirectoryInfo(sampleDirectory)).Name;
                unit.Samples.Add(this.ReadSample(GetElementFilePath(Path.Combine(workingDirectory, "Samples"), sampleDirectoryName, "Sample.xml")));
            }

            foreach (string videoDirectory in unit.VideoDirectories)
            {
                string videoDirectoryName = (new System.IO.DirectoryInfo(videoDirectory)).Name;
                unit.Videos.Add(this.ReadVideo(GetElementFilePath(Path.Combine(workingDirectory, "Videos"), videoDirectoryName, "Video.xml")));
            }

            foreach (string whitepaperDirectory in unit.WhitepaperDirectories)
            {
                string whitepaperDirectoryName = (new System.IO.DirectoryInfo(whitepaperDirectory)).Name;
                unit.Whitepapers.Add(this.ReadWhitepaper(GetElementFilePath(Path.Combine(workingDirectory, "Whitepapers"), whitepaperDirectoryName, "Whitepaper.xml")));
            }
        }

        public Lab ReadLab(string filePath)
        {
            Lab lab = this.labHelper.ReadMetadata(filePath);
            lab.OriginalDirectory = Path.GetDirectoryName(filePath);
            lab.BasePath = Path.GetDirectoryName(filePath);
            if (!string.IsNullOrEmpty(lab.Document.RelativePath) && !File.Exists(lab.Document.AbsolutePath))
            {
                throw new ContentFrameworkException("Lab document does not exist: " + lab.Document.AbsolutePath, "Verify the Lab.xml file has a 'Document' element pointing to the content file");
            }

            return lab;
        }

        public Demo ReadDemo(string filePath)
        {
            Demo demo = this.demoHelper.ReadMetadata(filePath);
            demo.OriginalDirectory = Path.GetDirectoryName(filePath);
            demo.BasePath = Path.GetDirectoryName(filePath);
            if (!string.IsNullOrEmpty(demo.Document.RelativePath) && !File.Exists(demo.Document.AbsolutePath))
            {
                throw new ContentFrameworkException("Demo document does not exist: " + demo.Document.AbsolutePath, "Verify the Demo.xml file has a 'Document' element pointing to the content file");
            }

            return demo;
        }

        public Sample ReadSample(string filePath)
        {
            Sample sample = this.sampleHelper.ReadMetadata(filePath);
            sample.OriginalDirectory = Path.GetDirectoryName(filePath);
            sample.BasePath = Path.GetDirectoryName(filePath);
            if (!string.IsNullOrEmpty(sample.Document.RelativePath) && !File.Exists(sample.Document.AbsolutePath))
            {
                throw new ContentFrameworkException("Sample document does not exist: " + sample.Document.AbsolutePath, "Verify the Sample.xml file has a 'Document' element pointing to the content file");
            }

            return sample;
        }

        public Presentation ReadPresentation(string filePath)
        {
            Presentation presentation = this.presentationHelper.ReadMetadata(filePath);
            presentation.OriginalDirectory = Path.GetDirectoryName(filePath);
            presentation.BasePath = Path.GetDirectoryName(filePath);
            if (!string.IsNullOrEmpty(presentation.Document.RelativePath) && !File.Exists(presentation.Document.AbsolutePath))
            {
                throw new ContentFrameworkException("Presentation does not exist: " + presentation.Document.AbsolutePath, "Verify the Presentation.xml file has a 'Document' element pointing to the content file");
            }

            return presentation;
        }

        public Video ReadVideo(string videoPath)
        {
            Video video = this.videoHelper.ReadMetadata(videoPath);
            video.OriginalDirectory = Path.GetDirectoryName(videoPath);
            video.BasePath = Path.GetDirectoryName(videoPath);
            if (string.IsNullOrEmpty(video.VideoUrl) &&
                !string.IsNullOrEmpty(video.Document.RelativePath) && 
                !File.Exists(video.Document.AbsolutePath))
            {
                throw new ContentFrameworkException("Video source does not exist", "Verify the Video.xml file has a 'Document' element pointing to the content file or remove its value if using a URL");
            }

            return video;
        }

        public Whitepaper ReadWhitepaper(string whitepaperPath)
        {
            Whitepaper whitepaper = this.whitepaperHelper.ReadMetadata(whitepaperPath);
            whitepaper.OriginalDirectory = Path.GetDirectoryName(whitepaperPath);
            whitepaper.BasePath = Path.GetDirectoryName(whitepaperPath);
            if (!File.Exists(whitepaper.Document.AbsolutePath))
            {
                throw new ContentFrameworkException("Whitepaper document does not exist", "Verify the Whitepaper.xml file has a 'Document' element pointing to the content file");
            }

            return whitepaper;
        }

        private static string GetElementFilePath(string contentDirectory, string elementDirectory, string elementFile)
        {
            string path = Path.Combine(contentDirectory, elementDirectory);
            string elementPath = path + @"\" + elementFile;
            DirectoryHelper.CheckPathTooLong(elementPath);

            return elementPath;
        }

        private void Settings_ValidationEventHandler(object sender, ValidationEventArgs e)
        {
            this.validXml = false;

            Logger.Log(LogLevel.Warning, e.Message);
        }
    }
}
