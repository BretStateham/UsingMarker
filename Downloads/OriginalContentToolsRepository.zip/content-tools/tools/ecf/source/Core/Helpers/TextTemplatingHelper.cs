﻿namespace Microsoft.Dpe.Ecf.Core.Helpers
{
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using Microsoft.Dpe.Ecf.Common.Helpers;
    using Microsoft.Dpe.Ecf.TextTemplating;

    public class TextTemplatingHelper
    {
        private SimpleTemplateProcessor templateProcessor;

        public TextTemplatingHelper() : this(new SimpleTemplateProcessor())
        {
        }

        internal TextTemplatingHelper(SimpleTemplateProcessor templateProcessor)
        {
            this.templateProcessor = templateProcessor;
        }

        public static string[] SearchTemplatesPattern()
        {
            return new string[] { "*.t4", "*.tt" };
        }

        public virtual void ProcessMultipleTemplates(string templatesDirectory, Dictionary<string, object> properties, string outputDirectory, string[] includeTemplates)
        {
            RecursiveSearchHelper searchHelper = new RecursiveSearchHelper();

            // Process navigation pages
            foreach (string templateFile in searchHelper.GetFiles(templatesDirectory, SearchTemplatesPattern(), includeTemplates))
            {
                string relativePath = Path.GetDirectoryName(templateFile).Substring(Path.GetFullPath(templatesDirectory).Length);
                this.ProcessSingleTemplate(templateFile, properties, string.Concat(outputDirectory, relativePath));
            }
        }

        public virtual void ProcessSingleTemplate(string templateFile, Dictionary<string, object> properties, string outputDirectory)
        {
            string processedContent = this.templateProcessor.Execute(properties, templateFile);
            if (this.templateProcessor.Errors.Count > 0)
            {
                throw new TextTemplatingException(string.Format(CultureInfo.CurrentCulture, "Template processing has failed: {0}", this.templateProcessor.ErrorsString));
            }

            string processedPage = Path.Combine(outputDirectory, string.Concat(Path.GetFileNameWithoutExtension(templateFile), ".htm"));

            this.WriteContentPage(processedPage, processedContent);
        }

        public virtual string ProcessSingleTemplate(string templateFile, Dictionary<string, object> properties)
        {
            string processedContent = this.templateProcessor.Execute(properties, templateFile);
            if (this.templateProcessor.Errors.Count > 0)
            {
                throw new TextTemplatingException(string.Format(CultureInfo.CurrentCulture, "Template processing has failed: {0}", this.templateProcessor.ErrorsString));
            }

            return processedContent;
        }

        protected virtual void WriteContentPage(string pageName, string content)
        {
            string pageDirectory = Path.GetDirectoryName(pageName);
            if (!Directory.Exists(pageDirectory))
            {
                Directory.CreateDirectory(pageDirectory);
            }
                
            File.WriteAllText(pageName, content);
        }
    }
}
