﻿namespace Microsoft.Dpe.Ecf.Core.Helpers
{
    using System.Collections.ObjectModel;
    using System.Xml.Linq;
    using Microsoft.Dpe.Ecf.Core.Models;

    internal class DocumentHelper
    {
        private Collection<MetadataProperty> properties;

        public DocumentHelper(string documentPath)
        {
            this.DocumentPath = documentPath;
        }
        
        /// <summary>
        /// List of properties to update.
        /// </summary>
        public Collection<MetadataProperty> Properties 
        {
            get
            {
                if (this.properties == null)
                {
                    this.properties = new Collection<MetadataProperty>();
                }

                return this.properties;
            }
        }

        /// <summary>
        /// Get or set the wordfile (full) filename.
        /// </summary>
        public string DocumentPath 
        { 
            get; 
            set;
        }

        protected virtual void UpdateProperty(XElement partProperties, MetadataProperty metadataProperty)
        {
            XElement element = partProperties.Element(metadataProperty.XWordProperty);

            if (element == null)
            {
                XElement newElement = new XElement(metadataProperty.XWordProperty);
                newElement.Value = metadataProperty.Value;

                partProperties.Add(newElement);
            }
            else
            {
                element.Value = metadataProperty.Value;
            }
        }
    }    
}
