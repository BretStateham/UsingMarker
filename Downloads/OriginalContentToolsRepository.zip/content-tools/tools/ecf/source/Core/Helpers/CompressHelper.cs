﻿namespace Microsoft.Dpe.Ecf.Core.Helpers
{
    using System;
    using System.Diagnostics;
    using System.IO;
    using System.Reflection;
    using System.Security;
    using System.Security.Permissions;
    using Microsoft.Dpe.Ecf.Common;
    using Microsoft.Dpe.Ecf.Core.Models;

    public class CompressHelper
    {
        private const string WinrarFilename = "winrar.exe";
        private const string DefaultSfxFilename = "Default.sfx";
        private readonly string WinrarWowInstallPath;
        private readonly string WinrarInstallPath;
        private readonly string WinrarBundlePath;

        public CompressHelper(
            string winrarBundlePath = @"Tools",
            string winrarInstallPath = @"%ProgramFiles%\WinRar",
            string winrarWowInstallPath = @"%ProgramFiles(x86)%\WinRar")
        {
            this.WinrarBundlePath = winrarBundlePath;
            this.WinrarInstallPath = winrarInstallPath;
            this.WinrarWowInstallPath = winrarWowInstallPath;
        }

        protected string SelfExtractToolPath { get; set; }

        public string GetWinrarInstallPath()
        {
            var assemblyFolder = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            var toolsFolder = Path.Combine(assemblyFolder, this.WinrarBundlePath);
            var bundleWinrar = Environment.ExpandEnvironmentVariables(
                Path.Combine(toolsFolder, WinrarFilename));

            if (File.Exists(bundleWinrar))
            {
                return bundleWinrar;
            }

            var installedWinrar = Environment.ExpandEnvironmentVariables(
                Path.Combine(this.WinrarInstallPath, WinrarFilename));
            if (File.Exists(installedWinrar))
            {
                return installedWinrar;
            }

            var installedWowWinrar = Environment.ExpandEnvironmentVariables(
                Path.Combine(this.WinrarWowInstallPath, WinrarFilename));
            if (File.Exists(installedWowWinrar))
            {
                return installedWowWinrar;
            }

            return null;
        }

        public virtual void LoadTool()
        {
            Logger.Log(LogLevel.Information, "Compress Helper: Load Tool");

            var winrarPath = this.GetWinrarInstallPath();

            if (string.IsNullOrEmpty(winrarPath) || !File.Exists(winrarPath))
            {
                throw new ContentFrameworkException("Could not find WinRAR executable path", "You need to install latest WinRAR version to generate ECF packages");
            }

            this.SelfExtractToolPath = winrarPath;
        }

        [PermissionSet(SecurityAction.LinkDemand)]
        public virtual void GenerateSelfExtract(SelfExtractMetadata data)
        {
            Logger.Log(LogLevel.Information, "Generate Self Extract");
            Logger.Log(LogLevel.Debug, string.Format("Self Extract Tool Path: {0}", this.SelfExtractToolPath));
            Logger.Log(LogLevel.Debug, string.Format("Working Directory: {0}", data.FolderToCompress));

            if (!string.IsNullOrEmpty(data.OutputDirectory) &&
                !Directory.Exists(data.OutputDirectory))
            {
                Logger.Log(LogLevel.Debug, string.Format("Creating Output Directory: {0}", data.OutputDirectory));
                Directory.CreateDirectory(data.OutputDirectory);
            }

            using (var process = new Process())
            {
                process.StartInfo = new ProcessStartInfo()
                {
                    FileName = this.SelfExtractToolPath,
                    WindowStyle = ProcessWindowStyle.Hidden,
                    WorkingDirectory = data.FolderToCompress,
                };

                var builder = new CompressArgumentsBuilder();

                builder.Command = CompressCommands.AddToAnArchive;
                builder.CreateSelfExtracting = true;
                builder.RecurseFolders = true;
                builder.AssumeYesOnQueries = true;

                builder.OutputFileName = Path.Combine(data.OutputDirectory, data.Name);
                builder.CommentsFileName = Path.GetFileName(data.LicenseAgreementFile);

                builder.ImageFileName = data.ImageFile;
                builder.ExcludeFileName = data.ExcludeFiles;

                process.StartInfo.Arguments = builder.ToString();
                Logger.Log(LogLevel.Debug, string.Format("Self Extract Tool Arguments: {0}", process.StartInfo.Arguments));

                process.Start();

                // 30 Minutes Timeout
                process.WaitForExit(1000 * 60 * 30);

                if (!process.HasExited)
                {
                    process.Kill();
                    throw new ContentFrameworkException("Compression Process have not been completed in the allocated timout time.", "Please try again the build process, if the content is too large, consider increasing the timeout value");
                }
            }
        }

        [PermissionSet(SecurityAction.LinkDemand)]
        public virtual void GenerateZip(SelfExtractMetadata data)
        {
            using (var process = new Process())
            {
                process.StartInfo = new ProcessStartInfo()
                {
                    FileName = this.SelfExtractToolPath,
                    WindowStyle = ProcessWindowStyle.Hidden,
                    WorkingDirectory = data.FolderToCompress,
                };

                var builder = new CompressArgumentsBuilder();

                builder.Command = CompressCommands.AddToAnArchive;
                builder.CreateSelfExtracting = false;
                builder.RecurseFolders = true;
                builder.AssumeYesOnQueries = true;

                builder.OutputFileName = Path.Combine(data.OutputDirectory, data.Name);
                builder.CommentsFileName = Path.GetFileName(data.LicenseAgreementFile);

                builder.ImageFileName = data.ImageFile;
                builder.ExcludeFileName = data.ExcludeFiles;

                process.StartInfo.Arguments = builder.ToString();
                process.Start();

                // 30 Minutes Timeout
                process.WaitForExit(1000 * 60 * 30);

                if (!process.HasExited)
                {
                    process.Kill();
                    throw new ContentFrameworkException("Compression Process have not been completed in the allocated timout time.", "Please try again the build process, if the content is too large, consider increasing the timeout value");
                }
            }
        }
    }
}
