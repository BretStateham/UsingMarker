﻿namespace ContentFramework.Core.Helpers
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Text.RegularExpressions;
    using ContentFramework.Core.Models;

    public static class PublishLabStepHelper
    {
        public static string GetInnerHtml(string htmlText, string tagName)
        {
            if (htmlText == null)
            {
                throw new ArgumentNullException("htmlText");
            }

            int ptag = htmlText.IndexOf("<" + tagName, StringComparison.OrdinalIgnoreCase);

            if (ptag < 0)
            {
                return htmlText;
            }

            int ptag1 = htmlText.IndexOf(">", ptag, StringComparison.OrdinalIgnoreCase);

            int ptag2 = htmlText.IndexOf("</" + tagName, StringComparison.OrdinalIgnoreCase);

            return htmlText.Substring(ptag1 + 1, ptag2 - ptag1 - 1);
        }

        public static string GetTitleContent(string htmlText)
        {
            return GetInnerHtml(htmlText, "title");
        }

        public static string GetBodyContent(string htmlText)
        {
            return GetInnerHtml(htmlText, "body");
        }

        public static string ChangeTopicLinks(string content, Dictionary<string, PublishedPost> publishedPosts)
        {
            foreach (string filePath in publishedPosts.Keys)
            {
                content = Regex.Replace(content, Path.GetFileName(filePath), publishedPosts[filePath].PostUri.ToString(), RegexOptions.IgnoreCase);
            }

            return content;
        }

        public static string ChangeImagesLinks(string content, Dictionary<string, string> uploadedImages)
        {
            foreach (string imageName in uploadedImages.Keys)
            {
                content = Regex.Replace(content, @"images\\" + imageName, uploadedImages[imageName], RegexOptions.IgnoreCase);
            }

            return content;
        }

        public static string ChangeLocalFilesLinks(string content, Dictionary<string, string> uploadedLocalFiles)
        {
            foreach (string fileName in uploadedLocalFiles.Keys)
            {
                content = Regex.Replace(content, "src=\"../local/" + fileName, "src=\"" + uploadedLocalFiles[fileName], RegexOptions.IgnoreCase);
            }

            return content;
        }        
    }
}
