﻿namespace Microsoft.Dpe.Ecf.Core.Helpers
{
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.IO;
    using System.Xml;
    using Microsoft.Dpe.Ecf.Common;
    using Microsoft.Dpe.Ecf.Core.Models;
    using Microsoft.Dpe.Ecf.Model;
    using Microsoft.Practices.DocxConverter;

    internal class ConvertHelper
    {
        public static void Convert(ConvertibleDocument document)
        {
            Convert(document, null);
        }

        public static void Convert(ConvertibleDocument document, string xsltPath)             
        {
            Convert(document, xsltPath, null);
        }

        public static void Convert(ConvertibleDocument document, string xsltPath, DocToolsConfig configuration)
        {
            Convert(document, xsltPath, configuration, false);
        }

        public static void Convert(ConvertibleDocument document, string xsltPath, DocToolsConfig configuration, bool useTocFile)
        {
            if (!string.IsNullOrEmpty(document.RelativePath))
            {
                string outputName = "Default";

                if ((document.ConversionType & ConversionType.Html) == ConversionType.Html)
                {
                    var destinationFolder = document.HtmlFolder;

                    DocumentTopic[] topics = ConvertToHtml(document.AbsolutePath, xsltPath, destinationFolder, configuration, useTocFile);

                    foreach (var item in topics)
                    {
                        document.Topics.Add(item);
                    }

                    // document.Topics.AddRange(topics);
                    // this is to avoid naming collisions if converting to both Html and HtmlSinglePage (docSet_Default.html != docSet_Lab.html)
                    outputName = Path.GetFileNameWithoutExtension(document.RelativePath);
                }

                if ((document.ConversionType & ConversionType.HtmlSinglePage) == ConversionType.HtmlSinglePage)
                {
                    var destinationFolder = document.HtmlFolder;

                    DocumentTopic topic = ConvertToSingleHtml(document.AbsolutePath, xsltPath, destinationFolder, outputName, configuration);

                    // document.Topics.AddLast(topic);
                    document.Topics.Add(topic);
                }
            }
        }

        private static DocumentTopic[] ConvertToHtml(string documentFullPath, string xsltPath, string outputFolder, DocToolsConfig configuration, bool useTocFile)
        {
            string documentFolder = Path.GetDirectoryName(documentFullPath);

            // By default output folder is always html
            if (string.IsNullOrEmpty(outputFolder))
            {
                outputFolder = Path.GetFileNameWithoutExtension(documentFullPath) + ".html";
            }

            string outputPath = Path.Combine(documentFolder, outputFolder);

            // Create the config file for DocTools
            string configFile = CreateConfigFile(configuration, xsltPath);

            Logger.Log(LogLevel.Debug, "Converting document to HTML in output folder " + outputPath);
            Logger.IncreaseIndent();

            // Convert the document to html
            string[] excludes = Properties.Resources.defaultExcludePattern.Split(" ".ToCharArray());
            HtmlConverter htmlConverter = new HtmlConverter();
            Collection<string> topics = htmlConverter.Convert(documentFullPath, xsltPath, outputPath, configFile, null, excludes, useTocFile);

            List<DocumentTopic> documentTopics = new List<DocumentTopic>();            
            foreach (string topic in topics)
            {
                documentTopics.Add(new DocumentTopic(topic));
            }

            Logger.DecreaseIndent();

            if (File.Exists(configFile))
            {
                File.Delete(configFile);
            }

            return documentTopics.ToArray();
        }

        private static DocumentTopic ConvertToSingleHtml(string documentFullPath, string xsltPath, string outputFolder, string defaultName, DocToolsConfig configuration)
        {
            string documentFolder = Path.GetDirectoryName(documentFullPath);

            // By default output folder is always html
            if (string.IsNullOrEmpty(outputFolder))
            {
                outputFolder = Path.GetFileNameWithoutExtension(documentFullPath) + ".html";
            }

            string outputPath = Path.Combine(documentFolder, outputFolder);

            // Create the config file for DocTools
            string configFile = CreateConfigFile(configuration, xsltPath);

            Logger.Log(LogLevel.Debug, "Converting document to a single HTML in output folder " + outputPath);
            Logger.IncreaseIndent();

            // Convert the document to html
            string[] excludes = Properties.Resources.defaultExcludePattern.Split(" ".ToCharArray());
            SingleHtmlConverter htmlConverter = new SingleHtmlConverter();
            htmlConverter.DefaultName = defaultName;
            string topic = htmlConverter.Convert(documentFullPath, xsltPath, outputPath, configFile, null, excludes);

            DocumentTopic documentTopic = new DocumentTopic(topic);

            Logger.DecreaseIndent();

            if (File.Exists(configFile))
            {
                File.Delete(configFile);
            }

            return documentTopic;
        }

        private static string CreateConfigFile(DocToolsConfig configuration, string xsltPath)
        {
            if (configuration == null)
            {
                return null;
            }

            // Read default config
            if (string.IsNullOrEmpty(xsltPath))
            {
                xsltPath = Path.GetFullPath("Formatting\\MSDN2\\xsl");
            }
                       
            string ecfConfigFile = Path.Combine(xsltPath, "ppdocConfig.xml");

            // read ecfConfigFile            
            XmlDocument configFileXml = new XmlDocument();
            configFileXml.Load(ecfConfigFile);
            if (!String.IsNullOrEmpty(configuration.Header))
            {
                configFileXml.SelectSingleNode("/options/header").InnerText = configuration.Header;
            }

            if (!String.IsNullOrEmpty(configuration.Copyright))
            {
                configFileXml.SelectSingleNode("/options/copyright").InnerText = configuration.Copyright;
            }

            if (!String.IsNullOrEmpty(configuration.Feedback))
            {
                configFileXml.SelectSingleNode("/options/feedback").InnerText = configuration.Feedback;
            }

            // save in a temporary file
            string createdConfigFile = Path.GetTempFileName();
            configFileXml.Save(createdConfigFile);

            return createdConfigFile;
        }
    }
}
