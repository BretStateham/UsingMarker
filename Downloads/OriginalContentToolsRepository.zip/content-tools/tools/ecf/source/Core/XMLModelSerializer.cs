﻿namespace Microsoft.Dpe.Ecf.Core
{
    using System;
    using System.IO;
    using System.Runtime.Serialization;
    using System.Text;
    using System.Xml.Serialization;
    using Microsoft.Dpe.Ecf.Model;

    internal class XMLModelSerializer<TModel> : IModelSerializer<TModel>
    {
        public virtual TModel Deserialize(FileStream stream)
        {
            TModel result = default(TModel);
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(TModel));
                result = (TModel)serializer.Deserialize(stream);

                // set the base path
                Package package = result as Package;
                if (package != null && package.Overview != null)
                {
                    package.Overview.BasePath = Path.GetDirectoryName(stream.Name);
                }

                DocumentMetadata document = result as DocumentMetadata;
                if (document != null)
                {
                    document.BasePath = Path.GetDirectoryName(stream.Name);
                }
            }
            catch (Exception e)
            {
                StringBuilder builder = new StringBuilder();
                builder.AppendLine("There was a problem deserializing file: " + Path.GetFullPath(stream.Name));
                builder.AppendLine("Check that XML is well formed");
                throw new SerializationException(builder.ToString(), e);
            }
          
            return result;
        }

        public virtual Stream Serialize(TModel model)
        {
            var stream = new MemoryStream();
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(TModel));
                serializer.Serialize(stream, model);
            }
            catch (Exception e)
            {
                StringBuilder builder = new StringBuilder();
                if (model != null)
                {
                    builder.AppendLine("There was a problem serializing " + model.GetType().Name + " class");
                }
                else
                {
                    builder.AppendLine("There was a problem serializing. Trying to serialize null.");
                }

                throw new SerializationException(builder.ToString(), e);
            }

            return stream;
        }

        ////public static bool Validate(FileStream stream)
        ////{
        ////    var isValid = false;
        ////    var xsc = new XmlSchemaCollection();

        ////    xsc.Add(

        ////    try
        ////    {
        ////        if(stream != null) 
        ////        {
        ////            var vreader = new XmlValidatingReader(stream, XmlNodeType.Element, null);
        ////            vreader.Schemas.Add(xsc);
                    
        ////            while (vreader.Read())
        ////                    isValid = true;
        ////        }
        ////    }
        ////    catch (Exception)
        ////    {
        ////        isValid = false;
        ////    }

        ////    return isValid;
        ////}
    }
}
