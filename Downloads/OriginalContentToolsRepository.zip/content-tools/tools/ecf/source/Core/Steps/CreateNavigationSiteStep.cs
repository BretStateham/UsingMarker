﻿namespace Microsoft.Dpe.Ecf.Core.Steps
{
    using System;
    using System.Collections.Generic;
    using Microsoft.Dpe.Ecf.Common;
    using Microsoft.Dpe.Ecf.Common.Helpers;
    using Microsoft.Dpe.Ecf.Core.Helpers;
    using Microsoft.Dpe.Ecf.Model;

    public class CreateNavigationSiteStep
    {
        private TextTemplatingHelper templatingHelper;
        
        public CreateNavigationSiteStep() : this(new TextTemplatingHelper())
        {
        }

        internal CreateNavigationSiteStep(TextTemplatingHelper templatingHelper)
        {
            this.templatingHelper = templatingHelper;
        }

        public string TemplatesDirectory
        {
            get;
            set;
        }

        public Package Package
        {
            get;
            set;
        }

        public string PackagePath
        {
            get;
            set;
        }

        public Dictionary<string, object> TemplateProperties
        {
            get; 
            set;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1819:PropertiesShouldNotReturnArrays", Justification = "Design decision for simplicity")]
        public string[] IncludeTemplates
        {
            get;
            set;
        }

        public virtual void Execute()
        {
            if (this.Package == null)
            {
                throw new ArgumentException("Package must be provided");
            }

            if (this.TemplateProperties == null)
            {
                this.TemplateProperties = new Dictionary<string, object>();
            }

            Logger.Log(LogLevel.Information, "Create Navigation Site Step: Execute");
            Logger.Log(LogLevel.Debug, string.Format("TemplatesDirectory: {0}", this.TemplatesDirectory));
            Logger.Log(LogLevel.Debug, string.Format("Package Path: {0}", this.PackagePath));
            Logger.Log(LogLevel.Debug, string.Format("Include Templates: {0}", this.IncludeTemplates));

            if (this.TemplateProperties != null && this.TemplateProperties.Count > 0) 
            {
                Logger.Log(LogLevel.Debug, "Templates Properties:");
                Logger.IncreaseIndent();

                foreach (string key in this.TemplateProperties.Keys)
                {
                    Logger.Log(LogLevel.Debug, string.Format("{0}: {1}", key, this.TemplateProperties[key]));
                }

                Logger.DecreaseIndent();
            }

            this.TemplateProperties.Add("Package", this.Package);

            // Process navigation templates
            this.templatingHelper.ProcessMultipleTemplates(this.TemplatesDirectory, this.TemplateProperties, this.PackagePath, this.IncludeTemplates);

            // Copy images and css directories
            this.CreateSupportDirectories();

            Logger.Log(LogLevel.Information, "Create Navigation Site Step: Done");
        }

        protected virtual void CreateSupportDirectories()
        {
            Logger.Log(LogLevel.Information, "Create Support Directories");
            List<string> excludes = new List<string>(Properties.Resources.defaultExcludePattern.Split(" ".ToCharArray()));
            excludes.AddRange(TextTemplatingHelper.SearchTemplatesPattern());

            DirectoryHelper.CopyDirectory(this.TemplatesDirectory, this.PackagePath, excludes.ToArray());
        }
    }
}
