﻿namespace Microsoft.Dpe.Ecf.Core.Steps
{
    using System;
    using System.IO;
    using Microsoft.Dpe.Ecf.Common;
    using Microsoft.Dpe.Ecf.Core.Helpers;
    using Microsoft.Dpe.Ecf.Model;    

    /// <summary>
    /// Converts the Document Specified in DocumentPath Propery to the format specified by ConvertionType Property
    /// OBLIGATORY PARAMETERS:  - DocumentPath
    ///                         - ConversionType    Html|Mht|None
    ///                         
    /// OPTIONAL PARAMETERS:
    ///                         - OutputFolderPath  DEFAULT: DocumentName.html
    ///                         - XsltPath          DEFAULT: null
    /// 
    /// </summary>
    public class ConvertDocumentStep
    {
        public ConvertDocumentStep(string documentPath, string conversionType)
            : this(documentPath, conversionType, string.Empty)
        {
        }

        public ConvertDocumentStep(string documentPath, string conversionType, string xsltPath)
            : this(documentPath, conversionType, xsltPath, false)
        {
        }

        public ConvertDocumentStep(string documentPath, string conversionType, string xsltPath, bool useTocFile)
        {
            this.ConversionType = ParseConvertionType(conversionType);
            this.DocumentPath = documentPath;
            this.XsltPath = xsltPath;
            this.UseTocFile = useTocFile;

            this.ValidateParameters();
        }

        private string DocumentPath
        {
            get;
            set;
        }

        private ConversionType ConversionType
        {
            get;
            set;
        }

        private string XsltPath
        {
            get;
            set;
        }

        private bool UseTocFile
        {
            get;
            set;
        }

        public virtual void Execute()
        {
            // create document to be converted
            ConvertibleDocument document = new ConvertibleDocument();
            document.RelativePath = this.DocumentPath;
            document.ConversionType = this.ConversionType;

            // convert the document
            ConvertHelper.Convert(document, this.XsltPath, null, this.UseTocFile);

            if (document.ExcludeSource)
            {
                if (File.Exists(document.AbsolutePath))
                {
                    Logger.Log(LogLevel.Information, "Removing source document " + document.RelativePath + "...");
                    File.Delete(document.AbsolutePath);
                }
            }

            if ((document.ConversionType & ConversionType.Html) == ConversionType.Html ||
                (document.ConversionType & ConversionType.HtmlSinglePage) == ConversionType.HtmlSinglePage)
            {
                // validate the content was converted
                var resultsDir = Path.Combine(document.AbsoluteHtmlPath, "html");

                if (Directory.Exists(resultsDir))
                {
                    if ((new DirectoryInfo(resultsDir)).GetFiles("*.html").Length < 1)
                    {
                        Logger.Log(LogLevel.Warning, "Document " + document.RelativePath + " was not converted! Verify the document content is using the docTools styles.");
                    }
                }
            }
        }

        private static ConversionType ParseConvertionType(string conversionType)
        {
            ConversionType convType = ConversionType.None;

            string[] types = conversionType.Split(", ".ToCharArray());

            foreach (var ctype in types)
            {
                switch (ctype.Trim().ToUpperInvariant())
                {
                    case "HTML":
                        convType |= ConversionType.Html;
                        break;
                    case "HTMLSINGLEPAGE":
                    case "SINGLEHTMLPAGE":
                    case "SINGLEHTML":
                        convType |= ConversionType.HtmlSinglePage;
                        break;
                    case "PDF":
                        convType |= ConversionType.Pdf;
                        break;
                    case "NONE":
                        convType = ConversionType.None;
                        break;
                    case "":
                        break;
                    default:
                        throw new ArgumentException("Invalid convertion: " + conversionType + ". Convertion must be Html, HtmlSinglePage, Pdf or None");
                }
            }

            return convType;
        }

        private void ValidateParameters()
        {
            // Document Path
            if (String.IsNullOrEmpty(this.DocumentPath))
            {
                throw new ArgumentException("Document Path should be specified");
            }

            if (!File.Exists(this.DocumentPath))
            {
                throw new ArgumentException("Document File can not be found: " + Path.GetFullPath(this.DocumentPath));
            }

            // XSLT Path, if specified, check existance
            if (!String.IsNullOrEmpty(this.XsltPath)) 
            {
                if (!Directory.Exists(this.XsltPath))
                {
                    throw new ArgumentException("XSLT directory can not be found: " + this.XsltPath);
                }

                this.XsltPath = Path.GetFullPath(this.XsltPath);
            }
        }
    }
}
