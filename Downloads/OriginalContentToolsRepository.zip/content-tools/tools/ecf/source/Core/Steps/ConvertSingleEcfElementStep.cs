﻿namespace Microsoft.Dpe.Ecf.Core.Steps
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Xml.Serialization;
    using Microsoft.Dpe.Ecf.Common;
    using Microsoft.Dpe.Ecf.Core.Helpers;
    using Microsoft.Dpe.Ecf.Core.Models;
    using Microsoft.Dpe.Ecf.Model;

    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1704:IdentifiersShouldBeSpelledCorrectly", MessageId = "Ecf", Justification = "ECF is for Evangelism content framework")]
    public class ConvertSingleEcfElementStep<T> where T : EcfElement, new()
    {        
        public ConvertSingleEcfElementStep(ConvertibleDocument document, string xsltPath, DocToolsConfig config)
            : this(document, xsltPath, config, false, string.Empty)
        {
        }
        
        public ConvertSingleEcfElementStep(ConvertibleDocument document, string xsltPath, DocToolsConfig config, bool useTocFile, string conversionType)
        {
            this.Document = document;
            this.DocToolsConfig = config;
            this.XsltPath = xsltPath;
            this.UseTocFile = useTocFile;
            this.IncludeConversionType = conversionType;

            // Check the correctness of parameters
            this.CheckParameters();
        }
        
        public DocToolsConfig DocToolsConfig
        {
            get;
            set;
        }

        public ConvertibleDocument Document
        {
            get;
            set;
        }

        private bool UseTocFile
        {
            get;
            set;
        }

        private string XsltPath
        {
            get;
            set;
        }

        private string IncludeConversionType
        {
            get;
            set;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily", Justification = "Double cast is needed due to generics")]
        public virtual void Execute() 
        {            
            // convert word 2007/2010 documents only
            if (Path.GetExtension(this.Document.RelativePath).Equals(".DOCX", StringComparison.OrdinalIgnoreCase))
            {
                if (!string.IsNullOrEmpty(this.IncludeConversionType))
                {
                    this.Document.ConversionType |= ParseConvertionType(this.IncludeConversionType);
                }

                ConvertHelper.Convert(this.Document, this.XsltPath, this.DocToolsConfig, this.UseTocFile);
                SerializeToc(this.Document);

                if (this.Document.ExcludeSource)
                {
                    if (File.Exists(this.Document.AbsolutePath))
                    {
                        File.Delete(this.Document.AbsolutePath);
                    }
                }

                if ((this.Document.ConversionType & ConversionType.Html) == ConversionType.Html || (this.Document.ConversionType & ConversionType.HtmlSinglePage) == ConversionType.HtmlSinglePage)
                {
                    // validate the content was converted
                    var resultsDir = Path.Combine(this.Document.AbsoluteHtmlPath, "html");

                    if (Directory.Exists(resultsDir))
                    {
                        if ((new DirectoryInfo(resultsDir)).GetFiles("*.html").Length < 1)
                        {
                            Logger.Log(LogLevel.Warning, "Document " + this.Document.RelativePath + " was not converted! Verify the document content is using the docTools styles.");
                        }
                    }
                }
            }
        }

        private static ConversionType ParseConvertionType(string conversionType)
        {
            ConversionType convType = ConversionType.None;

            string[] types = conversionType.Split(", ".ToCharArray());

            foreach (var ctype in types)
            {
                switch (ctype.Trim().ToUpperInvariant())
                {
                    case "HTML":
                        convType |= ConversionType.Html;
                        break;
                    case "HTMLSINGLEPAGE":
                    case "SINGLEHTMLPAGE":
                    case "SINGLEHTML":
                        convType |= ConversionType.HtmlSinglePage;
                        break;
                    case "PDF":
                        convType |= ConversionType.Pdf;
                        break;
                    case "NONE":
                        convType = ConversionType.None;
                        break;
                    case "":
                        break;
                    default:
                        throw new ArgumentException("Invalid convertion: " + conversionType + ". Convertion must be Html, HtmlSinglePage, Mht, Pdf, Xps or None");
                }
            }

            return convType;
        }

        private static void SerializeToc(ConvertibleDocument document)
        {
            if ((document.ConversionType & ConversionType.Html) == ConversionType.Html)
            {
                var tocPath = Path.Combine(document.BasePath, "Topics.xml");

                if (!File.Exists(tocPath))
                {
                    var stream = File.Open(tocPath, FileMode.CreateNew, FileAccess.Write, FileShare.Read); // var writer = new StreamWriter(tocPath);
                    var serializer = new XmlSerializer(typeof(List<DocumentTopic>));

                    serializer.Serialize(stream, document.Topics);
                    stream.Close();
                }
            }
        }
        
        private void CheckParameters()
        {
            // XSLT Path, if specified, check existance
            if (!String.IsNullOrEmpty(this.XsltPath)) 
            {
                if (!Directory.Exists(this.XsltPath))
                {
                    throw new ArgumentException("XSLT File can not be found: " + this.XsltPath);
                }

                this.XsltPath = Path.GetFullPath(this.XsltPath);
            }
        }
    }
}
