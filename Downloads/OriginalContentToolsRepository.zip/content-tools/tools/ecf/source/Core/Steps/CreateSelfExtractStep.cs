﻿namespace Microsoft.Dpe.Ecf.Core.Steps
{
    using System;
    using System.Globalization;
    using System.IO;
    using System.Security;
    using System.Security.Permissions;
    using System.Text;
    using Microsoft.Dpe.Ecf.Common;
    using Microsoft.Dpe.Ecf.Core.Helpers;
    using Microsoft.Dpe.Ecf.Core.Models;

    public class CreateSelfExtractStep
    {
        private CompressHelper compressHelper;

        public CreateSelfExtractStep()
            : this(new CompressHelper())
        {
        }

        internal CreateSelfExtractStep(CompressHelper compressHelper)
        {
            this.compressHelper = compressHelper;
        }

        public SelfExtractMetadata Metadata
        {
            get;
            set;
        }

        [PermissionSet(SecurityAction.LinkDemand)]
        public virtual void Execute()
        {
            if (this.Metadata == null)
            {
                throw new ArgumentNullException("Metadata cannot be null.");
            }

            Logger.Log(LogLevel.Information, "Create Self Extract Step: Execute");

            this.compressHelper.LoadTool();

            if (this.Metadata.Package != null)
            {
                if (!string.IsNullOrEmpty(this.Metadata.Package.LicenseAgreementFile))
                {
                    if (File.Exists(this.Metadata.Package.LicenseAgreementFile))
                    {
                        this.Metadata.LicenseAgreementFile = this.Metadata.Package.LicenseAgreementFile;
                    }
                    else
                    {
                        throw new ArgumentException("The license agreement file does not exist.");
                    }
                }
            }
            else
            {
                if (this.Metadata.Sample != null)
                {
                    if (!string.IsNullOrEmpty(this.Metadata.Sample.LicenseAgreementFile))
                    {
                        if (File.Exists(this.Metadata.Sample.LicenseAgreementFile))
                        {
                            this.Metadata.LicenseAgreementFile = this.Metadata.Sample.LicenseAgreementFile;
                        }
                        else
                        {
                            throw new ArgumentException("The license agreement file does not exist.");
                        }
                    }
                }
            }

            // this.Metadata.FolderToCompress = Path.GetFullPath(Path.Combine(this.Metadata.FolderToCompress ?? string.Empty, this.Metadata.Package.Id));
            this.Metadata.FolderToCompress = Path.GetFullPath(this.Metadata.FolderToCompress ?? string.Empty);
            this.Metadata.OutputDirectory = Path.GetFullPath(this.Metadata.OutputDirectory ?? string.Empty);

            if (!String.IsNullOrEmpty(this.Metadata.LicenseAgreementFile))
            {
                this.CreateCommentsFile();
            }

            if (!string.IsNullOrEmpty(this.Metadata.Name))
            {
                this.ExcludeFile(Path.Combine(this.Metadata.OutputDirectory, this.Metadata.Name));
            }

            this.compressHelper.GenerateSelfExtract(this.Metadata);
        }

        protected virtual void CreateCommentsFile()
        {
            if (this.Metadata.Package != null)
            {
                this.CreateCommentsFile(
                    this.Metadata.Package.Id.Replace(" ", "_"),
                    this.Metadata.Package.Name,
                    this.Metadata.Package.Description,
                    this.Metadata.Package.Overview.Description);
            }
            else if (this.Metadata.Sample != null)
            {
                this.CreateCommentsFile(
                    this.Metadata.Sample.Id.Replace(" ", "_"),
                    this.Metadata.Sample.Title,
                    this.Metadata.Sample.Description,
                    this.Metadata.Sample.Description);
            }
            else
            {
                string folderName = Path.GetFileName(this.Metadata.FolderToCompress);
                this.CreateCommentsFile(folderName, folderName, string.Empty, string.Empty);
            }
        }

        protected virtual void ExcludeFile(string filePath)
        {
            if (File.Exists(filePath))
            {
                Logger.Log(LogLevel.Debug, string.Format("Exclude File: {0}", filePath));
                File.Delete(filePath);
            }
        }

        private void CreateCommentsFile(string installFolder, string title, string description, string tooltip)
        {
            Logger.Log(LogLevel.Information, "Create Self Extract Step: Create Comments File");

            Logger.Log(LogLevel.Debug, string.Format("Install Folder: {0}", installFolder));
            Logger.Log(LogLevel.Debug, string.Format("Title: {0}", title));
            Logger.Log(LogLevel.Debug, string.Format("Description: {0}", description));

            string license = File.ReadAllText(this.Metadata.LicenseAgreementFile, Encoding.Default);
            string comments = Properties.Resources.CommentsTemplate;
            string finalPath = Path.Combine(this.Metadata.FolderToCompress, "Comments.txt");

            StringBuilder pathBuilder = new StringBuilder("C:\\");
            pathBuilder.Append(installFolder);

            string setup = @"explorer .\";
            if (!String.IsNullOrEmpty(this.Metadata.StartCommand))
            {
                setup = this.Metadata.StartCommand;
            }
            else
            {
                if (File.Exists(Path.Combine(this.Metadata.FolderToCompress, "default.htm")))
                {
                    setup = "explorer default.htm";
                }
            }

            Logger.Log(LogLevel.Debug, string.Format("Start Command: {0}", setup));

            license = license.Replace("{title}", title);
            var shortcut = this.BuildShortcutInfo(title, tooltip);
            Logger.Log(LogLevel.Debug, string.Format("Build Shortcut Info: {0}", shortcut));

            comments = String.Format(
                CultureInfo.InvariantCulture,
                comments,
                pathBuilder,
                title,
                description,
                license,
                setup,
                shortcut);

            File.WriteAllText(finalPath, comments, Encoding.Default);

            this.Metadata.LicenseAgreementFile = finalPath;
        }

        private string BuildShortcutInfo(string name, string description)
        {
            var iconFile = string.Empty;
            var shortcut = string.Empty;

            // TODO: add support for icons in Sample.xml 
            if (this.Metadata.Package != null)
            {
                if (!string.IsNullOrEmpty(this.Metadata.Package.Icon))
                {
                    iconFile = ", " + this.Metadata.Package.Icon;
                }
            }

            if (!string.IsNullOrEmpty(this.Metadata.ShortcutFile))
            {
                shortcut = string.Format(
                        CultureInfo.InvariantCulture,
                        @"Shortcut=D, {0}, , ""{1}"", ""{2}""{3}",
                        this.Metadata.ShortcutFile,
                        description,
                        name,
                        iconFile);
            }

            return shortcut;
        }
    }
}
