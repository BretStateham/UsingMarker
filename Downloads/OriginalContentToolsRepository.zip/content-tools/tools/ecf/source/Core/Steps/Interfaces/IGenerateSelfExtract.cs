﻿namespace Microsoft.Dpe.Ecf.Core.Steps
{
    using System.Collections.ObjectModel;
    using Microsoft.Dpe.Ecf.Core.Helpers;
    using Microsoft.Dpe.Ecf.Core.Models;

    public interface IGenerateSelfExtract
    {
        IGenerateSelfExtract SelfExtractOperator
        {
            get;
            set;
        }

        SelfExtractMetadata Metadata
        {
            get;
            set;
        }

        void Execute(CompressHelper compressHelper, Collection<string> elements);
    }
}
