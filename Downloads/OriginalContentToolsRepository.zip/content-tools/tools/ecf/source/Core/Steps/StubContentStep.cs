﻿namespace Microsoft.Dpe.Ecf.Core.Steps
{
    using System.IO;
    using Microsoft.Dpe.Ecf.Common;
    using Microsoft.Dpe.Ecf.Core.Helpers;
    using Microsoft.Dpe.Ecf.Model;

    public class StubContentStep
    {
        private MetadataHelper packageHelper;

        public StubContentStep()
            : this(new MetadataHelper())
        {
        }

        public StubContentStep(MetadataHelper packageHelper)
        {
            this.packageHelper = packageHelper;
        }

        public string PackageFile
        {
            get;
            set;
        }

        /// <summary>
        /// Copy the BeginDirectory to the ProcessDirectory excluding files indicated.
        /// </summary>
        public virtual void Execute()
        {
            Logger.Log(LogLevel.Information, "Reading package metadata...");
            Package package = this.packageHelper.ReadMetadata(this.PackageFile);

            string packageDirectory = Path.GetDirectoryName(this.PackageFile);

            // Copy each Package's content
            foreach (Unit unit in package.Units)
            {
                Logger.Log(LogLevel.Information, "Looking for missing content in unit " + unit.Name + "...");
                Logger.IncreaseIndent();
                this.StubUnit(unit, packageDirectory);
                Logger.DecreaseIndent();
            }
        }

        private void StubUnit(Unit unit, string packageDirectory)
        {
            foreach (Lab lab in unit.Labs)
            {
                this.StubContent(lab);
            }

            foreach (Demo demo in unit.Demos)
            {
                this.StubContent(demo);
            }

            foreach (Presentation presentation in unit.Presentations)
            {
                this.StubContent(presentation);
            }

            foreach (Sample sample in unit.Samples)
            {
                this.StubContent(sample);
            }

            foreach (Video video in unit.Videos)
            {
                this.StubContent(video);
            }

            foreach (Whitepaper whitepaper in unit.Whitepapers)
            {
                this.StubContent(whitepaper);
            }
        }

        private void StubContent(DocumentMetadata content)
        {
            if (!string.IsNullOrEmpty(content.Document.RelativePath))
            {
                if (!File.Exists(content.Document.AbsolutePath))
                {
                    Logger.Log(LogLevel.Information, "Creating " + content.Document.AbsolutePath);
                    var file = File.CreateText(content.Document.AbsolutePath);
                    file.Close();
                }
            }
        }
    }
}
