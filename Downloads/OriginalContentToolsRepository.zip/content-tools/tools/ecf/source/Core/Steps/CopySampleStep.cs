﻿namespace Microsoft.Dpe.Ecf.Core.Steps
{
    using System;
    using System.IO;
    using System.Text;
    using Microsoft.Dpe.Ecf.Common;
    using Microsoft.Dpe.Ecf.Common.Helpers;
    using Microsoft.Dpe.Ecf.Core.Helpers;
    using Microsoft.Dpe.Ecf.Model;
    using Microsoft.Dpe.Ecf.Model.Extensions;

    public class CopySampleStep
    {
        private static string ecfDependencyCheckerFolder = string.Empty; // Path.Combine(Environment.GetEnvironmentVariable("ECF", EnvironmentVariableTarget.Machine), "resources\\DependencyChecker");
        private MetadataHelper sampleManifestHelper;
        private Sample sample;       
        
        public CopySampleStep()
            : this(new MetadataHelper())
        {
        }

        internal CopySampleStep(MetadataHelper sampleManifestHelper)
        {
            this.sampleManifestHelper = sampleManifestHelper;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1819:PropertiesShouldNotReturnArrays", Justification = "Design decision for simplicity")]
        public string[] Excludes
        {
            get;
            set;
        }

        /// <summary>
        /// Get or Set the directory where things will be copied
        /// </summary>
        public string OutputDirectory
        {
            get;
            set;
        }

        public string SampleManifestsFilePath
        {
            get;
            set;
        }

        public string AssetDirectories
        {
            get;
            set;
        }

        private Sample Sample 
        {
            get
            {
                if (this.sample == null)
                {
                    // Deserialize Sample
                    this.sample = this.sampleManifestHelper.ReadSample(this.SampleManifestsFilePath);
                }

                return this.sample;
            }
        }       

        private string SampleOutputFolder
        {
            get
            {
                return Path.Combine(this.OutputDirectory, this.Sample.Id);
            }
        }

        private string AssetsOutputFolder
        {
            get
            {
                return Path.Combine(this.SampleOutputFolder, "Assets");
            }
        }

        /// <summary>
        /// Copy the BeginDirectory to the ProcessDirectory excluding files indicated.
        /// </summary>
        public virtual void Execute()
        {
            this.ValidateParameters();            

            // Prepare output directory
            if (Directory.Exists(this.OutputDirectory))
            {
                Logger.Log(LogLevel.Information, "Removing working directory...");
                Directory.Delete(this.OutputDirectory, true);
            }
            
            // copy the sample files
            Logger.Log(LogLevel.Information, "Copying sample to working directory...");
            this.CopySample();

            // copy Assets
            Logger.Log(LogLevel.Information, "Copying assets to working directory...");
            this.CopyAssets();
        }

        private void CopyAssets()
        {
            if (!String.IsNullOrEmpty(this.AssetDirectories))
            {
                // Prepare asset Directory
                if (!Directory.Exists(this.AssetsOutputFolder))
                {
                    Directory.CreateDirectory(this.AssetsOutputFolder);
                }

                string[] assetDirs = this.AssetDirectories.Split(';');
                foreach (string directory in assetDirs)
                {
                    DirectoryHelper.CopyDirectory(directory.Trim(), this.AssetsOutputFolder, this.Excludes);
                }                
            }
        }

        private void CopySample()
        {
            string sourcePath = this.Sample.OriginalDirectory;
            string destinationPath = this.SampleOutputFolder;

            if (!Directory.Exists(destinationPath))
            {
                Directory.CreateDirectory(destinationPath);
            }

            DirectoryHelper.CopyDirectory(sourcePath, destinationPath, this.Excludes);            
        }

        private void ValidateParameters()
        {
            // Xml Package file
            if (String.IsNullOrEmpty(this.SampleManifestsFilePath))
            {
                throw new ArgumentException("Xml Sample file should be specified");
            }

            DirectoryHelper.CheckPathTooLong(this.SampleManifestsFilePath);

            if (!File.Exists(this.SampleManifestsFilePath))
            {
                throw new ArgumentException("Xml Sample file can not be found: " + Path.GetFullPath(this.SampleManifestsFilePath));
            }

            // Output directory
            if (String.IsNullOrEmpty(this.OutputDirectory))
            {
                throw new ArgumentException("Output folder should be specified");
            }

            DirectoryHelper.CheckPathTooLong(this.OutputDirectory);
        }
    }
}
