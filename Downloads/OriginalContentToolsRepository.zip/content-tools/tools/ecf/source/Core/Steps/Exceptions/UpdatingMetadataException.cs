﻿namespace Microsoft.Dpe.Ecf.Core.Steps.Exceptions
{
    using System;
    using System.IO;
    using System.Runtime.Serialization;
    using System.Security.Permissions;

    [Serializable]
    public class UpdatingMetadataException : Exception, ISerializable
    {
        public UpdatingMetadataException() : base()
        {
        }

        public UpdatingMetadataException(string documentPath)
            : base("There was a problem while updating metadata for file:" + Path.GetFullPath(documentPath))
        {
        }

        public UpdatingMetadataException(string documentPath, string message, Exception innerException)
            : base("There was a problem while updating metadata for file:" + Path.GetFullPath(documentPath) + "." + Environment.NewLine + message, innerException)
        {            
        }

        public UpdatingMetadataException(string documentPath, Exception innerException) 
            : base("There was a problem while updating metadata for file:" + Path.GetFullPath(documentPath), innerException)
        {            
        }

        // This constructor is needed for serialization.
        protected UpdatingMetadataException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        // This method is needed for serialization.
        [SecurityPermission(SecurityAction.LinkDemand, Flags = SecurityPermissionFlag.SerializationFormatter)]
        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            base.GetObjectData(info, context);
        }    
    }
}
