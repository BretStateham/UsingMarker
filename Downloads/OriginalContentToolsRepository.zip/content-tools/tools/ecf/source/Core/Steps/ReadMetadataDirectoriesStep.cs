﻿namespace Microsoft.Dpe.Ecf.Core.Steps
{
    using System;
    using System.IO;
    using System.Linq;
    using Microsoft.Dpe.Ecf.Core.Helpers;

    public class ReadMetadataDirectoriesStep
    {
        public string PackageXmlPath { get; set; }

        public virtual string[] Execute()
        {
            // Check the correctness of parameters
            this.CheckParameters();

            MetadataHelper metadataHelper = new MetadataHelper();

            // Deserialize package
            var package = metadataHelper.ReadPlainMetadata(this.PackageXmlPath);

            return metadataHelper.GetPackageDirectories(package).ToArray();
        }

        private void CheckParameters()
        {
            // XML Path
            if (String.IsNullOrEmpty(this.PackageXmlPath))
            {
                throw new ArgumentException("Package XML Path should be specified");
            }

            if (!File.Exists(this.PackageXmlPath))
            {
                throw new ArgumentException("Package XML File can not be found: " + this.PackageXmlPath);
            }
        }
    }
}