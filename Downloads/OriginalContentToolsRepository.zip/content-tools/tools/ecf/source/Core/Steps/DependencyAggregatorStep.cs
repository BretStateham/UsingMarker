﻿namespace Microsoft.Dpe.Ecf.Core.Steps
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Xml.Linq;
    using Microsoft.Dpe.Ecf.Common;
    using Microsoft.Dpe.Ecf.Core.Properties;

    public class DependencyAggregatorStep
    {
        public string TemplatePath { get; set; }

        public string SourceFolder { get; set; }

        public string OutputPath { get; set; }

        public bool AggregateDeploymentTasks { get; set; }

        public bool UpdateScriptToAbsolutePath { get; set; }

        public ICollection<string> LabSpecificTasks { get; set; }

        public ICollection<string> ExcludeDependencies { get; set; }

        public virtual void Execute()
        {
            Logger.Log(LogLevel.Information, "Creating Aggregated Dependencies file.");
            string[] dependencies = RetrieveDependencyFiles(this.SourceFolder);
            this.Aggregate(dependencies, this.OutputPath);
        }

        protected virtual void Aggregate(string[] dependencies, string finalDependencyFilename)
        {
            var finalDoc = this.LoadDependencyFileTemplate();

            foreach (var dependencyFile in dependencies)
            {
                XDocument depDoc = XDocument.Load(dependencyFile);

                if (this.AggregateDeploymentTasks)
                {
                    var taskNode = depDoc.Root.Element("tasks");
                    if (taskNode != null)
                    {
                        foreach (var task in taskNode.Descendants("task"))
                        {
                            if ((this.LabSpecificTasks != null && this.LabSpecificTasks.Contains(task.Attribute("description").Value))
                                || finalDoc.Root.Element("tasks").Descendants("task").Count(t => t.Attribute("description") != null && t.Attribute("description").Value == task.Attribute("description").Value) == 0)
                            {
                                if (this.UpdateScriptToAbsolutePath)
                                {
                                    DoUpdateScriptToAbsolutePath(task, dependencyFile);
                                }

                                finalDoc.Root.Element("tasks").Add(task);
                            }
                        }
                    }
                }

                if (depDoc.Root.Element("dependencies") != null &&
                    depDoc.Root.Element("dependencies").Descendants("os") != null)
                {
                    var dependencyOsElements = from os in depDoc.Root.Element("dependencies").Descendants("os")
                                               where os.Attribute("type") != null && os.Attribute("buildNumber") != null
                                               select os;
                    foreach (var os in dependencyOsElements)
                    {
                        var dependencyOsClone = new XElement(os);

                        foreach (string buildNumber in os.Attribute("buildNumber").Value.Split(';'))
                        {
                            dependencyOsClone.Attribute("buildNumber").SetValue(buildNumber);

                            if (finalDoc.Root.Element("dependencies").Descendants("os").Where(e => e.Attribute("type") != null && e.Attribute("buildNumber") != null && e.Attribute("type").Value == dependencyOsClone.Attribute("type").Value && e.Attribute("buildNumber").Value == dependencyOsClone.Attribute("buildNumber").Value).Count() == 0)
                            {
                                if (this.UpdateScriptToAbsolutePath)
                                {
                                    DoUpdateScriptToAbsolutePath(dependencyOsClone.Descendants("dependency"), dependencyFile);
                                }

                                finalDoc.Root.Element("dependencies").Add(new XElement(dependencyOsClone));
                            }
                            else
                            {
                                var dependencyOsFinal = finalDoc.Root.Element("dependencies").Descendants("os").First(osF => osF.Attribute("type").Value == dependencyOsClone.Attribute("type").Value && osF.Attribute("buildNumber").Value == dependencyOsClone.Attribute("buildNumber").Value);

                                foreach (var dependency in dependencyOsClone.Descendants("dependency"))
                                {
                                    var thisDependency = dependencyOsFinal.Descendants("dependency").SingleOrDefault(e => e.Attribute("title") != null && e.Attribute("title").Value == dependency.Attribute("title").Value);
                                    if (thisDependency == null)
                                    {
                                        if (this.UpdateScriptToAbsolutePath)
                                        {
                                            DoUpdateScriptToAbsolutePath(dependency, dependencyFile);
                                        }

                                        dependencyOsFinal.Add(dependency);
                                    }
                                }
                            }
                        }
                    }
                }
            }

            UpdateExplanationAttribute(finalDoc);

            var outputDirectory = Path.GetDirectoryName(finalDependencyFilename);
            if (!Directory.Exists(outputDirectory))
            {
                Directory.CreateDirectory(outputDirectory);
            }

            finalDoc.Save(finalDependencyFilename);
            var message = string.Format(CultureInfo.CurrentCulture, "Aggregated Dependency file created: {0}", finalDependencyFilename);
            Logger.Log(LogLevel.Information, message);
        }

        protected XDocument LoadDependencyFileTemplate()
        {
            XDocument finalDoc;
            if (string.IsNullOrEmpty(this.TemplatePath))
            {
                finalDoc = XDocument.Parse(Resources.Dependencies_NewFileTemplate);
            }
            else
            {
                finalDoc = XDocument.Load(this.TemplatePath);
            }

            return finalDoc;
        }

        private static string[] RetrieveDependencyFiles(string sourceFolder)
        {
            List<string> results = new List<string>();

            // Consider moving filenames to a pattern property
            results.AddRange(DirSearch(sourceFolder, "Dependencies.xml"));
            results.AddRange(DirSearch(sourceFolder, "Dependencies.dep"));

            return results.ToArray();
        }

        private static void DoUpdateScriptToAbsolutePath(IEnumerable<XElement> dependencies, string dependencyFile)
        {
            foreach (var dependency in dependencies)
            {
                DoUpdateScriptToAbsolutePath(dependency, dependencyFile);
            }
        }

        private static void DoUpdateScriptToAbsolutePath(XElement dependency, string dependencyFile)
        {
            UpdateAttributeToAbsolutePath(dependencyFile, dependency.Attribute("value"));
            UpdateAttributeToAbsolutePath(dependencyFile, dependency.Attribute("scriptName"));
        }

        private static void UpdateAttributeToAbsolutePath(string dependencyFile, XAttribute attribute)
        {
            if (attribute != null && !string.IsNullOrEmpty(attribute.Value))
            {
                attribute.Value = new FileInfo(new FileInfo(dependencyFile).DirectoryName + attribute.Value).FullName;
            }
        }

        private static void UpdateExplanationAttribute(XDocument finalDoc)
        {
            string trainingKitTitle = finalDoc.Root.Element("title").Value;
            finalDoc.Root.Descendants("dependency").ToList().ForEach(x => x.Attribute("explanation").Value = string.Format("{0} requires {1}", trainingKitTitle, x.Attribute("title").Value));
        }

        private static string[] DirSearch(string searchDir, string pattern)
        {
            List<string> filesFound = new List<string>();
            try
            {
                foreach (string f in Directory.GetFiles(searchDir, pattern))
                {
                    filesFound.Add(f);
                }

                foreach (string d in Directory.GetDirectories(searchDir))
                {
                    // exclude "_archive" Directories (Consider moving to a parameter)
                    if (!d.EndsWith("_archive", StringComparison.OrdinalIgnoreCase))
                    {
                        filesFound.AddRange(DirSearch(d, pattern));
                    }
                }
            }
            catch (System.Exception excpt)
            {
                Console.WriteLine(excpt.Message);
            }

            return filesFound.ToArray();
        }
    }
}