﻿namespace Microsoft.Dpe.Ecf.Core.Steps
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Text;

    public class AddCopyrightHeaderStep
    {
        public AddCopyrightHeaderStep()
        {
        }

        public string FilePath
        {
            get;
            set;
        }

        public string HeaderFileName
        {
            get;
            set;
        }

        public virtual void Execute()
        {
            this.AddCopyright(this.HeaderFileName, this.RecursiveSearch(this.FilePath));
        }

        protected virtual void AddCopyright(string copyrightFileName, IEnumerable<string> filesToModify)
        {
            if (String.IsNullOrEmpty(copyrightFileName))
            { 
                throw new ArgumentNullException(string.Format(CultureInfo.InvariantCulture, "copyrightFileName"));
            }

            if (!File.Exists(copyrightFileName))
            {
                throw new ArgumentException(string.Format(CultureInfo.InvariantCulture, "The copyright header file '{0}' was not found.", copyrightFileName));
            }

            string copyrightHeader = this.ReadCopyrightFile(copyrightFileName);

            foreach (var filePath in filesToModify)
            {
                this.ApplyHeaderToFile(copyrightHeader, filePath);
            }
        }

        protected virtual string ReadCopyrightFile(string path)
        {
            var header = File.ReadAllText(path);
            return header;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1309:UseOrdinalStringComparison", MessageId = "System.String.StartsWith(System.String,System.StringComparison)", Justification = "Comparison should be case sensitive")]
        protected virtual void ApplyHeaderToFile(string header, string filePath)
        {
            if (filePath.EndsWith(".cs", StringComparison.OrdinalIgnoreCase) |
                filePath.EndsWith(".c", StringComparison.OrdinalIgnoreCase) |
                filePath.EndsWith(".cpp", StringComparison.OrdinalIgnoreCase) |
                filePath.EndsWith(".h", StringComparison.OrdinalIgnoreCase))
            {
                header = PrepareHeaderForCSFile(header);
            }

            if (filePath.EndsWith(".vb", StringComparison.OrdinalIgnoreCase))
            {
                header = PrepareHeaderForVBFile(header);
            }

            // Trim Header File
            header = header.Trim();

            // Read Code File
            var fileContent = File.ReadAllText(filePath);

            // // Trim Code File
            // fileContent = fileContent.Trim();

            // Add Header to file (if it does not contain it already) 
            StringBuilder builder = new StringBuilder();
            if (!fileContent.StartsWith(header, StringComparison.InvariantCulture))
            {
                builder.Append(header);
                builder.Append(Environment.NewLine);
                builder.Append(Environment.NewLine);                
            }

            builder.Append(fileContent);

            File.WriteAllText(filePath, builder.ToString(), Encoding.UTF8);
        }

        private static string PrepareHeaderForCSFile(string header)
        {
            return ReplaceComments(header, "//");
        }

        private static string PrepareHeaderForVBFile(string header)
        {
            return ReplaceComments(header, "'");
        }

        private static string ReplaceComments(string header, string commnetPattern)
        {
            StringReader reader = new StringReader(header);
            StringBuilder builder = new StringBuilder();

            string line = reader.ReadLine();
            while (line != null)
            {
                if (!line.StartsWith(commnetPattern, StringComparison.OrdinalIgnoreCase))
                {
                    line = commnetPattern + " " + line;
                }

                builder.AppendLine(line);

                line = reader.ReadLine();
            }

            return builder.ToString();
        }

        private IEnumerable<string> RecursiveSearch(string path)
        {
            List<string> fileList = new List<string>();

            if (path == null)
            {
                return fileList;
            }

            fileList.AddRange(Directory.GetFiles(path, "*.cs"));
            fileList.AddRange(Directory.GetFiles(path, "*.c"));
            fileList.AddRange(Directory.GetFiles(path, "*.cpp"));
            fileList.AddRange(Directory.GetFiles(path, "*.h"));
            fileList.AddRange(Directory.GetFiles(path, "*.vb"));

            if (!(Directory.GetDirectories(path) == null))
            {
                foreach (string item in Directory.GetDirectories(path))
                {
                    fileList.AddRange(this.RecursiveSearch(item));
                }
            }

            return fileList;
        }
    }
}
