﻿namespace Microsoft.Dpe.Ecf.Core.Steps
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.IO;
    using System.Reflection;
    using System.Xml.Serialization;
    using Microsoft.Dpe.Ecf.Common;
    using Microsoft.Dpe.Ecf.Core.Helpers;
    using Microsoft.Dpe.Ecf.Core.Models;
    using Microsoft.Dpe.Ecf.Model;
    using Microsoft.Dpe.Ecf.Model.Extensions;

    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1704:IdentifiersShouldBeSpelledCorrectly", MessageId = "Ecf", Justification = "ECF is for Evangelism content framework")]
    public class ConvertEcfElementStep<T> where T : EcfElement, new()
    {
        public ConvertEcfElementStep(T metadataInstance)
            : this(metadataInstance, string.Empty)
        {
        }

        public ConvertEcfElementStep(T metadataInstance, string xsltPath)
            : this(metadataInstance, xsltPath, false)
        {
        }

        public ConvertEcfElementStep(T metadataInstance, string xsltPath, bool useTocFile)
            : this(metadataInstance, xsltPath, false, string.Empty)
        {
        }

        public ConvertEcfElementStep(T metadataInstance, string xsltPath, bool useTocFile, string conversionType)
        {
            this.MetadataInstance = metadataInstance;
            this.XsltPath = xsltPath;
            this.UseTocFile = useTocFile;
            this.IncludeConversionType = conversionType;

            // Check the correctness of parameters
            this.CheckParameters();
        }

        private bool UseTocFile
        {
            get;
            set;
        }

        private T MetadataInstance
        {
            get;
            set;
        }

        private string XsltPath
        {
            get;
            set;
        }

        private string IncludeConversionType
        {
            get;
            set;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily", Justification = "Double cast is needed due to generics")]
        public virtual void Execute() 
        {
            // Check that package was deserialized correctly
            if (this.MetadataInstance == null)
            {
                throw new ArgumentException("XML file has invalid format.");
            }

            string packageFeedback = GetPackageFeedBack(this.MetadataInstance);
            Dictionary<EcfElement, List<ConvertibleDocument>> documentsToConvert = this.GetDocumentsToConvert(this.MetadataInstance);
            
            // Convert each document            
            foreach (var key in documentsToConvert.Keys)
            {
                DocToolsConfig config = GetConfiguration(key, packageFeedback);
                foreach (var document in documentsToConvert[key])
                {
                    // convert word 2007/2010 documents only
                    if (Path.GetExtension(document.RelativePath).Equals(".DOCX", StringComparison.OrdinalIgnoreCase))
                    {
                        if (!string.IsNullOrEmpty(this.IncludeConversionType))
                        {
                            document.ConversionType |= ParseConvertionType(this.IncludeConversionType);
                        }

                        if (config != null)
                        {
                            ConvertHelper.Convert(document, this.XsltPath, config, this.UseTocFile);
                        }
                        else
                        {
                            ConvertHelper.Convert(document, this.XsltPath, null, this.UseTocFile);
                        }

                        SerializeToc(document);

                        if (document.ExcludeSource)
                        {
                            if (File.Exists(document.AbsolutePath))
                            {
                                File.Delete(document.AbsolutePath);
                            }
                        }

                        if ((document.ConversionType & ConversionType.Html) == ConversionType.Html || (document.ConversionType & ConversionType.HtmlSinglePage) == ConversionType.HtmlSinglePage)
                        {
                            // validate the content was converted
                            var resultsDir = Path.Combine(document.AbsoluteHtmlPath, "html");

                            if (Directory.Exists(resultsDir))
                            {
                                if ((new DirectoryInfo(resultsDir)).GetFiles("*.html").Length < 1)
                                {
                                    Logger.Log(LogLevel.Warning, "Document " + document.RelativePath + " was not converted! Verify the document content is using the docTools styles.");
                                }
                            }
                        }
                    }
                }
            }
        }

        private static ConversionType ParseConvertionType(string conversionType)
        {
            ConversionType convType = ConversionType.None;

            string[] types = conversionType.Split(", ".ToCharArray());

            foreach (var ctype in types)
            {
                switch (ctype.Trim().ToUpperInvariant())
                {
                    case "HTML":
                        convType |= ConversionType.Html;
                        break;
                    case "HTMLSINGLEPAGE":
                    case "SINGLEHTMLPAGE":
                    case "SINGLEHTML":
                        convType |= ConversionType.HtmlSinglePage;
                        break;
                    case "PDF":
                        convType |= ConversionType.Pdf;
                        break;
                    case "NONE":
                        convType = ConversionType.None;
                        break;
                    case "":
                        break;
                    default:
                        throw new ArgumentException("Invalid convertion: " + conversionType + ". Convertion must be Html, HtmlSinglePage, Mht, Pdf, Xps or None");
                }
            }

            return convType;
        }

        private static void SerializeToc(ConvertibleDocument document)
        {
            if ((document.ConversionType & ConversionType.Html) == ConversionType.Html)
            {
                var tocPath = Path.Combine(document.BasePath, "Topics.xml");

                if (!File.Exists(tocPath))
                {
                    var stream = File.Open(tocPath, FileMode.CreateNew, FileAccess.Write, FileShare.Read); // var writer = new StreamWriter(tocPath);
                    var serializer = new XmlSerializer(typeof(List<DocumentTopic>));

                    serializer.Serialize(stream, document.Topics);
                    stream.Close();
                }
            }
        }

        private static string GetPackageFeedBack(T metadataInstance)
        {
            // Get the document to convert            
            string packageFeedback = String.Empty;
            ManifestFile package = metadataInstance as ManifestFile;
            if (package != null)
            {                          
                packageFeedback = package.Feedback;
            }

            return packageFeedback;
        }      

        private static DocToolsConfig GetConfiguration(EcfElement key, string packageFeedback)
        {
            DocumentMetadata contentType = key as DocumentMetadata;
            string feedback = String.Empty;
            if (contentType != null)
            {
                if (contentType != null && !String.IsNullOrEmpty(contentType.Feedback))
                {
                    feedback = contentType.Feedback;
                }
                else
                {
                    feedback = packageFeedback;
                }

                return new DocToolsConfig(contentType.Title, feedback);
            }

            return null;            
        }

        private static Dictionary<EcfElement, List<ConvertibleDocument>> GetConvertibleDocuments(DocumentMetadata documentMetaData)
        {
            Dictionary<EcfElement, List<ConvertibleDocument>> convertibleDocuments = new Dictionary<EcfElement, List<ConvertibleDocument>>();

            if (documentMetaData == null)
            {
                return convertibleDocuments;
            }

            PropertyInfo[] properties = documentMetaData.GetType().GetProperties();
            List<ConvertibleDocument> documents = new List<ConvertibleDocument>();
            foreach (var property in properties)
            {
                if (IsClassOrSubClassOf(property.PropertyType, typeof(ConvertibleDocument)))
                {
                    ConvertibleDocument document = (ConvertibleDocument)property.GetValue(documentMetaData, null);
                    documents.Add(document);
                }
            }

            convertibleDocuments.Add(documentMetaData, documents);

            return convertibleDocuments;
        }

        private static bool IsClassOrSubClassOf(Type baseType, Type otherType)
        {
            // Check for type or subtype
            if (baseType == otherType || baseType.IsSubclassOf(otherType))
            {
                return true;
            }

            return false;
        }

        private static bool IsArrayOf(Type baseType, Type otherType)
        {
            // Check for generic Types (including collections, so List<otherType> return true)
            if (baseType.IsGenericType && IsClassOrSubClassOf(baseType.GetGenericArguments()[0], otherType))
            {
                return true;
            }

            return false;
        }

        private Dictionary<EcfElement, List<ConvertibleDocument>> GetDocumentsToConvert(T metadataInstance)
        {
            // Get the document to convert            
            Dictionary<EcfElement, List<ConvertibleDocument>> documentsToConvert = new Dictionary<EcfElement, List<ConvertibleDocument>>();
            DocumentMetadata contentType = metadataInstance as DocumentMetadata;
            ManifestFile package = metadataInstance as ManifestFile;
            if (contentType != null)
            {
                documentsToConvert = GetConvertibleDocuments(contentType);
            }
            else if (package != null)
            {
                documentsToConvert = this.GetConvertibleDocuments(package);
            }

            return documentsToConvert;
        }

        /// <summary>
        /// 
        ///  Searches in property colections of:
        ///                             - ManifestFiles 
        ///                             - DocumentMetadata
        ///   Searches in property  of:
        ///                             - DocumentMetadata 
        ///                             - ConvertibleDocument
        ///                             
        /// </summary>
        /// <param name="package"></param>
        /// <returns></returns>
        private Dictionary<EcfElement, List<ConvertibleDocument>> GetConvertibleDocuments(ManifestFile package)
        {
            Dictionary<EcfElement, List<ConvertibleDocument>> convertibleDocuments = new Dictionary<EcfElement, List<ConvertibleDocument>>();

            PropertyInfo[] properties = package.GetType().GetProperties();
            foreach (var property in properties)
            {
                // Search in ManifestFiles Collections
                if (IsArrayOf(property.PropertyType, typeof(ManifestFile)))
                {
                    ICollection manifestsFileCol = (ICollection)property.GetValue(package, null);
                    foreach (var manifestFile in manifestsFileCol)
                    {
                        convertibleDocuments.AddRange(this.GetConvertibleDocuments((ManifestFile)manifestFile));
                    }
                }

                // Search in DocumentMetadata Collections
                if (IsArrayOf(property.PropertyType, typeof(DocumentMetadata)))
                {
                    ICollection manifestsFileCol = (ICollection)property.GetValue(package, null);
                    foreach (var manifestFile in manifestsFileCol)
                    {
                        convertibleDocuments.AddRange(GetConvertibleDocuments((DocumentMetadata)manifestFile));
                    }
                }
                
                // Search in all Metadata
                if (IsClassOrSubClassOf(property.PropertyType, typeof(DocumentMetadata)))
                {
                    DocumentMetadata documentMetaData = (DocumentMetadata)property.GetValue(package, null);
                    convertibleDocuments.AddRange(GetConvertibleDocuments(documentMetaData));
                }

                // Add convertible documents
                if (IsClassOrSubClassOf(property.PropertyType, typeof(ConvertibleDocument)))
                {
                    ConvertibleDocument document = (ConvertibleDocument)property.GetValue(package, null);
                    convertibleDocuments.Add(package, new List<ConvertibleDocument>() { document });
                }
            }

            return convertibleDocuments;
        }
       
        private void CheckParameters()
        {
            // Package Path
            if (this.MetadataInstance == null)
            {
                throw new ArgumentException("Metadata Instance should be specified");
            }

            // XSLT Path, if specified, check existance
            if (!String.IsNullOrEmpty(this.XsltPath)) 
            {
                if (!Directory.Exists(this.XsltPath))
                {
                    throw new ArgumentException("XSLT File can not be found: " + this.XsltPath);
                }

                this.XsltPath = Path.GetFullPath(this.XsltPath);
            }
        }
    }
}
