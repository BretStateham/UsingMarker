﻿namespace Microsoft.Dpe.Ecf.Core.Steps
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Security;
    using System.Security.Permissions;
    using Microsoft.Dpe.Ecf.Common.Helpers;

    public class CreateZipStep
    {
        public CreateZipStep()
        {
        }

        public string FolderToZip
        {
            get;
            set;
        }

        public string ZipFileName
        {
            get;
            set;
        }

        public string ExcludeFile
        {
            get;
            set;
        }

        private string OutputFolder
        {
            get
            {
                return Path.GetDirectoryName(this.ZipFileName);
            }
        }

        [PermissionSet(SecurityAction.LinkDemand)]
        public virtual void Execute()
        {
            this.ValidateParameters();

            // delete previous file if it exists
            if (File.Exists(this.ZipFileName))
            {
                File.Delete(this.ZipFileName);
            }

            if (!Directory.Exists(this.OutputFolder))
            {
                Directory.CreateDirectory(this.OutputFolder);
            }

            // read excludes file
            string[] excludes = this.GetExcludes();

            ZipHelper.ZipFolder(this.FolderToZip, this.ZipFileName, excludes);            
        }

        private string[] GetExcludes()
        {
            List<string> excludes = new List<string>();
            if (!String.IsNullOrEmpty(this.ExcludeFile))
            {
                using (StreamReader reader = File.OpenText(this.ExcludeFile))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        excludes.Add(line);
                    }
                }
            }

            return excludes.ToArray();
        }

        private void ValidateParameters()
        {
            if (!String.IsNullOrEmpty(this.ExcludeFile))
            {
                if (!File.Exists(this.ExcludeFile))
                {
                    throw new ArgumentException("Exclude File could not be found." + Path.GetFullPath(this.ExcludeFile));
                }                
            }
        }               
    }
}
