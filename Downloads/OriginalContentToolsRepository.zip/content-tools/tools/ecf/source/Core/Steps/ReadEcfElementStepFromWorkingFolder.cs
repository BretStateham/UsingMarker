﻿namespace Microsoft.Dpe.Ecf.Core.Steps
{
    using System;
    using System.IO;
    using Microsoft.Dpe.Ecf.Core.Helpers;
    using Microsoft.Dpe.Ecf.Model;    

    /// <summary>
    /// Deserialices the specified XML into a Package object
    /// OBLIGATORY PARAMETERS:  - PackageXMLPath    
    /// </summary>
    public class ReadEcfElementFromWorkingFolderStep
    {
        public string ManifestXmlPath { get; set; }

        public virtual EcfElement Execute()
        {
            // Check the correctness of parameters
            this.CheckParameters(); 
            
            MetadataHelper packageHelper = new MetadataHelper();

            // Deserialize package
            return packageHelper.ReadEcfElementFromWorkingDirectory(this.ManifestXmlPath);
        }
       
        private void CheckParameters()
        {
            // XML Path
            if (String.IsNullOrEmpty(this.ManifestXmlPath))
            {
                throw new ArgumentException("Package XML Path should be specified");
            }

            if (!File.Exists(this.ManifestXmlPath))
            {
                throw new ArgumentException("Package XML File can not be found: " + this.ManifestXmlPath);
            }
        }
    }
}
