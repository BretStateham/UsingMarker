﻿namespace Microsoft.Dpe.Ecf.Core.Steps
{
    using System;
    using System.IO;
    using Microsoft.Dpe.Ecf.Core.Helpers;
    using Microsoft.Dpe.Ecf.Model;    

    /// <summary>
    /// Deserialices the specified XML into a Package object
    /// OBLIGATORY PARAMETERS:  - PackageXMLPath    
    /// </summary>
    public class ReadPlainMetadataStep
    {
        public string PackageXmlPath { get; set; }

        public virtual Package Execute()
        {
            // Check the correctness of parameters
            this.CheckParameters(); 
            
            MetadataHelper packageHelper = new MetadataHelper();

            // Deserialize package
            return packageHelper.ReadPlainMetadata(this.PackageXmlPath);
        }
       
        private void CheckParameters()
        {
            // XML Path
            if (String.IsNullOrEmpty(this.PackageXmlPath))
            {
                throw new ArgumentException("Package XML Path should be specified");
            }

            if (!File.Exists(this.PackageXmlPath))
            {
                throw new ArgumentException("Package XML File can not be found: " + this.PackageXmlPath);
            }
        }
    }
}
