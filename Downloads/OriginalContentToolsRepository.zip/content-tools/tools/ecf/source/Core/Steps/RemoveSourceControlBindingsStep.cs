﻿namespace Microsoft.Dpe.Ecf.Core.Steps
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Text;
    using System.Xml.Linq;
    using Microsoft.Dpe.Ecf.Common;
    using Microsoft.Dpe.Ecf.Common.Helpers;

    public class RemoveSourceControlBindingsStep
    {
        private RecursiveSearchHelper recursiveSearch;

        private string[] bindingPattern = new string[] { "*.vssscc", "*.vspscc", "*.scc" };
        private string projectPattern = "*.*proj";
        private string solutionPattern = "*.sln";
        private string globalSection = "GlobalSection(TeamFoundationVersionControl)";
        private string endGlobalSection = "EndGlobalSection";

        public RemoveSourceControlBindingsStep()
        {
            this.recursiveSearch = new RecursiveSearchHelper();
        }

        /// <summary>
        /// Get or Set the temporal directory for process proposes
        /// </summary>
        public string WorkingDirectory
        {
            get;
            set;
        }

        /// <summary>
        /// Remove Source Control Bindings according to a specified binding pattern.
        /// </summary>
        public virtual void Execute()
        {
            this.DeleteSourceControlFiles();
            this.CleanSolutions();
            this.CleanProjects();
        }

        protected virtual void DeleteSourceControlFiles()
        {
            List<string> files = new List<string>();

            foreach (var pattern in this.bindingPattern)
            {
                files.AddRange(this.recursiveSearch.GetFiles(this.WorkingDirectory, pattern));
            }

            foreach (var file in files)
            {
                File.SetAttributes(file, FileAttributes.Normal);
                File.Delete(file);
            }
        }

        protected virtual void CleanSolutions()
        {
            string[] solutions = this.recursiveSearch.GetFiles(this.WorkingDirectory, this.solutionPattern);

            foreach (var solutionFile in solutions)
            {
                string solutionText = File.ReadAllText(solutionFile);

                if (solutionText.Contains(this.globalSection))
                {
                    string tfs = this.GetTfsGlobalSection(solutionText);

                    // add VS Solution signature missing on text mode editing
                    var text = (new ASCIIEncoding()).GetBytes(solutionText.Replace(tfs, null));
                    var bytes = new byte[text.Length + 3];
                    Array.Copy(text, 0, bytes, 3, text.Length);
                    bytes[0] = 0xEF;
                    bytes[1] = 0xBB;
                    bytes[2] = 0xBF;

                    FileStream stream = new FileStream(solutionFile, FileMode.Create);
                    BinaryWriter w = new BinaryWriter(stream);
                    w.Write(bytes);
                    w.Close();
                }
            }
        }

        protected virtual void CleanProjects()
        {
            string[] projects = this.recursiveSearch.GetFiles(this.WorkingDirectory, this.projectPattern);

            foreach (var projectFile in projects)
            {
                Logger.Log(LogLevel.Debug, "Cleaning bindings from project " + projectFile);

                try
                {
                    XDocument projectDocument = XDocument.Load(projectFile);
                
                    foreach (var item in projectDocument.Elements())
                    {
                        this.RemoveSccElements(item);
                    }

                    projectDocument.Save(projectFile);
                }
                catch (System.Xml.XmlException)
                {
                    // ignore non xml content
                }
            }
        }

        private void RemoveSccElements(XElement node)
        {
            if (node.Name.LocalName.Contains("Scc"))
            {
                node.RemoveAll();
            }
            else if (node.HasElements)
            {
                foreach (XElement element in node.Elements())
                {
                    this.RemoveSccElements(element);
                }
            }
        }

        private string GetTfsGlobalSection(string solutionText)
        {
            string globalTfsSection = solutionText.Substring(solutionText.IndexOf(this.globalSection, StringComparison.OrdinalIgnoreCase));
            globalTfsSection = globalTfsSection.Substring(0, (globalTfsSection.IndexOf(this.endGlobalSection, StringComparison.OrdinalIgnoreCase) + this.endGlobalSection.Length));

            return globalTfsSection;
        }
    }
}
