﻿namespace Microsoft.Dpe.Ecf.Core.Steps
{
    using System.IO;
    using System.Linq;
    using System.Reflection;
    using System.Xml.Serialization;
    using Microsoft.Dpe.Ecf.Core.Properties;
    using Microsoft.Dpe.Ecf.Model.EcfMetadata;

    /// <summary>
    /// Deserialices the specified XML into a Package object
    /// OBLIGATORY PARAMETERS:  - PackageXMLPath    
    /// </summary>
    public class ReadEcfMetadataStep
    {
        private static EcfMetadata ecfMetadataDefaultValues;

        static ReadEcfMetadataStep()
        {
            XmlSerializer serializer = new XmlSerializer(typeof(EcfMetadata));

            var content = Resources.EcfMetadataDefaults;
            
            using (var reader = new StringReader(content))
            {
                ecfMetadataDefaultValues = (EcfMetadata)serializer.Deserialize(reader);
            }
        }

        public string EcfMetadataContent { get; set; }

        public string EcfToolsFolder { get; set; }

        public string PackageRootFolder { get; set; }

        public virtual EcfMetadata Execute()
        {
            bool areAllValuesDefault = false;
            EcfMetadata ecfMetadata;
            XmlSerializer serializer = new XmlSerializer(typeof(EcfMetadata));

            var content = this.EcfMetadataContent;
            if (string.IsNullOrEmpty(content))
            {
                content = Resources.EcfMetadataDefaults;
                areAllValuesDefault = true;
            }

            using (var reader = new StringReader(content))
            {
                ecfMetadata = (EcfMetadata)serializer.Deserialize(reader);
            }

            if (!areAllValuesDefault)
            {
                this.SetDefaultValues(ecfMetadata, ecfMetadataDefaultValues);
            }

            this.ExpandEnvironmentVariables(ecfMetadata);

            return ecfMetadata;
        }

        private void SetDefaultValues(object metadata, object defaultMetadata)
        {
            if (metadata != null && defaultMetadata != null)
            {
                var metadataProperties = metadata.GetType().GetProperties(BindingFlags.Public | BindingFlags.SetProperty | BindingFlags.GetProperty | BindingFlags.Instance)
                    .Where(p => p.GetCustomAttributes(typeof(EcfIgnoreDefaultValueAttribute), true).Length == 0).ToList();

                var defaultProperties = defaultMetadata.GetType().GetProperties(BindingFlags.Public | BindingFlags.SetProperty | BindingFlags.GetProperty | BindingFlags.Instance)
                    .Where(p => p.GetCustomAttributes(typeof(EcfIgnoreDefaultValueAttribute), true).Length == 0).ToList();

                foreach (var property in metadataProperties)
                {
                    var defaultProperty = defaultProperties.SingleOrDefault(p => p.Name == property.Name && p.PropertyType == property.PropertyType);

                    if (defaultProperty != null)
                    {
                        var currentValue = property.GetValue(metadata, null);
                        var newValue = defaultProperty.GetValue(defaultMetadata, null);

                        if (property.PropertyType.IsAssignableFrom(typeof(string)))
                        {
                            if (string.IsNullOrEmpty((string)currentValue))
                            {
                                property.SetValue(metadata, (string)newValue, null);
                            }
                        }
                        else
                        {
                            if (currentValue == null)
                            {
                                property.SetValue(metadata, newValue, null);
                            }
                            else
                            {
                                this.SetDefaultValues(property.GetValue(metadata, null), defaultProperty.GetValue(defaultMetadata, null));
                            }
                        }
                    }
                }
            }
        }

        private void ExpandEnvironmentVariables(object instance)
        {
            if (instance != null)
            {
                var allTypeProperties = instance.GetType().GetProperties(BindingFlags.Public | BindingFlags.SetProperty | BindingFlags.GetProperty | BindingFlags.Instance);
                var decoredProperties = allTypeProperties.Where(
                    p => p.GetCustomAttributes(typeof(EcfExpandEnvironmentVariablesAttribute), true).Length > 0);

                foreach (var item in decoredProperties)
                {
                    if (item.PropertyType.IsAssignableFrom(typeof(string)))
                    {
                        var previousValue = (string)item.GetValue(instance, null);

                        if (!string.IsNullOrEmpty(previousValue))
                        {
                            var newValue = previousValue.Replace("%ECF%", this.EcfToolsFolder);
                            if (!Path.IsPathRooted(newValue))
                            {
                                newValue = Path.Combine(this.PackageRootFolder, newValue);
                            }

                            item.SetValue(instance, newValue, null);
                        }
                    }
                    else
                    {
                        this.ExpandEnvironmentVariables(item.GetValue(instance, null));
                    }
                }
            }
        }
    }
}
