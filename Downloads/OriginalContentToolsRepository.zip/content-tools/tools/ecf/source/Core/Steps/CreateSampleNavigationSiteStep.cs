﻿namespace Microsoft.Dpe.Ecf.Core.Steps
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using Microsoft.Dpe.Ecf.Common.Helpers;
    using Microsoft.Dpe.Ecf.Core.Helpers;
    using Microsoft.Dpe.Ecf.Model;

    public class CreateSampleNavigationSiteStep
    {
        private MetadataHelper sampleHelper;
        private TextTemplatingHelper templatingHelper;

        public CreateSampleNavigationSiteStep()
            : this(new MetadataHelper(), new TextTemplatingHelper())
        {
        }

        internal CreateSampleNavigationSiteStep(MetadataHelper packageHelper, TextTemplatingHelper templatingHelper)
        {
            this.sampleHelper = packageHelper;
            this.templatingHelper = templatingHelper;
        }

        public string TemplatesDirectory
        {
            get;
            set;
        }

        public string SampleManifestsFile
        {
            get;
            set;
        }

        public string OutputFolderPath
        {
            get;
            set;
        }

        public string XsltPath
        {
            get;
            set;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1819:PropertiesShouldNotReturnArrays", Justification = "Design decision for simplicity")]
        public string[] IncludeTemplates
        {
            get;
            set;
        }

        public virtual void Execute()
        {
            // Deserialize package
            Sample sample = this.sampleHelper.ReadSample(this.SampleManifestsFile);

            if (sample == null)
            {
                throw new ArgumentException("Package file has invalid format.");
            }

            string packagePath = Path.GetDirectoryName(this.SampleManifestsFile);

            // convert the document
            ConvertHelper.Convert(sample.Document, this.XsltPath);

            // Creates properties bag for the template
            Dictionary<string, object> properties = new Dictionary<string, object>();
            properties.Add("Sample", sample);

            // Process navigation templates
            this.templatingHelper.ProcessMultipleTemplates(this.TemplatesDirectory, properties, packagePath, this.IncludeTemplates);

            // Copy templates images and css directories
            this.CreateSupportDirectories();
        }

        protected virtual void CreateSupportDirectories()
        {
            List<string> excludes = new List<string>(Properties.Resources.defaultExcludePattern.Split(" ".ToCharArray()));
            excludes.AddRange(TextTemplatingHelper.SearchTemplatesPattern());

            DirectoryHelper.CopyDirectory(this.TemplatesDirectory, Path.GetDirectoryName(this.SampleManifestsFile), excludes.ToArray());
        }
    }
}