﻿namespace Microsoft.Dpe.Ecf.Core.Steps
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using Microsoft.Dpe.Ecf.Common;
    using Microsoft.Dpe.Ecf.Common.Helpers;
    using Microsoft.Dpe.Ecf.Core.Helpers;
    using Microsoft.Dpe.Ecf.Model;

    public class CopyPackageStep
    {
        private MetadataHelper packageHelper;

        public CopyPackageStep()
            : this(new MetadataHelper())
        {
        }

        public CopyPackageStep(MetadataHelper packageHelper)
        {
            this.packageHelper = packageHelper;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1819:PropertiesShouldNotReturnArrays", Justification = "Design decision for simplicity")]
        public string[] Excludes
        {
            get;
            set;
        }

        /// <summary>
        /// Get or Set the temporal directory for process proposes
        /// </summary>
        public string ProcessDirectory
        {
            get;
            set;
        }

        public Package Metadata
        {
            get;
            set;
        }

        public string AssetDirectories
        {
            get;
            set;
        }

        public bool ExcludeDependencyChecker
        {
            get;
            set;
        }

        public bool DependencyCheckerInScriptFolder
        {
            get;
            set;
        }

        /// <summary>
        /// Copy the BeginDirectory to the ProcessDirectory excluding files indicated.
        /// </summary>
        public virtual void Execute()
        {
            DirectoryHelper.CheckPathTooLong(this.ProcessDirectory);
            DirectoryHelper.CheckPathTooLong(this.Metadata.Location);

            string packageDirectory = Path.GetDirectoryName(this.Metadata.Location);
            string tempPackageDirectory = Path.Combine(this.ProcessDirectory, this.Metadata.Id);

            if (Directory.Exists(tempPackageDirectory))
            {
                Logger.Log(LogLevel.Information, "Removing working directory...");
                Directory.Delete(tempPackageDirectory, true);
            }

            // Copy the package
            Logger.Log(LogLevel.Information, "Copying package to working directory...");
            this.CopyPackageToWorkingDirectory(tempPackageDirectory, this.Metadata);

            // copy the assests & dependency Checker
            Logger.Log(LogLevel.Information, "Copying package assets...");
            this.CopyAssets(this.Metadata, tempPackageDirectory);

            // Copy each Package's content
            foreach (Unit unit in this.Metadata.Units)
            {
                Logger.Log(LogLevel.Information, "Copying unit " + unit.Name + " to working directory...");
                this.CopyUnitToWorkingDirectory(unit, tempPackageDirectory, packageDirectory);
            }
        }

        private void CopyAssets(Package package, string packageDirectory)
        {
            string assetsDirectory = Path.Combine(packageDirectory, "Assets");
            string copiedDependencyCheckerFolder = string.Empty;
            string originalPackageDirectory = Path.GetDirectoryName(package.Location);

            if (!String.IsNullOrEmpty(this.AssetDirectories))
            {
                string[] directories = this.AssetDirectories.Split(';').Select(d => Path.Combine(originalPackageDirectory, d)).ToArray();

                if (!Directory.Exists(assetsDirectory))
                {
                    Directory.CreateDirectory(assetsDirectory);
                }

                foreach (string directory in directories)
                {
                    DirectoryHelper.CheckPathTooLong(directory);
                    DirectoryHelper.CopyDirectory(directory, assetsDirectory, this.Excludes);
                }
            }
        }

        private void CopyUnitToWorkingDirectory(Unit unit, string workingDirectory, string packageDirectory)
        {
            foreach (Lab lab in unit.Labs)
            {
                this.CopyContentToWorkingDirectory(lab, workingDirectory);
            }

            foreach (Demo demo in unit.Demos)
            {
                this.CopyContentToWorkingDirectory(demo, workingDirectory);
            }

            foreach (Presentation presentation in unit.Presentations)
            {
                this.CopyContentToWorkingDirectory(presentation, workingDirectory);
            }

            foreach (Sample sample in unit.Samples)
            {
                this.CopyContentToWorkingDirectory(sample, workingDirectory);
            }

            foreach (Video video in unit.Videos)
            {
                this.CopyVideoToWorkingDirectory(video, workingDirectory);
            }

            foreach (Whitepaper whitepaper in unit.Whitepapers)
            {
                this.CopyContentToWorkingDirectory(whitepaper, workingDirectory);
            }
        }

        private void CopyPackageToWorkingDirectory(string workingDirectory, Package package)
        {
            if (!Directory.Exists(workingDirectory))
            {
                Directory.CreateDirectory(workingDirectory);
            }

            var newPackagePath = Path.Combine(workingDirectory, Path.GetFileName(package.Location));

            DirectoryHelper.CopyFile(package.Location, newPackagePath, true);

            // update Asset file references
            if (!string.IsNullOrEmpty(this.AssetDirectories))
            {
                var assetsPaths = this.AssetDirectories.Split(';');

                foreach (var item in assetsPaths)
                {
                    var assetsPath = item;

                    if (PathsHelper.IsRootedPath(assetsPath))
                    {
                        assetsPath = PathsHelper.RelativePathTo(Path.GetDirectoryName(package.Location), assetsPath);
                    }

                    Logger.Log(LogLevel.Debug, "Updating asset file references from " + assetsPath + " to Assets in " + newPackagePath + "...");
                    this.packageHelper.UpdateAssetPaths(newPackagePath, assetsPath);
                }
            }

            if (package.Overview != null && !String.IsNullOrEmpty(package.Overview.Document.RelativePath))
            {
                string overviewDoc = Path.Combine(Path.GetDirectoryName(package.Location), package.Overview.Document.RelativePath);

                if (!File.Exists(overviewDoc))
                {
                    throw new ContentFrameworkException("Overview document does not exist: " + overviewDoc, "Ensure the Package.xml metadata has a valid path to the overview document");
                }

                DirectoryHelper.CopyFile(overviewDoc, Path.Combine(workingDirectory, Path.GetFileName(overviewDoc)), true);
            }
        }

        private void CopyContentToWorkingDirectory(DocumentMetadata document, string workingDirectory)
        {
            string sourcePath = document.OriginalDirectory;
            string destinationPath = Path.Combine(workingDirectory, document.DestinationPath);
            DirectoryHelper.CopyDirectory(sourcePath, destinationPath, this.Excludes);
        }

        private void CopyVideoToWorkingDirectory(Video video, string workingDirectory)
        {
            string sourcePath = video.OriginalDirectory;
            string destinationPath = Path.Combine(workingDirectory, video.DestinationPath);
            var videoExcludes = new List<string>();

            if (!string.IsNullOrEmpty(video.VideoUrl)
                || (video.Document != null && video.Document.ExcludeSource))
            {
                videoExcludes.Add(video.Document.AbsolutePath);
            }

            DirectoryHelper.CopyDirectory(sourcePath, destinationPath, this.Excludes, videoExcludes.ToArray());
        }
    }
}
