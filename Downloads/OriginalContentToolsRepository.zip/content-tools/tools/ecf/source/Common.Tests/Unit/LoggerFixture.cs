﻿namespace Microsoft.Dpe.Ecf.Common.Tests
{
    using System;
    using System.IO;
    using System.Threading;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    [DeploymentItem("Resources")]
    public class LoggerFixture
    {
        private const string ConfigFile = "contentFramework.config";

        [TestMethod]
        public void ShouldInitializeLogger()
        {
            Assert.IsTrue(File.Exists(ConfigFile));
            Logger.Log(LogLevel.Information, String.Empty);
        }       

        [TestMethod]
        public void ShouldLogMessage()
        {
            Assert.IsTrue(File.Exists(ConfigFile));
            Logger.Log(LogLevel.Information, "Dummy message");
        }

        [TestMethod]
        public void ShouldLogException()
        {
            Assert.IsTrue(File.Exists(ConfigFile));
            Logger.Log(LogLevel.Error, new ArgumentException("Dummy message"));
        }

        [TestMethod]
        public void ShouldLogExceptionWithCustomMessage()
        {
            Assert.IsTrue(File.Exists(ConfigFile));
            Logger.Log(LogLevel.Warning, new ArgumentException("Dummy message"), "Additional dummy info");
        }

        [TestMethod]
        public void ShouldLogToFile()
        {
            Assert.IsTrue(File.Exists(ConfigFile), "Missing Configuration File");
            
            Logger.Log(LogLevel.Warning, new ArgumentException("Dummy Message for the file"), "Additional info to be Logged");
            Logger.Log(LogLevel.Information, "Dummy Information for the file");
            Logger.Log(LogLevel.Error, "Dummy Error for the file");

            Assert.IsTrue(File.Exists("log.txt"), "Log file was not created");
            string fileContent = File.ReadAllText("log.txt");

            // Check that the messages and errors where logged.
            Assert.IsTrue(fileContent.Contains("Message for the file"), "Message was not logged in the file");
            Assert.IsTrue(fileContent.Contains("Additional info to be Logged"));
            Assert.IsTrue(fileContent.Contains("Dummy Information for the file"));
            Assert.IsTrue(fileContent.Contains("Dummy Error for the file"));

            // check that previous messages were not overwriten
            Assert.IsTrue(fileContent.Contains("Already existing message"), "Previous entries were deleted");
        }

        [TestMethod]
        public void ShouldLogToXml()
        {
            Assert.IsTrue(File.Exists(ConfigFile), "Missing Configuration File");

            Logger.Log(LogLevel.Warning, new ArgumentException("Dummy Message for the file"), "Additional info to be Logged");
            Logger.Log(LogLevel.Information, "Dummy Information for the file");
            Logger.Log(LogLevel.Error, "Dummy Error for the file");

            Assert.IsTrue(File.Exists("log.xml"), "Log file was not created");
            string fileContent = File.ReadAllText("log.xml");

            // Check that the messages and errors where logged.
            Assert.IsTrue(fileContent.Contains("Message for the file"), "Message was not logged in the file");
            Assert.IsTrue(fileContent.Contains("Additional info to be Logged"));
            Assert.IsTrue(fileContent.Contains("Dummy Information for the file"));
            Assert.IsTrue(fileContent.Contains("Dummy Error for the file"));

            // check that previous messages were not overwriten
            Assert.IsTrue(fileContent.Contains("Already existing message"), "Previous entries were deleted");
        }

        [TestMethod]
        public void ShouldLogSourceToFile()
        {
            Assert.IsTrue(File.Exists(ConfigFile), "Missing Configuration File");

            Logger.SetCurrentSource("testsource");
            Logger.Log(LogLevel.Warning, new ArgumentException("Dummy Message for the file"), "Additional info to be Logged");
            Logger.Log(LogLevel.Information, "Dummy Information for the file");
            Logger.Log(LogLevel.Error, "Dummy Error for the file");

            Assert.IsTrue(File.Exists("testsource-log.txt"), "Log file was not created");
            string fileContent = File.ReadAllText("testsource-log.txt");

            // Check that the messages and errors where logged.
            Assert.IsTrue(fileContent.Contains("Message for the file"), "Message was not logged in the file");
            Assert.IsTrue(fileContent.Contains("Additional info to be Logged"));
            Assert.IsTrue(fileContent.Contains("Dummy Information for the file"));
            Assert.IsTrue(fileContent.Contains("Dummy Error for the file"));

            // check that previous messages were not overwriten
            Assert.IsTrue(fileContent.Contains("Already existing message"), "Previous entries were deleted");
        }

        [TestMethod]
        public void ShouldLogSourceToXml()
        {
            Assert.IsTrue(File.Exists(ConfigFile), "Missing Configuration File");

            Logger.SetCurrentSource("testxmlsource");
            Logger.Log(LogLevel.Warning, new ArgumentException("Dummy Message for the file"), "Additional info to be Logged");
            Logger.Log(LogLevel.Information, "Dummy Information for the file");
            Logger.Log(LogLevel.Error, "Dummy Error for the file");

            Assert.IsTrue(File.Exists("testxmlsource-log.xml"), "Log file was not created");
            string fileContent = File.ReadAllText("testxmlsource-log.xml");

            // Check that the messages and errors where logged.
            Assert.IsTrue(fileContent.Contains("Message for the file"), "Message was not logged in the file");
            Assert.IsTrue(fileContent.Contains("Additional info to be Logged"));
            Assert.IsTrue(fileContent.Contains("Dummy Information for the file"));
            Assert.IsTrue(fileContent.Contains("Dummy Error for the file"));

            // check that previous messages were not overwriten
            Assert.IsTrue(fileContent.Contains("Already existing message"), "Previous entries were deleted");
        }

        [TestMethod]
        public void ShouldLogMultipleSources()
        {
            Assert.IsTrue(File.Exists(ConfigFile), "Missing Configuration File");

            var sourceThread1 = new Thread(() =>
                {
                    Logger.SetCurrentSource("testmultiplesources1");
                    Logger.Log(LogLevel.Warning, new ArgumentException("Dummy Message for the file"), "Additional info to be Logged");
                    Logger.Log(LogLevel.Information, "Dummy Information for the file");
                    Logger.Log(LogLevel.Error, "Dummy Error for the file");
                });

            var sourceThread2 = new Thread(() =>
            {
                Logger.SetCurrentSource("testmultiplesources2");
                Logger.Log(LogLevel.Warning, new ArgumentException("Dummy Message for the file"), "Additional info to be Logged");
                Logger.Log(LogLevel.Information, "Dummy Information for the file");
                Logger.Log(LogLevel.Error, "Dummy Error for the file");
            });

            sourceThread1.Start();
            sourceThread2.Start();
            sourceThread1.Join();
            sourceThread2.Join();

            Assert.IsTrue(File.Exists("testmultiplesources1-log.xml"), "Log file was not created");
            Assert.IsTrue(File.Exists("testmultiplesources2-log.xml"), "Log file was not created");
            Assert.IsTrue(File.Exists("testmultiplesources1-log.txt"), "Log file was not created");
            Assert.IsTrue(File.Exists("testmultiplesources2-log.txt"), "Log file was not created");
        }
    }
}
