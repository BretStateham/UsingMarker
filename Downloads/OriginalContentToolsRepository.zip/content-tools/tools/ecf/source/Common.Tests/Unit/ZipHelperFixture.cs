﻿namespace Microsoft.Dpe.Ecf.Common.Tests
{
    using System.IO;
    using Microsoft.Dpe.Ecf.Common.Helpers;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    [DeploymentItem(@"Resources\ZipHelperFixture", "ZipHelperFixture")]
    public class ZipHelperFixture
    {
        [TestMethod]
        public void ShouldZipFolder()
        {
            ZipHelper.ZipFolder(@"ZipHelperFixture\ContentToZip", "ZippedContent.zip");

            Assert.IsTrue(File.Exists("ZippedContent.zip"));

            File.Delete("ZippedContent.zip");
        }

        [TestMethod]
        public void ShouldZipFile()
        {
            ZipHelper.ZipFile(@"ZipHelperFixture\ContentToZip\SubFolder2\WordDoc.docx", "ZippedWordDoc.zip");

            Assert.IsTrue(File.Exists("ZippedWordDoc.zip"));

            File.Delete("ZippedWordDoc.zip");
        }

        [TestMethod]
        public void ShouldZipFolderExcluding()
        {
            string[] excludes = new string[] { ".svn", "exc", "*.obj" };

            ZipHelper.ZipFolder(@"ZipHelperFixture\ContentToZip", "ZippedContent.zip", excludes);

            Assert.IsTrue(File.Exists("ZippedContent.zip"));

            ZipHelper.Unzip("ZippedContent.zip", "UnzippedContent");
            
            // check the excluded does not exists
            Assert.IsFalse(Directory.Exists("UnzippedContent\\.svn"));
            Assert.IsFalse(Directory.Exists("UnzippedContent\\exc"));
            Assert.IsFalse(File.Exists("UnzippedContent\\SubFolder1\\toBeExcluded.obj"));

            // Delete things
            Directory.Delete("UnzippedContent", true);
            File.Delete("ZippedContent.zip");
        }
    }
}
