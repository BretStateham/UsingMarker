﻿namespace Microsoft.Dpe.Ecf.Common.Tests.Unit
{
    using Microsoft.Dpe.Ecf.Common.Helpers;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class DirectoryHelperFixture
    {
        [TestMethod]
        public void ShouldResolveAbsolutePath()
        {
            var absolutePath = DirectoryHelper.ResolveRelativePaths(@"C:\Temp\file.txt");
            var expected = @"C:\Temp\file.txt";
            Assert.AreEqual(expected, absolutePath);
        }

        [TestMethod]
        public void ShouldResolveShortRootedRelativePath()
        {
            var absolutePath = DirectoryHelper.ResolveRelativePaths(@"C:\Temp\..\file.txt");
            var expected = @"C:\file.txt";
            Assert.AreEqual(expected, absolutePath);
        }

        [TestMethod]
        public void ShouldResolveShortNonRootedRelativePath()
        {
            var absolutePath = DirectoryHelper.ResolveRelativePaths(@"Temp\AnotherTemp\..\file.txt");
            var expected = @"Temp\file.txt";
            Assert.AreEqual(expected, absolutePath);
        }

        [TestMethod]
        public void ShouldResolveDoubleNonRootedRelativePath()
        {
            var absolutePath = DirectoryHelper.ResolveRelativePaths(@"Temp\AnotherTemp\..\..\file.txt");
            var expected = @"file.txt";
            Assert.AreEqual(expected, absolutePath);
        }

        [TestMethod]
        public void ShouldResolveComplexNonRootedRelativePath()
        {
            var absolutePath = DirectoryHelper.ResolveRelativePaths(@"Temp\.\AnotherTemp\.\..\YetAnotherTemp\..\file.txt");
            var expected = @"Temp\file.txt";
            Assert.AreEqual(expected, absolutePath);
        }

        [TestMethod]
        public void ShouldResolveNonRootedRelativePathWhichStartsWithDoubleDot()
        {
            var absolutePath = DirectoryHelper.ResolveRelativePaths(@"..\Temp\file.txt");
            var expected = @"Temp\file.txt";
            Assert.AreEqual(expected, absolutePath);
        }

        [TestMethod]
        public void ShouldResolveRootedLongRelativePath()
        {
            var relativePath = @"..\Temp\";
            while (relativePath.Length < 260)
            {
                relativePath += relativePath;
            }

            relativePath = @"C:\" + relativePath + "file.txt";
            var absolutePath = DirectoryHelper.ResolveRelativePaths(relativePath);
            var expected = @"C:\Temp\file.txt";
            Assert.AreEqual(expected, absolutePath);
        }
    }
}
