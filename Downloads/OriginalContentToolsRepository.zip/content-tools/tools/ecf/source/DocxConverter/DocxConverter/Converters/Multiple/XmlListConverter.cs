// ===============================================================================
// Microsoft patterns & practices
// Documentation Tools - January 2008 
//-------------------------------------------------------------------------------
// Copyright �  Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//-------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ===============================================================================

namespace Microsoft.Practices.DocxConverter.ElementConverters
{
    using System.Xml;
    using System.Xml.XPath;
    using Microsoft.Practices.DocxConverter.Converters;

    public abstract class XmlListConverter : MultipleNodesConverter
    {
        public override IConverter ItemConverter
        {
            get
            {
                return ConverterFactory.CreateConverter(typeof(XmlListItemConverter), this.XmlConverterService);
            }
        }

        protected abstract string ElementName
        {
            get;
        }

        protected override void ConvertCore(XPathNodeIterator iterator, XmlWriter writer)
        {
            // We look "in the future" for the next element that we will convert
            // if there is a node to convert, we create the converter. Then we check the indentation
            // level that applies to that node and if it's less than the current indentation
            // we break the loop. Otherwise we use the ItemConverter for the same indentation level
            // or we use the regular Convert if the indentation level is greater                    
            bool childElementsFound = true;

            writer.WriteStartElement(this.ElementName);
            this.ItemConverter.Convert(iterator, writer);

            while (childElementsFound && iterator.Current is IHasXmlNode)
            {
                XmlNode node = ((IHasXmlNode)iterator.Current).GetNode().NextSibling;
                if (node != null)
                {
                    IConverter converter = ConverterFactory.CreateConverter(node, this.XmlConverterService);
                    if ((converter.IndentationLevel < IndentationLevel && !XmlConverterService.IsParagraphEmpty(node)) ||
                         typeof(XmlListEndConverter).IsAssignableFrom(ConverterFactory.GetConverterType(node)))
                    {                            
                        childElementsFound = false;
                    }
                    else
                    {
                        if (!iterator.MoveNext())
                        {
                            break;
                        }
                        
                        if (typeof(XmlListConverter).IsAssignableFrom(converter.GetType())
                            && converter.IndentationLevel == IndentationLevel)
                        {
                            (converter as XmlListConverter).ItemConverter.Convert(iterator, writer);
                        }
                        else
                        {
                            converter.Convert(iterator, writer);
                        }
                    }
                }
                else
                {
                    childElementsFound = false;
                }
            }

            writer.WriteEndElement(); // ElementName
        }
    }
}
