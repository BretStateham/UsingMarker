// ===============================================================================
// Microsoft patterns & practices
// Documentation Tools - January 2008 
//-------------------------------------------------------------------------------
// Copyright �  Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//-------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ===============================================================================

namespace Microsoft.Practices.DocxConverter.ElementConverters
{
    using System;
    using System.Xml;
    using System.Xml.XPath;
    using Microsoft.Practices.DocxConverter.Converters;

    public class XmlListItemConverter : MultipleNodesConverter
    {
        public XmlListItemConverter()
        {
        }

        public override IConverter ItemConverter
        {
            get
            {
                return ConverterFactory.CreateConverter(typeof(XmlListItemTitleConverter), this.XmlConverterService);
            }
        }

        protected override void ConvertCore(XPathNodeIterator iterator, XmlWriter writer)
        {
            writer.WriteStartElement("step");

            this.ItemConverter.Convert(iterator, writer);

            writer.WriteStartElement("contents");

            while (iterator.Current is IHasXmlNode)
            {
                XmlNode node = ((IHasXmlNode)iterator.Current).GetNode().NextSibling;
                if (node == null)
                {
                    break;
                }

                int currentLevel = ConverterFactory.GetIndentationLevel(((IHasXmlNode)iterator.Current).GetNode());

                Type converterType = ConverterFactory.GetConverterType(node);
                IConverter converter = ConverterFactory.CreateConverter(node, this.XmlConverterService);

                if ((converter.IndentationLevel < currentLevel) ||
                    typeof(XmlListEndConverter).IsAssignableFrom(converterType))
                {
                    break;
                }

                if (converter.IndentationLevel == currentLevel &&
                    typeof(XmlListConverter).IsAssignableFrom(converterType))
                {
                    break;
                }

                if (!iterator.MoveNext())
                {
                    break;
                }

                converter.Convert(iterator, writer);
            }

            writer.WriteEndElement(); // </contents>
            writer.WriteEndElement(); // </step>
        }

        private class XmlListItemTitleConverter : XmlParagraphConverter
        {
            protected override string ElementName
            {
                get { return "title"; }
            }
        }
    }
}
