// ===============================================================================
// Microsoft patterns & practices
// Documentation Tools - January 2008 
//-------------------------------------------------------------------------------
// Copyright �  Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//-------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ===============================================================================

namespace Microsoft.Practices.DocxConverter
{
    using System;
    using System.Xml;
    using System.Xml.XPath;

    public abstract class MultipleNodesConverter : BaseConverter
    {
        public abstract IConverter ItemConverter
        {
            get;
        }

        public override void Convert(XPathNodeIterator iterator, XmlWriter writer)
        {
            if (iterator == null)
            {
                throw new ArgumentNullException("iterator");
            }

            if (writer == null)
            {
                throw new ArgumentNullException("writer");
            }

            try
            {
                this.ConvertCore(iterator, writer);
            }
            catch (SplitDocumentConverterException e)
            {
                SetExceptionText(iterator, e);
                throw;
            }
            catch (Exception e)
            {
                SplitDocumentConverterException ex = new SplitDocumentConverterException(e);
                SetExceptionText(iterator, ex);                
                throw ex;
            }
        }

        protected abstract void ConvertCore(XPathNodeIterator iterator, XmlWriter writer);

        private static void SetExceptionText(XPathNodeIterator iterator, SplitDocumentConverterException e)
        {
            if (iterator.Current is IHasXmlNode)
            {
                XmlNode node = ((IHasXmlNode)iterator.Current).GetNode();

                if (node != null)
                {
                    e.Text = node.InnerText;
                }
            }
        }
    }
}
