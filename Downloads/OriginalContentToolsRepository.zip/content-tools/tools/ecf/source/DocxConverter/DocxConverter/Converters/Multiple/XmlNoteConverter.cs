// ===============================================================================
// Microsoft patterns & practices
// Documentation Tools - January 2008 
//-------------------------------------------------------------------------------
// Copyright �  Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//-------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ===============================================================================

namespace Microsoft.Practices.DocxConverter.ElementConverters
{
    using System;
    using System.Xml;
    using System.Xml.XPath;
    using Microsoft.Practices.DocxConverter.Converters;

    public class XmlNoteConverter : MultipleNodesConverter
    {        
        public override IConverter ItemConverter
        {
            get
            {
                return ConverterFactory.CreateConverter(typeof(XmlNoteItemConverter), this.XmlConverterService);
            }
        }

        protected override void ConvertCore(XPathNodeIterator iterator, XmlWriter writer)
        {
            // We look "in the future" for the next element that we will convert
            // if there is a node to convert, we create the converter. Then we check:
            // 1. If the converter corresponding to that node has the same type as the actual converter.
            // 2. If the indentation level that applies to that node is not less than the current indentation
            // In case that 1 and 2 could not be satisfied, we break the loop. Otherwise we use the ItemConverter 
            // for the same or greater indentation level.
            writer.WriteStartElement("note");

            writer.WriteStartElement("title");
            writer.WriteString("Note:");
            writer.WriteEndElement();

            writer.WriteStartElement("text");

            this.ItemConverter.Convert(iterator, writer);

            while (iterator.Current is IHasXmlNode)
            {
                XmlNode node = ((IHasXmlNode)iterator.Current).GetNode().NextSibling;
                if (node == null || !CanConvert<XmlNoteConverter>(IndentationLevel, node))
                {
                    break;
                }
                
                writer.WriteStartElement("br");
                writer.WriteEndElement();

                if (!iterator.MoveNext())
                {
                    break;
                }

                this.ItemConverter.Convert(iterator, writer);                            
            }

            writer.WriteEndElement(); // </text>
            writer.WriteEndElement(); // </note>
        }

        private static bool CanConvert<TConverter>(int currentLevel, XmlNode nodeToConvert) where TConverter : IConverter
        {
            Type type = ConverterFactory.GetConverterType(nodeToConvert);
            int nextLevel = ConverterFactory.GetIndentationLevel(nodeToConvert);

            return typeof(TConverter).IsAssignableFrom(type) && nextLevel >= currentLevel;
        }        
    }
}
