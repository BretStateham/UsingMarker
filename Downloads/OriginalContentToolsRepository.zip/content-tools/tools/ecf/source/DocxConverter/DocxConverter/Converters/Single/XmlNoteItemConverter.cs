// ===============================================================================
// Microsoft patterns & practices
// Documentation Tools - January 2008 
//-------------------------------------------------------------------------------
// Copyright �  Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//-------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ===============================================================================

namespace Microsoft.Practices.DocxConverter.ElementConverters
{
    using System;
    using System.Xml;

    public class XmlNoteItemConverter : SingleNodeConverter
    {
        protected override void ConvertCore(XmlNode node, XmlWriter writer)
        {
            if (String.Compare(node.LocalName, "p", StringComparison.OrdinalIgnoreCase) != 0)
            {
                throw new NotSupportedException(Resources.ErrorMessages.NoteConverterErrorNoteParagraphExpected);
            }

            XmlNode nodeWithNote = node.SelectSingleNode("descendant-or-self::w:r[w:t[starts-with(text(),'Note:')]]", GetNamespaceManager(node.OwnerDocument));
            if (nodeWithNote != null)
            {
                if (nodeWithNote.SelectSingleNode("w:rPr/w:b", GetNamespaceManager(node.OwnerDocument)) == null)
                {
                    writer.WriteString("Error: Note format was corrupted. Title should be bold.");
                }

                nodeWithNote.RemoveAll();
            }

            XmlConverterService.ConvertParagraph(node, writer);
        }
    }
}
