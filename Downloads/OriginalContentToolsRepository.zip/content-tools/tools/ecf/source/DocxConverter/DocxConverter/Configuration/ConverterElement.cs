﻿namespace Microsoft.Practices.DocxConverter.Configuration
{
    using System.Configuration;
    using System.Diagnostics.CodeAnalysis;

    public sealed class ConverterElement : ConfigurationElement
    {
        [ConfigurationProperty("path", IsKey = true, IsRequired = true)]
        public string Path
        {
            get
            {
                return (string)base["path"];
            }

            set
            {
                base["path"] = value;
            }
        }

        [ConfigurationProperty("type", IsRequired = true)]
        [SuppressMessage("Microsoft.Naming", "CA1721", Justification = "should be added to dictionary")]
        public string Type
        {
            get
            {
                return (string)base["type"];
            }

            set
            {
                base["type"] = value;
            }
        }

        [ConfigurationProperty("level", IsRequired = false)]
        public int Level
        {
            get
            {
                return (int)base["level"];
            }

            set
            {
                base["level"] = value;
            }
        }
    }
}
