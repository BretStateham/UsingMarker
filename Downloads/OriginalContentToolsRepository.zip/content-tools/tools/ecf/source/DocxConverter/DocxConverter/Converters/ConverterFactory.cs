// ===============================================================================
// Microsoft patterns & practices
// Documentation Tools - January 2008 
//-------------------------------------------------------------------------------
// Copyright �  Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//-------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ===============================================================================

namespace Microsoft.Practices.DocxConverter.Converters
{
    using System;
    using System.Diagnostics.CodeAnalysis;
    using System.Xml;
    using Microsoft.Practices.DocxConverter.ElementConverters;

    public static class ConverterFactory
    {
        private static string configurationPath;

        public static string ConfigurationPath
        {
            get { return configurationPath; }
            set { configurationPath = value; }
        }

        [SuppressMessage("Microsoft.Design", "CA1059", Justification = "Should be added to dictionary")]
        public static IConverter CreateConverter(XmlNode node, XmlConverterService converterService) 
        {
            if (node == null)
            {
                throw new ArgumentNullException("node");
            }

            XmlElementConverterFactory factory = new XmlElementConverterFactory(OpenXmlHelper.GetNamespaceManager(node.OwnerDocument), configurationPath);
            IConverter converter = factory.CreateConverter(node);
            if (converter is BaseConverter)
            {
                ((BaseConverter)converter).XmlConverterService = converterService;
            }

            return converter;
        }

        [SuppressMessage("Microsoft.Design", "CA1059", Justification = "Should be added to dictionary")]
        public static IConverter CreateConverter(Type converterType, XmlConverterService converterService) 
        {
            if (converterType == null)
            {
                throw new ArgumentNullException("converterType");
            }

            if (converterService == null)
            {
                throw new ArgumentNullException("converterService");
            }

            var converter = (IConverter)Activator.CreateInstance(converterType);
            if (converter is BaseConverter)
            {
                ((BaseConverter)converter).XmlConverterService = converterService;
            }

            return converter;
        }

        [SuppressMessage("Microsoft.Design", "CA1059", Justification = "Should be added to dictionary")]
        public static Type GetConverterType(XmlNode node)
        {
            if (node == null)
            {
                throw new ArgumentNullException("node");
            }

            XmlElementConverterFactory factory = new XmlElementConverterFactory(OpenXmlHelper.GetNamespaceManager(node.OwnerDocument), configurationPath);
            Type type = factory.GetConverterType(node);
            return type;
        }

        [SuppressMessage("Microsoft.Design", "CA1059", Justification = "Should be added to dictionary")]
        public static int GetIndentationLevel(XmlNode node)
        {
            if (node == null)
            {
                throw new ArgumentNullException("node");
            }

            XmlElementConverterFactory factory = new XmlElementConverterFactory(OpenXmlHelper.GetNamespaceManager(node.OwnerDocument), configurationPath);
            int level = factory.GetIndentationLevel(node);
            return level;
        }
    }
}
