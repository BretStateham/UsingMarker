// ===============================================================================
// Microsoft patterns & practices
// Documentation Tools - January 2008 
//-------------------------------------------------------------------------------
// Copyright �  Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//-------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ===============================================================================

namespace Microsoft.Practices.DocxConverter.Configuration
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Configuration;

    public sealed class ConvertersCollection : ConfigurationElementCollection, ICollection<ConverterElement>
    {
        public new bool IsReadOnly
        {
            get { return base.IsReadOnly(); }
        }

        protected override string ElementName
        {
            get
            {
                return "add";
            }
        }

        public void Add(ConverterElement item)
        {
            BaseAdd(item);
        }

        public void Clear()
        {
            BaseClear();
        }

        public bool Contains(ConverterElement item)
        {
            return this.BaseIndexOf(item) != -1;
        }

        public void CopyTo(ConverterElement[] array, int arrayIndex)
        {
            base.CopyTo(array, arrayIndex);
        }

        public bool Remove(ConverterElement item)
        {
            if (item == null)
            {
                throw new ArgumentNullException("item");
            }

            if (this.Contains(item))
            {
                this.BaseRemove(item.Path);
                return true;
            }

            return false;
        }

        public new IEnumerator<ConverterElement> GetEnumerator()
        {
            IEnumerator enumarator = base.GetEnumerator();
            while (enumarator.MoveNext())
            {
                yield return enumarator.Current as ConverterElement;
            }
        }

        protected override ConfigurationElement CreateNewElement()
        {
            return new ConverterElement();
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            return ((ConverterElement)element).Path;
        }
    }
}
