// ===============================================================================
// Microsoft patterns & practices
// Documentation Tools - January 2008 
//-------------------------------------------------------------------------------
// Copyright �  Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//-------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ===============================================================================

namespace Microsoft.Practices.DocxConverter.ElementConverters
{
    using System;
    using System.Xml;

    public class XmlCodeBlockItemConverter : SingleNodeConverter
    {
        protected override void ConvertCore(XmlNode node, XmlWriter writer)
        {
            writer.WriteStartElement("line");
            if (String.Compare(node.LocalName, "p", StringComparison.OrdinalIgnoreCase) != 0)
            {
                writer.WriteString("Could not convert node");
            }
            else
            {
                XmlConverterService.ConvertParagraph(node, writer);
            }

            writer.WriteEndElement();
        }
    }
}
