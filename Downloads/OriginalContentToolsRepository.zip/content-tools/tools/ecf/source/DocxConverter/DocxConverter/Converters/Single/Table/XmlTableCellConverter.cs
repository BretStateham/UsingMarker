// ===============================================================================
// Microsoft patterns & practices
// Documentation Tools - January 2008 
//-------------------------------------------------------------------------------
// Copyright �  Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//-------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ===============================================================================

namespace Microsoft.Practices.DocxConverter.ElementConverters
{
    using System;
    using System.Diagnostics.CodeAnalysis;
    using System.Globalization;
    using System.Xml;
    using System.Xml.XPath;
    using Microsoft.Practices.DocxConverter.Converters;

    public abstract class XmlTableCellConverter : SingleNodeConverter
    {
        protected abstract string ElementName
        {
            get;
        }

        [SuppressMessage("Microsoft.Design", "CA1059", Justification = "Should be added to dictionary")]
        protected static int GetNumbersOfMergedRows(XmlNode node)
        {
            if (node == null)
            {
                throw new ArgumentNullException("node");
            }

            int rows = 1;
            int colPosition = node.SelectNodes("preceding-sibling::w:tc", OpenXmlHelper.GetNamespaceManager(node.OwnerDocument)).Count;

            foreach (XmlNode rowNode in node.ParentNode.SelectNodes("following-sibling::w:tr", OpenXmlHelper.GetNamespaceManager(node.OwnerDocument)))
            {
                int colPos = 0;
                foreach (XmlNode colNode in rowNode.SelectNodes("w:tc", OpenXmlHelper.GetNamespaceManager(node.OwnerDocument)))
                {
                    if (colPos == colPosition)
                    {
                        XmlNode mergeNode = colNode.SelectSingleNode("w:tcPr/w:vMerge", OpenXmlHelper.GetNamespaceManager(node.OwnerDocument));

                        if (mergeNode == null)
                        {
                            return rows;
                        }
                        else if (mergeNode.SelectSingleNode("@w:val", OpenXmlHelper.GetNamespaceManager(node.OwnerDocument)) != null)
                        {
                            return rows;
                        }

                        rows++;
                    }

                    colPos++;
                }
            }

            return rows;
        }

        protected abstract bool IsValidConverter(IConverter converter);

        protected override void ConvertCore(XmlNode node, XmlWriter writer)
        {
            if (node == null)
            {
                throw new ArgumentNullException("node");
            }

            if (writer == null)
            {
                throw new ArgumentNullException("writer");
            }

            if (node.SelectSingleNode("./w:tcPr/w:vMerge", GetNamespaceManager(node.OwnerDocument)) != null
                && node.SelectSingleNode("w:tc/w:tcPr/w:vMerge/@w:val", GetNamespaceManager(node.OwnerDocument)) == null
                && String.IsNullOrEmpty(node.InnerText))
            {
                return;
            }

            writer.WriteStartElement(this.ElementName);            
            
            XPathNavigator navigator = node.CreateNavigator();
            XPathNodeIterator iterator = navigator.SelectChildren(XPathNodeType.Element);            

            if (node.SelectSingleNode("w:tcPr/w:gridSpan", GetNamespaceManager(node.OwnerDocument)) != null)
            {
                writer.WriteAttributeString("colspan", node.SelectSingleNode("w:tcPr/w:gridSpan/@w:val", GetNamespaceManager(node.OwnerDocument)).Value);
            }

            if (node.SelectSingleNode("w:tcPr/w:vMerge/@w:val", GetNamespaceManager(node.OwnerDocument)) != null)
            {
                int rows = GetNumbersOfMergedRows(node);
                writer.WriteAttributeString("rowspan", rows.ToString(CultureInfo.InvariantCulture));
            }

            while (iterator.MoveNext())
            {
                if (iterator.Current is IHasXmlNode)
                {
                    XmlNode childNode = ((IHasXmlNode)iterator.Current).GetNode();
                    IConverter converter = ConverterFactory.CreateConverter(childNode, this.XmlConverterService);

                    if (this.IsValidConverter(converter))
                    {
                        converter.Convert(iterator, writer);
                    }
                    else
                    {
                        writer.WriteString("Conversion Error: Invalid style applied inside cell");
                    }
                }
            }

            writer.WriteEndElement();
        }
    }
}
