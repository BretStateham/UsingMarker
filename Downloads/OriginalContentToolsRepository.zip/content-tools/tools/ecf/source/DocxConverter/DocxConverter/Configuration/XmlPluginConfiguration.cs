// ===============================================================================
// Microsoft patterns & practices
// Documentation Tools - January 2008 
//-------------------------------------------------------------------------------
// Copyright �  Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//-------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ===============================================================================

namespace Microsoft.Practices.DocxConverter
{
    using System;
    using System.Configuration;
    using System.Diagnostics.CodeAnalysis;
    using System.Xml;
    using Microsoft.Practices.DocxConverter.Configuration;

    [SuppressMessage("Microsoft.Naming", "CA1704", Justification = "Should be added to dictionary")]
    public class XmlPluginConfiguration
    {
        private ConvertersCollection converters;
        private XmlNamespaceManager nsm;

        [SuppressMessage("Microsoft.Naming", "CA1704", Justification = "Should be added to dictionary")]
        public XmlPluginConfiguration(string configurationPath, string sectionPath, XmlNamespaceManager nsm)
        {
            if (!string.IsNullOrEmpty(configurationPath))
            {
                ExeConfigurationFileMap map = new ExeConfigurationFileMap();
                map.ExeConfigFilename = configurationPath;
                System.Configuration.Configuration config =
                    ConfigurationManager.OpenMappedExeConfiguration(map, ConfigurationUserLevel.None);
                ConvertersSection convertersSection = (ConvertersSection)config.GetSection(sectionPath);
                if (convertersSection == null)
                {
                    throw new ConfigurationErrorsException(Resources.ErrorMessages.PLuginConfNotFoundConf);
                }

                this.converters = convertersSection.Converters;
            }
            else
            {
                this.converters = DefaultConfiguration.Converters;
            }

            this.nsm = nsm;
        }

        public ConvertersCollection Converters
        {
            get { return this.converters; }
        }

        [SuppressMessage("Microsoft.Naming", "CA1704", Justification = "Should be added to dictionary")]
        public XmlNamespaceManager Nsm
        {
            get { return this.nsm; }
        }
                
        [SuppressMessage("Microsoft.Design", "CA1059", Justification = "Should be added to dictionary")]
        public ConverterElement GetConverterElement(XmlNode node)
        {
            if (node == null)
            {
                throw new ArgumentNullException("node");
            }

            ConverterElement retConverter = null;

            foreach (ConverterElement converterElement in this.converters)
            {
                try
                {
                    if (node.SelectSingleNode(converterElement.Path, this.nsm) != null)
                    {
                        retConverter = converterElement;
                        break;
                    }
                }
                catch
                {
                    throw new NotSupportedException(Resources.ErrorMessages.PluginConfInvalidPathExpr);
                }
            }

            return retConverter;
        }
    }
}
