﻿namespace Microsoft.Practices.DocxConverter.Configuration
{
    using System.Configuration;

    public sealed class ConvertersSection : ConfigurationSection
    {
        public ConvertersSection()
        {
        }

        [ConfigurationProperty("", IsDefaultCollection = true)]
        public ConvertersCollection Converters
        {
            get
            {
                return (ConvertersCollection)base[string.Empty];
            }
        }
    }
}
