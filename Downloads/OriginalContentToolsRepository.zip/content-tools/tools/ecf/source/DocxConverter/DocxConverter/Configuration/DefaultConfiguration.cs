﻿namespace Microsoft.Practices.DocxConverter.Configuration
{
    public static class DefaultConfiguration
    {
        private static ConvertersCollection defaultConverters = InitDefaultConverters();

        public static ConvertersCollection Converters
        {
            get
            {
                return defaultConverters;
            }
        }

        private static ConvertersCollection InitDefaultConverters()
        {
            ConvertersCollection converters = new ConvertersCollection();

            converters.Add(new ConverterElement() { Path = "w:sdtContent/w:p/w:pPr/w:pStyle[@w:val='ppTopic']", Level = 0, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlSubtopicConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p[count(w:pPr/w:pStyle)=0]|self::w:sdt//w:p[count(w:pPr/w:pStyle)=0]", Level = 0, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlBodyTextConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppBodyText']|self::w:sdt//w:p/w:pPr/w:pStyle[@w:val='ppBodyText']", Level = 0, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlBodyTextConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppBodyTextIndent']|self::w:sdt//w:p/w:pPr/w:pStyle[@w:val='ppBodyTextIndent']", Level = 1, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlBodyTextConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppBodyTextIndent2']|self::w:sdt//w:p/w:pPr/w:pStyle[@w:val='ppBodyTextIndent2']", Level = 2, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlBodyTextConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppBodyTextIndent3']|self::w:sdt//w:p/w:pPr/w:pStyle[@w:val='ppBodyTextIndent3']", Level = 3, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlBodyTextConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ListParagraph']|self::w:sdt//w:p/w:pPr/w:pStyle[@w:val='ListParagraph']", Level = 0, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlBodyTextConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppFigure']", Level = 0, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlBodyTextConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppFigureIndent']", Level = 1, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlBodyTextConverter, Microsoft.Practices.DocxConverter" });     
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppFigureIndent2']", Level = 2, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlBodyTextConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppFigureIndent3']", Level = 3, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlBodyTextConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppFigureNumber']", Level = 0, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlFigureNumberConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppFigureNumberIndent']", Level = 1, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlFigureNumberConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppFigureNumberIndent2']", Level = 2, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlFigureNumberConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppFigureNumberIndent3']", Level = 3, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlFigureNumberConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppFigureCaption']", Level = 0, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlFigureCaptionConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppFigureCaptionIndent']", Level = 1, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlFigureCaptionConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppFigureCaptionIndent2']", Level = 2, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlFigureCaptionConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppFigureCaptionIndent3']", Level = 3, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlFigureCaptionConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppNumberList']|self::w:sdt//w:p/w:pPr/w:pStyle[@w:val='ppNumberList']", Level = 1, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlNumberListConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppNumberListIndent']|self::w:sdt//w:p/w:pPr/w:pStyle[@w:val='ppNumberListIndent']", Level = 2, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlNumberListConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppNumberListIndent2']|self::w:sdt//w:p/w:pPr/w:pStyle[@w:val='ppNumberListIndent2']", Level = 3, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlNumberListConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppNumberListIndent3']|self::w:sdt//w:p/w:pPr/w:pStyle[@w:val='ppNumberListIndent3']", Level = 4, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlNumberListConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppListEnd']", Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlListEndConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppNote']", Level = 0, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlNoteConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppNoteIndent']", Level = 1, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlNoteConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppNoteIndent2']", Level = 2, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlNoteConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppNoteIndent3']", Level = 3, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlNoteConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppTableText']|self::w:sdt//w:p/w:pPr/w:pStyle[@w:val='ppTableText']", Level = 0, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlBodyTextConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:tbl/w:tblPr/w:tblStyle[@w:val='TableGrid']", Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlTableConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:tbl[count(w:tblPr/w:tblStyle)=0]", Level = 10, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlTableConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:tbl/w:tblPr/w:tblStyle[@w:val='ppTable']", Level = 10, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlTableConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:tbl/w:tblPr/w:tblStyle[@w:val='ppTableGrid']", Level = 10, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlTableWithHeaderConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppBulletList']|self::w:sdt//w:p/w:pPr/w:pStyle[@w:val='ppBulletList']", Level = 1, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlBulletListConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppBulletListIndent']|self::w:sdt//w:p/w:pPr/w:pStyle[@w:val='ppBulletListIndent']", Level = 2, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlBulletListConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppBulletListIndent2']|self::w:sdt//w:p/w:pPr/w:pStyle[@w:val='ppBulletListIndent2']", Level = 3, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlBulletListConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppBulletListIndent3']|self::w:sdt//w:p/w:pPr/w:pStyle[@w:val='ppBulletListIndent3']", Level = 4, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlBulletListConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppCode']", Level = 0, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlCodeBlockConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppCodeIndent']", Level = 1, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlCodeBlockConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppCodeIndent1']", Level = 2, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlCodeBlockConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppCodeIndent2']", Level = 3, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlCodeBlockConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppCodeIndent3']", Level = 4, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlCodeBlockConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppCodeLanguage']", Level = 0, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlCodeLanguageConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppCodeLanguageIndent']", Level = 1, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlCodeLanguageConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppCodeLanguageIndent1']", Level = 2, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlCodeLanguageConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppCodeLanguageIndent2']", Level = 3, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlCodeLanguageConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppCodeLanguageIndent3']", Level = 4, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlCodeLanguageConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='TOC1']", Level = 0, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlToc1Converter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='TOC2']", Level = 0, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlToc2Converter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='TOC3']", Level = 0, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlToc3Converter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppSection']", Level = 0, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlSectionConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='ppProcedureStart']", Level = 0, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlProcedureStartConverter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='Heading1']", Level = 0, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlHeading1Converter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='Heading2']", Level = 0, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlHeading2Converter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='Heading3']", Level = 0, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlHeading3Converter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='Heading4']", Level = 0, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlHeading4Converter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='Subtitle']", Level = 0, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlHeading1Converter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='Title']", Level = 0, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlHeading4Converter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='HOLTitle1']", Level = 0, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlHeading4Converter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='HOLDescription']", Level = 0, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlHeading1Converter, Microsoft.Practices.DocxConverter" });
            converters.Add(new ConverterElement() { Path = "self::w:p/w:pPr/w:pStyle[@w:val='Bodynoindent']", Level = 0, Type = "Microsoft.Practices.DocxConverter.ElementConverters.XmlBodyTextConverter, Microsoft.Practices.DocxConverter" });
      
            return converters;
        }
    }
}
