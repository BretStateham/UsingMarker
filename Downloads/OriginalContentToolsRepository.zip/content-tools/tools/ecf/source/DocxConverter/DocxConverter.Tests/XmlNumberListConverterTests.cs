// ===============================================================================
// Microsoft patterns & practices
// Documentation Tools - January 2008 
//-------------------------------------------------------------------------------
// Copyright �  Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//-------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ===============================================================================

namespace DocxConverter.Tests
{
    using System.Xml;
    using System.Xml.XPath;
    using Microsoft.Practices.DocxConverter;
    using Microsoft.Practices.DocxConverter.Converters;
    using Microsoft.Practices.DocxConverter.ElementConverters;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class XmlNumberListConverterTests : OpenXmlElementConvertersTests
    {
        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\NumberList.xml")]
        public void ShouldConvertNumberList()
        {
            XmlDocument document = new XmlDocument();
            document.Load("NumberList.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlNumberListConverter converter = new XmlNumberListConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 1;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<ol><step><title>Number list item 1.</title><contents /></step><step><title>Number list item 2.</title><contents /></step></ol>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\NumberListWithEmptyBodyTextBetween.xml")]
        public void ShouldConvertNumberList_EmptyBodyTextBetween()
        {
            XmlDocument document = new XmlDocument();
            document.Load("NumberListWithEmptyBodyTextBetween.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlNumberListConverter converter = new XmlNumberListConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 1;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<ol><step><title>List item 1</title><contents /></step><br /><step><title>List item 2</title><contents /></step></ol>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\NumberListWithIndentedTableBetween.xml")]
        public void ShouldConvertNumberList_IndentedTableBetween()
        {
            XmlDocument document = new XmlDocument();
            document.Load("NumberListWithIndentedTableBetween.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("(descendant-or-self::w:p[w:pPr/w:pStyle[@w:val='ppNumberList']])|(descendant-or-self::w:tbl)", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlNumberListConverter converter = new XmlNumberListConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 1;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<ol><step><title>List Item 1</title><contents><table><tr><th><p>Title 1</p></th><th><p>Title 2</p></th></tr><tr><td><p>Text</p></td><td><p>Text</p></td></tr></table></contents></step><step><title>List Item 2</title><contents /></step></ol>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\NumberListWithNoRunOrNoTextElement.xml")]
        public void ShouldConvertNumberListEmpty_NoRunOrNoTextElement()
        {
            XmlDocument document = new XmlDocument();
            document.Load("NumberListWithNoRunOrNoTextElement.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlNumberListConverter converter = new XmlNumberListConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 1;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<ol><step><br /><contents /></step><step><br /><contents /></step></ol>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\NumberListsWithListEnd.xml")]
        public void ShouldConvertNumberList_ListsSeparatedWithListEnd()
        {
            XmlDocument document = new XmlDocument();
            document.Load("NumberListsWithListEnd.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlNumberListConverter converter = new XmlNumberListConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 1;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<ol><step><title>List item A1.</title><contents /></step><step><title>List item A2.</title><contents /></step></ol>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\NumberListsWithBodyTextIndentBetween.xml")]
        public void ShouldConvertNumberListWithBodyTextIndentBetween()
        {
            XmlDocument document = new XmlDocument();
            document.Load("NumberListsWithBodyTextIndentBetween.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlNumberListConverter converter = new XmlNumberListConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 1;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<ol><step><title>List item A1.</title><contents /></step><step><title>List item A2.</title><contents><p>Some text.</p></contents></step><step><title>List item B1.</title><contents /></step><step><title>List item B2.</title><contents /></step></ol>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\NumberListItem.xml")]
        public void ShouldConvertNumberListItem()
        {
            XmlDocument document = new XmlDocument();
            document.Load("NumberListItem.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();            

            XmlListItemConverter converter = new XmlListItemConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<step><title>Number list item.</title><contents /></step>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\NumberListItemWithBold.xml")]
        public void ShouldConvertNumberListItemWithBold()
        {
            XmlDocument document = new XmlDocument();
            document.Load("NumberListItemWithBold.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();            

            XmlListItemConverter converter = new XmlListItemConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<step><title>Number list item <b>with bold</b>.</title><contents /></step>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\NumberListItemWithItalic.xml")]
        public void ShouldConvertNumberListItemWithItalic()
        {
            XmlDocument document = new XmlDocument();
            document.Load("NumberListItemWithItalic.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();            

            XmlListItemConverter converter = new XmlListItemConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<step><title>Number list item <i>with italic</i>.</title><contents /></step>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\NumberListWithBodyTextIndentAtTheEnd.xml")]
        public void ShouldConvertNumberListWithBodyTextIndentAtTheEnd()
        {
            XmlDocument document = new XmlDocument();
            document.Load("NumberListWithBodyTextIndentAtTheEnd.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;
        
            XmlNumberListConverter converter = new XmlNumberListConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 1;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<ol><step><title>Number List 1</title><contents /></step><step><title>Number List 2</title><contents><p>This is text</p></contents></step></ol>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\NumberList.xml")]
        public void ShouldConvertNumberListWithConversionErr_WrongNode()
        {
            XmlDocument document = new XmlDocument();
            document.Load("NumberList.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:r", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlNumberListConverter converter = new XmlNumberListConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 1;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<ol><step><title>Could not convert node</title><contents /></step></ol>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\NumberListWithNoListEndAndBodyTextNext.xml")]
        public void ShouldConvertNumberList_BodyStyleAtTheEnd()
        {
            XmlDocument document = new XmlDocument();
            document.Load("NumberListWithNoListEndAndBodyTextNext.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlNumberListConverter converter = new XmlNumberListConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 1;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<ol><step><title>List item A1.</title><contents /></step></ol>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\NumberListNestedLevels.xml")]
        public void ShouldConvertNumberListNestedLevels()
        {
            XmlDocument document = new XmlDocument();
            document.Load("NumberListNestedLevels.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlNumberListConverter converter = new XmlNumberListConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 1;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<ol><step><title>List item 1.</title><contents><ol><step><title>List item a1.</title><contents /></step></ol></contents></step></ol>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\NumberListNestedLevelsWithInnerLevelBetween.xml")]
        public void ShouldConvertNumberListNestedLevelsWithInnerLevelBetween()
        {
            XmlDocument document = new XmlDocument();
            document.Load("NumberListNestedLevelsWithInnerLevelBetween.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlNumberListConverter converter = new XmlNumberListConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 1;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<ol><step><title>List item 1.</title><contents><ol><step><title>List item a1.</title><contents /></step></ol></contents></step><step><title>List item 2.</title><contents /></step></ol>", actual);
        }
    }
}
