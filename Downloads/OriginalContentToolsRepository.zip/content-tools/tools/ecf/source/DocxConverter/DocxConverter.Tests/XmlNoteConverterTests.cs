// ===============================================================================
// Microsoft patterns & practices
// Documentation Tools - January 2008 
//-------------------------------------------------------------------------------
// Copyright �  Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//-------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ===============================================================================

namespace DocxConverter.Tests
{
    using System;
    using System.Xml;
    using System.Xml.XPath;
    using Microsoft.Practices.DocxConverter;
    using Microsoft.Practices.DocxConverter.Converters;
    using Microsoft.Practices.DocxConverter.ElementConverters;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class XmlNoteConverterTests : OpenXmlElementConvertersTests
    {
        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\Note.xml")]
        public void ShouldConvertNote()
        {
            XmlDocument document = new XmlDocument();
            document.Load("Note.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlNoteConverter converter = new XmlNoteConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 0;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<note><title>Note:</title><text>This is a note.</text></note>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\NoteAllEmpty.xml")]
        public void ShouldConvertNoteAllEmpty()
        {
            XmlDocument document = new XmlDocument();
            document.Load("NoteAllEmpty.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlNoteConverter converter = new XmlNoteConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 0;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<note><title>Note:</title><text /></note>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\NoteIndentedWithNoteNotIndentedBelow.xml")]
        public void ShouldConvertSingleNote_OuterNoteBelow()
        {
            XmlDocument document = new XmlDocument();
            document.Load("NoteIndentedWithNoteNotIndentedBelow.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlNoteConverter converter = new XmlNoteConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 1;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<note><title>Note:</title><text>This is an indented note.</text></note>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\NoteWithBlankParagraph.xml")]
        public void ShouldConvertNoteWithBlankLineBetweenParagraphs()
        {
            XmlDocument document = new XmlDocument();
            document.Load("NoteWithBlankParagraph.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlNoteConverter converter = new XmlNoteConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 0;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<note><title>Note:</title><text>This is a paragraph.<br /><br />Another paragraph.</text></note>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\NoteWithBodyTextBelow.xml")]
        public void ShouldConvertSingleNote_BodyTextBelow()
        {
            XmlDocument document = new XmlDocument();
            document.Load("NoteWithBodyTextBelow.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlNoteConverter converter = new XmlNoteConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 0;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<note><title>Note:</title><text>This is a note.</text></note>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\NoteWithBoldText.xml")]
        public void ShouldConvertNoteWithBoldText()
        {
            XmlDocument document = new XmlDocument();
            document.Load("NoteWithBoldText.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlNoteConverter converter = new XmlNoteConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 0;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<note><title>Note:</title><text>This is a note with <b>bold</b>.</text></note>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\NoteWithItalicText.xml")]
        public void ShouldConvertNoteWithItalicText()
        {
            XmlDocument document = new XmlDocument();
            document.Load("NoteWithItalicText.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlNoteConverter converter = new XmlNoteConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 0;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<note><title>Note:</title><text>This is a note with <i>italic</i>.</text></note>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\NoteWithNoNoteTitle.xml")]
        public void ShouldConvertNoteWithNoteTitle_InputWithNoNoteTitle()
        {
            XmlDocument document = new XmlDocument();
            document.Load("NoteWithNoNoteTitle.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlNoteConverter converter = new XmlNoteConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 0;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<note><title>Note:</title><text>This note has no title.</text></note>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\NoteWithNoteTitleNotBold.xml")]
        public void ShouldConvertNoteWithNoteTitle_InputWithNoteTitleNotBold()
        {
            XmlDocument document = new XmlDocument();
            document.Load("NoteWithNoteTitleNotBold.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlNoteConverter converter = new XmlNoteConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 0;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<note><title>Note:</title><text>Error: Note format was corrupted. Title should be bold..</text></note>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\NoteWithNoteTitleObservation.xml")]
        public void ShouldConvertNoteWithNoteTitle_InputWithNoteTitleObservation()
        {
            XmlDocument document = new XmlDocument();
            document.Load("NoteWithNoteTitleObservation.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlNoteConverter converter = new XmlNoteConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 0;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<note><title>Note:</title><text><b>Observation: </b>This is an observation.</text></note>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\NoteWithAnotherNoteBelow.xml")]
        public void ShouldConvertMergedSingleNote_NoteWithAnotherNoteBelow()
        {
            XmlDocument document = new XmlDocument();
            document.Load("NoteWithAnotherNoteBelow.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlNoteConverter converter = new XmlNoteConverter();
            converter.XmlConverterService = new XmlConverterService(); 
            converter.IndentationLevel = 0;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<note><title>Note:</title><text>Paragraph 1.<br />Paragraph 2.</text></note>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\NoteWithTwoParagraphs.xml")]
        public void ShouldConvertNoteWithTwoParagraphs()
        {
            XmlDocument document = new XmlDocument();
            document.Load("NoteWithTwoParagraphs.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlNoteConverter converter = new XmlNoteConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 0;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<note><title>Note:</title><text>This is a paragraph.<br />Another paragraph.</text></note>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\Note.xml")]
        [ExpectedException(typeof(NotSupportedException), "Note Converter error: A note paragraph was expected.")]
        public void ShouldGenerateExeptionNoteExpected()
        {
            try
            {
                XmlDocument document = new XmlDocument();
                document.Load("Note.xml");
                XPathNavigator navigator = document.CreateNavigator();
                XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:body", OpenXmlHelper.GetNamespaceManager(document));
                iterator.MoveNext();

                string configPath = "DocxConverter.Tests.dll.config";
                ConverterFactory.ConfigurationPath = configPath;

                XmlNoteConverter converter = new XmlNoteConverter();
                converter.XmlConverterService = new XmlConverterService();
                converter.IndentationLevel = 0;
                converter.Convert(iterator, Writer);
            }
            catch (DocumentConverterException e)
            {
                throw e.InnerException;
            }
        }
    }
}
