// ===============================================================================
// Microsoft patterns & practices
// Documentation Tools - January 2008 
//-------------------------------------------------------------------------------
// Copyright �  Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//-------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ===============================================================================

namespace DocxConverter.Tests
{
    using System.Xml;
    using System.Xml.XPath;
    using Microsoft.Practices.DocxConverter;
    using Microsoft.Practices.DocxConverter.ElementConverters;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class XmlBodyTextConverterTests : OpenXmlElementConvertersTests
    {
        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\BodyText.xml")]
        public void ShouldConvertBodyText()
        {
            XmlDocument document = new XmlDocument();
            document.Load("BodyText.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlBodyTextConverter converter = new XmlBodyTextConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<p>This is a pp Body Text paragraph</p>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\BodyText.xml")]
        public void ShouldConvertBodyTextWithConversionErr_WrongNode()
        {
            XmlDocument document = new XmlDocument();
            document.Load("BodyText.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:r", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlBodyTextConverter converter = new XmlBodyTextConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<p>Could not convert node</p>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\BodyTextWithMultiTextElements.xml")]
        public void ShouldConvertBodyText_MultiTextElements()
        {
            XmlDocument document = new XmlDocument();
            document.Load("BodyTextWithMultiTextElements.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlBodyTextConverter converter = new XmlBodyTextConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<p>Text Region 1 /Text Region 2 /Text Region 3</p>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\BodyTextWithSpacePreserve.xml")]
        public void ShouldConvertBodyTextWithSpacePreserve()
        {
            XmlDocument document = new XmlDocument();
            document.Load("BodyTextWithSpacePreserve.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlBodyTextConverter converter = new XmlBodyTextConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<p>Word1 Word2</p>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\BodyTextWithNoSpacePreserve.xml")]
        public void ShouldConvertBodyTextWithNoSpacePreserve()
        {
            XmlDocument document = new XmlDocument();
            document.Load("BodyTextWithNoSpacePreserve.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlBodyTextConverter converter = new XmlBodyTextConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<p>Word1Word2</p>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\BodyTextWithBold.xml")]
        public void ShouldConvertBodyTextWithBold()
        {
            XmlDocument document = new XmlDocument();
            document.Load("BodyTextWithBold.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlBodyTextConverter converter = new XmlBodyTextConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<p>This is a pp Body Text paragraph <b>with bold</b></p>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\BodyTextWithItalic.xml")]
        public void ShouldConvertBodyTextWithItalic()
        {
            XmlDocument document = new XmlDocument();
            document.Load("BodyTextWithItalic.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlBodyTextConverter converter = new XmlBodyTextConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<p>This is a pp Body Text paragraph <i>with italic</i></p>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\BodyTextWithItalicAndBold.xml")]
        public void ShouldConvertBodyTextWithItalicAndBold()
        {
            XmlDocument document = new XmlDocument();
            document.Load("BodyTextWithItalicAndBold.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlBodyTextConverter converter = new XmlBodyTextConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<p>This is a pp Body Text paragraph with <i>italic</i> and <b>bold</b>.</p>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\BodyTextWithItalicBold.xml")]
        public void ShouldConvertBodyTextWithItalicBold()
        {
            XmlDocument document = new XmlDocument();
            document.Load("BodyTextWithItalicBold.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlBodyTextConverter converter = new XmlBodyTextConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<p>This is a pp paragraph with <b><i>italic bold</i></b>.</p>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\BodyTextWithNoRunElement.xml")]
        public void ShouldConvertBodyTextWithLineBreak_NoRunElement()
        {
            XmlDocument document = new XmlDocument();
            document.Load("BodyTextWithNoRunElement.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlBodyTextConverter converter = new XmlBodyTextConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<br />", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\BodyTextWithNoTextElement.xml")]
        public void ShouldConvertBodyTextEmpty_NoTextElement()
        {
            XmlDocument document = new XmlDocument();
            document.Load("BodyTextWithNoTextElement.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlBodyTextConverter converter = new XmlBodyTextConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<br />", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\BodyTextWithItalicWithStrangeSpace.xml")]
        public void ShouldConvertBodyTextWithItalicWithStrangeSpace()
        {
            XmlDocument document = new XmlDocument();
            document.Load("BodyTextWithItalicWithStrangeSpace.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlBodyTextConverter converter = new XmlBodyTextConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<p><i>This  is</i> a text with <i>italic words</i> in the beginning.</p>", actual);
        }
    }
}
