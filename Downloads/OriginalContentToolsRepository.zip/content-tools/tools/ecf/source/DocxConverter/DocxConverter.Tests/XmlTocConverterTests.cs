// ===============================================================================
// Microsoft patterns & practices
// Documentation Tools - January 2008 
//-------------------------------------------------------------------------------
// Copyright �  Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//-------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ===============================================================================

namespace DocxConverter.Tests
{
    using System.Xml;
    using System.Xml.XPath;
    using Microsoft.Practices.DocxConverter;
    using Microsoft.Practices.DocxConverter.ElementConverters;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class XmlTocConverterTests : OpenXmlElementConvertersTests
    {
        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\Toc1Paragraph.xml")]
        public void ShouldConvertToc1()
        {
            XmlDocument document = new XmlDocument();
            document.Load("Toc1Paragraph.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlToc1Converter converter = new XmlToc1Converter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, this.Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<toc1>This is TOC 1</toc1>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\Toc2Paragraph.xml")]
        public void ShouldConvertToc2()
        {
            XmlDocument document = new XmlDocument();
            document.Load("Toc2Paragraph.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlToc2Converter converter = new XmlToc2Converter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, this.Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<toc2>This is TOC 2</toc2>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\Toc3Paragraph.xml")]
        public void ShouldConvertToc3()
        {
            XmlDocument document = new XmlDocument();
            document.Load("Toc3Paragraph.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlToc3Converter converter = new XmlToc3Converter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, this.Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<toc3>This is TOC 3</toc3>", actual);
        }
    }
}
