// ===============================================================================
// Microsoft patterns & practices
// Documentation Tools - January 2008 
//-------------------------------------------------------------------------------
// Copyright �  Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//-------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ===============================================================================

namespace DocxConverter.Tests
{
    using System;
    using System.Xml;
    using System.Xml.XPath;
    using Microsoft.Practices.DocxConverter;
    using Microsoft.Practices.DocxConverter.Converters;
    using Microsoft.Practices.DocxConverter.ElementConverters;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class XmlTableConverterTests : OpenXmlElementConvertersTests
    {
        public XmlTableConverterTests()
        {
            // TODO: Add constructor logic here
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\TableWithHeaderOneColumnOneRowEmpty.xml")]
        public void ShouldConvertTableWithHeaderOneColumnOneRowEmpty()
        {
            XmlDocument document = new XmlDocument();
            document.Load("TableWithHeaderOneColumnOneRowEmpty.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:tbl", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlTableWithHeaderConverter converter = new XmlTableWithHeaderConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<table><tr><th><br /></th></tr><tr><td><br /></td></tr></table>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\TableWithHeaderOneColumnTwoRowsEmpty.xml")]
        public void ShouldConvertTableWithHeaderOneColumnTwoRowsEmpty()
        {
            XmlDocument document = new XmlDocument();
            document.Load("TableWithHeaderOneColumnTwoRowsEmpty.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:tbl", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlTableWithHeaderConverter converter = new XmlTableWithHeaderConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<table><tr><th><br /></th></tr><tr><td><br /></td></tr><tr><td><br /></td></tr></table>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\TableWithHeaderTwoColumnsTwoRowsEmpty.xml")]
        public void ShouldConvertTableWithHeaderTwoColumnsTwoRowsEmpty()
        {
            XmlDocument document = new XmlDocument();
            document.Load("TableWithHeaderTwoColumnsTwoRowsEmpty.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:tbl", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlTableWithHeaderConverter converter = new XmlTableWithHeaderConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<table><tr><th><br /></th><th><br /></th></tr><tr><td><br /></td><td><br /></td></tr><tr><td><br /></td><td><br /></td></tr></table>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\TableWithNoHeaderOneColumnOneRowEmpty.xml")]
        public void ShouldConvertTableWithNoHeaderOneColumnOneRowEmpty()
        {
            XmlDocument document = new XmlDocument();
            document.Load("TableWithNoHeaderOneColumnOneRowEmpty.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:tbl", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlTableConverter converter = new XmlTableConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<table><tr><td><br /></td></tr></table>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\TableWithTitleInMultitpleLines.xml")]
        public void ShouldConvertTableWithTitleInMultipleLines()
        {
            XmlDocument document = new XmlDocument();
            document.Load("TableWithTitleInMultitpleLines.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:tbl", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlTableWithHeaderConverter converter = new XmlTableWithHeaderConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<table><tr><th><p>Title</p><p>Subtitle</p></th></tr><tr><td><br /></td></tr></table>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\TableWithTitleAndCellWithBodyText.xml")]
        public void ShouldConvertTableWithTitleAndCellWithBodyText()
        {
            XmlDocument document = new XmlDocument();
            document.Load("TableWithTitleAndCellWithBodyText.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:tbl", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlTableWithHeaderConverter converter = new XmlTableWithHeaderConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<table><tr><th><p>Title</p></th></tr><tr><td><p>This is Body Text.</p></td></tr></table>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\TableWithTitleAndCellWithNumberList.xml")]
        public void ShouldConvertTableWithTitleAndCellWithNumberList()
        {
            XmlDocument document = new XmlDocument();
            document.Load("TableWithTitleAndCellWithNumberList.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:tbl", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlTableWithHeaderConverter converter = new XmlTableWithHeaderConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<table><tr><th><p>Title</p></th></tr><tr><td><ol><step><title>Item 1</title><contents /></step><step><title>Item 2</title><contents /></step></ol></td></tr></table>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\TableWithTitleInWrongStyle.xml")]
        public void ShouldTableConverterShowErrorInTitle()
        {
            XmlDocument document = new XmlDocument();
            document.Load("TableWithTitleInWrongStyle.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:tbl", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlTableWithHeaderConverter converter = new XmlTableWithHeaderConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<table><tr><th>Conversion Error: Invalid style applied inside cell</th></tr><tr><td><br /></td></tr></table>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\TableWithNestedTable.xml")]
        public void ShouldConvertTableWithNestedTable()
        {
            XmlDocument document = new XmlDocument();
            document.Load("TableWithNestedTable.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:tbl", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlTableWithHeaderConverter converter = new XmlTableWithHeaderConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<table><tr><th><p>Title C1</p></th><th><p>Title C2</p></th></tr><tr><td><table><tr><th><p>Title D1</p></th><th><p>Title D2</p></th></tr><tr><td><br /></td><td><br /></td></tr></table><br /></td><td><br /></td></tr></table>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\TableWithMergedCells.xml")]
        [DeploymentItem(@"XmlExpectedOutput\TablesWithMergedCellsOutput.xml")]
        public void ShouldConvertTableWithMergedCells()
        {
            XmlDocument document = new XmlDocument();
            document.Load("TableWithMergedCells.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:tbl", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlTableWithHeaderConverter converter = new XmlTableWithHeaderConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            XmlDocument expectedXmlOutput = new XmlDocument();
            expectedXmlOutput.Load("TablesWithMergedCellsOutput.xml");

            Assert.AreEqual(expectedXmlOutput.OuterXml, actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\TableWithNoHeaderOneColumnOneRowEmpty.xml")]
        [ExpectedException(typeof(NotSupportedException), "Table Converter error: A table was expected")]
        public void ShouldGenerateExeptionTableExpected()
        {
            try
            {
                XmlDocument document = new XmlDocument();
                document.Load("TableWithNoHeaderOneColumnOneRowEmpty.xml");
                XPathNavigator navigator = document.CreateNavigator();
                XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:body", OpenXmlHelper.GetNamespaceManager(document));
                iterator.MoveNext();

                string configPath = "DocxConverter.Tests.dll.config";
                ConverterFactory.ConfigurationPath = configPath;

                XmlTableConverter converter = new XmlTableConverter();
                converter.Convert(iterator, Writer);
            }
            catch (DocumentConverterException e)
            {
                throw e.InnerException;
            }
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\TableWithMergeRows.xml")]
        [DeploymentItem(@"XmlExpectedOutput\TableWithMergeRowsOutput.xml")]
        public void ShouldConvertTableWithMergedRows()
        {
            XmlDocument document = new XmlDocument();
            document.Load("TableWithMergeRows.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:tbl", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlTableWithHeaderConverter converter = new XmlTableWithHeaderConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            XmlDocument expectedXmlOutput = new XmlDocument();
            expectedXmlOutput.Load("TableWithMergeRowsOutput.xml");

            Assert.AreEqual(expectedXmlOutput.OuterXml, actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\TableWithDiferentMergeRowSizes.xml")]
        [DeploymentItem(@"XmlExpectedOutput\TableWithDifferentMergeRowSizesOutput.xml")]
        public void ShouldConvertTableWithMergedRows_DifferentMergeSizes()
        {
            XmlDocument document = new XmlDocument();
            document.Load("TableWithDiferentMergeRowSizes.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:tbl", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlTableWithHeaderConverter converter = new XmlTableWithHeaderConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            XmlDocument expectedXmlOutput = new XmlDocument();
            expectedXmlOutput.Load("TableWithDifferentMergeRowSizesOutput.xml");

            Assert.AreEqual(expectedXmlOutput.OuterXml, actual);
        }
    }
}
