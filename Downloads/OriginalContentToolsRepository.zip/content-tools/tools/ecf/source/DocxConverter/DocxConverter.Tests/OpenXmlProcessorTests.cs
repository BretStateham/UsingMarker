// ===============================================================================
// Microsoft patterns & practices
// Documentation Tools - January 2008 
//-------------------------------------------------------------------------------
// Copyright �  Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//-------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ===============================================================================

namespace DocxConverter.Tests
{
    using System.IO;
    using System.Xml;
    using Microsoft.Practices.DocxConverter;
    using Microsoft.Practices.DocxConverter.Converters;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public class OpenXmlProcessorTests
    {
        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\Topic.xml")]
        [DeploymentItem(@"XmlExpectedOutput\TopicOutput.xml")]
        public void ShouldConvertTopicDocument()
        {
            XmlDocument openXmlInput = new XmlDocument();
            openXmlInput.Load("Topic.xml");

            XmlNode node = openXmlInput.SelectSingleNode("descendant-or-self::w:sdt[w:sdtPr/w:alias[@w:val='Topic']]", OpenXmlHelper.GetNamespaceManager(openXmlInput));

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            var xmlConverterService = new XmlConverterService();
            XmlDocument xmlOutput = OpenXmlProcessor.Convert(node, null, xmlConverterService);
            
            XmlDocument expectedXmlOutput = new XmlDocument();
            expectedXmlOutput.Load("TopicOutput.xml");

            Assert.AreEqual<string>(expectedXmlOutput.OuterXml, xmlOutput.OuterXml);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\DocWithNoTopicAtStart.xml")]
        [DeploymentItem(@"XmlExpectedOutput\DefaultOutput.xml")]
        public void ShouldConvertDefaultDocument()
        {
            XmlDocument openXmlInput = new XmlDocument();
            openXmlInput.Load("DocWithNoTopicAtStart.xml");

            XmlNode nodeStart = openXmlInput.SelectSingleNode(@"//w:body/*[1]", OpenXmlHelper.GetNamespaceManager(openXmlInput));
            XmlNode nodeEnd = openXmlInput.SelectSingleNode("descendant-or-self::w:sdt[w:sdtPr/w:alias[@w:val='Topic']]", OpenXmlHelper.GetNamespaceManager(openXmlInput));

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            var xmlConverterService = new XmlConverterService();
            XmlDocument xmlOutput = OpenXmlProcessor.Convert(nodeStart, nodeEnd, xmlConverterService);

            XmlDocument expectedXmlOutput = new XmlDocument();
            expectedXmlOutput.Load("DefaultOutput.xml");

            Assert.AreEqual<string>(expectedXmlOutput.OuterXml, xmlOutput.OuterXml);
        }

        [TestMethod]
        [DeploymentItem(@"DocxInput\DocWithKeywords.docx")]
        [DeploymentItem(@"OpenXmlInput\DocWithKeywords.xml")]
        [DeploymentItem(@"XmlExpectedOutput\TopicWithKeywordsOutput.xml")]
        [DeploymentItem(@"XmlExpectedOutput\TopicWithNoKeywordsOutput.xml")]
        public void ShouldConvertKeyworsInsideFirstTopicOnly()
        {
            string documentName = Directory.GetCurrentDirectory() + "\\DocWithKeywords.docx";
            string imagesPath = "images_ShouldConvertKeyworsInsideFirstTopicOnly";
            string imagesAbsolutePath = Directory.GetCurrentDirectory() + "\\" + imagesPath;
            string imagesFormat = ".png";
            Directory.CreateDirectory(imagesAbsolutePath);

            IReferenceResolver resolver = new OpenXmlReferenceResolver(documentName, imagesPath, imagesAbsolutePath, imagesFormat);
            var xmlConverterService = new XmlConverterService(resolver);

            XmlDocument openXmlInput = new XmlDocument();
            openXmlInput.Load("DocWithKeywords.xml");

            XmlNode nodeTopic1 = openXmlInput.SelectSingleNode("descendant-or-self::w:sdt[w:sdtPr/w:alias[@w:val='Topic']]", OpenXmlHelper.GetNamespaceManager(openXmlInput));
            XmlNode nodeTopic2 = nodeTopic1.SelectSingleNode("following-sibling::w:sdt[w:sdtPr/w:alias[@w:val='Topic']]", OpenXmlHelper.GetNamespaceManager(openXmlInput));

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;
            xmlConverterService.KeywordPropsAlreadyAdded = false;

            XmlDocument xmlOutput, expectedXmlOutput;

            xmlOutput = OpenXmlProcessor.Convert(nodeTopic1, nodeTopic2, xmlConverterService);
            expectedXmlOutput = new XmlDocument();
            expectedXmlOutput.Load("TopicWithKeywordsOutput.xml");

            Assert.AreEqual<string>(expectedXmlOutput.OuterXml, xmlOutput.OuterXml);

            xmlOutput = OpenXmlProcessor.Convert(nodeTopic2, null, xmlConverterService);
            expectedXmlOutput = new XmlDocument();
            expectedXmlOutput.Load("TopicWithNoKeywordsOutput.xml");

            Assert.AreEqual<string>(expectedXmlOutput.OuterXml, xmlOutput.OuterXml);
        }
    }
}
