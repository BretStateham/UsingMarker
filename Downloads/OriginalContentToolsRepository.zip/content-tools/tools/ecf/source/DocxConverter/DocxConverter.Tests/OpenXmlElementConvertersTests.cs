// ===============================================================================
// Microsoft patterns & practices
// Documentation Tools - January 2008 
//-------------------------------------------------------------------------------
// Copyright �  Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//-------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ===============================================================================

namespace DocxConverter.Tests
{
    using System.IO;
    using System.Xml;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public class OpenXmlElementConvertersTests
    {
        private Stream stream;
        
        public OpenXmlElementConvertersTests()
        {
            // TODO: Add constructor logic here            
        }

        protected XmlWriter Writer
        {
            get;
            set;
        }

        [TestInitialize()]
        public void MyTestInitialize()
        {
            this.stream = new MemoryStream();

            XmlWriterSettings settings = new XmlWriterSettings();
            settings.ConformanceLevel = ConformanceLevel.Fragment;
            settings.OmitXmlDeclaration = true;
            this.Writer = XmlWriter.Create(this.stream, settings);
        }
        
        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void MyTestCleanup()
        {
            this.Writer.Close();
            this.stream.Close();
        }

        protected string GetConvertedStream()
        {
            this.Writer.Close();
            this.stream.Position = 0;
            StreamReader rdr = new StreamReader(this.stream);
            return rdr.ReadToEnd();
        }

        /*
        [TestMethod]
        public void ShouldConvertBulletListItem()
        {
            XmlDocument openXmlInput = new XmlDocument();
            openXmlInput.Load("BulletListItem.xml");

            XmlNode node = openXmlInput.SelectSingleNode("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(openXmlInput));

            XmlBulletListItemConverter converter = new XmlBulletListItemConverter(this.writer);
            converter.Convert(node);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<step><title>Bullet item</title><contents /></step>", actual);
        }

        [TestMethod]
        public void ShouldConvertBulletListItemWithBold()
        {
            XmlDocument openXmlInput = new XmlDocument();
            openXmlInput.Load("BulletListIemWithBold.xml");

            XmlNode node = openXmlInput.SelectSingleNode("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(openXmlInput));

            XmlBulletListItemConverter converter = new XmlBulletListItemConverter(this.writer);
            converter.Convert(node);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<step><title>Bullet item <b>with bold</b></title><contents /></step>", actual);
        }

        [TestMethod]
        public void ShouldConvertBulletListItemWithItalic()
        {
            XmlDocument openXmlInput = new XmlDocument();
            openXmlInput.Load("BulletListItemWithItalic.xml");

            XmlNode node = openXmlInput.SelectSingleNode("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(openXmlInput));

            XmlBulletListItemConverter converter = new XmlBulletListItemConverter(this.writer);
            converter.Convert(node);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<step><title>Bullet item <i>with </i><i>italic</i></title><contents /></step>", actual);
        }

        [TestMethod]
        public void ShouldConvertCodeLine()
        {
            XmlDocument openXmlInput = new XmlDocument();
            openXmlInput.Load("Code.xml");

            XmlNode node = openXmlInput.SelectSingleNode("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(openXmlInput));

            XmlCodeLineConverter converter = new XmlCodeLineConverter(this.writer);
            converter.Convert(node);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<line>var myVar = 15;</line>", actual);
        }

        [TestMethod]
        public void ShouldConvertCodeBlock()
        {
            XmlDocument openXmlInput = new XmlDocument();
            openXmlInput.Load("CodeBlock.xml");

            XmlNode node = openXmlInput.SelectSingleNode("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(openXmlInput));

            XmlCodeLanguageConverter converter = new XmlCodeLanguageConverter(this.writer);
            converter.Convert(node);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<code language='C#'><line>var myVar = 15;</line></code><br />", actual);
        }

        [TestMethod]
        public void ShouldConvertCodeLanguage()
        {
            XmlDocument openXmlInput = new XmlDocument();
            openXmlInput.Load("CodeLanguage.xml");

            XmlNode node = openXmlInput.SelectSingleNode("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(openXmlInput));

            XmlCodeLanguageConverter converter = new XmlCodeLanguageConverter(this.writer);
            converter.Convert(node);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<code language='JavaScript' />", actual);
        }
       
        [TestMethod]
        public void ShouldConvertFigureCaption()
        {
            XmlDocument openXmlInput = new XmlDocument();
            openXmlInput.Load("FigureCaption.xml");

            XmlNode node = openXmlInput.SelectSingleNode("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(openXmlInput));

            XmlFigureCaptionConverter converter = new XmlFigureCaptionConverter(this.writer);
            converter.Convert(node);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<figurecaption>This is a figure caption</figurecaption><br />", actual);
        }

        [TestMethod]
        public void ShouldConvertFigureNumber()
        {
            XmlDocument openXmlInput = new XmlDocument();
            openXmlInput.Load("FigureNumber.xml");

            XmlNode node = openXmlInput.SelectSingleNode("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(openXmlInput));

            XmlFigureNumberConverter converter = new XmlFigureNumberConverter(this.writer);
            converter.Convert(node);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<figurenumber>Figure 1</figurenumber>", actual);
        }
        */
    }
}
