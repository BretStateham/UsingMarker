﻿namespace DocxConverter.Tests
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Xml;
    using Microsoft.Practices.DocxConverter;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class DocumentSplitterTests
    {   
        [TestMethod]
        [DeploymentItem(@"TestFolder\WordDoc")]
        public void ShouldSplitAndConvertDocument()
        {
            string outputPath = Path.GetFullPath("HtmlOutput");
            string documentFile = Path.GetFullPath("WordDoc\\Overview.docx");

            Directory.CreateDirectory(outputPath);

            DocumentSplitter splitter = new DocumentSplitter()
            {
                OutputPath = outputPath
            };

            IDictionary<string, XmlDocument> outputDocuments = splitter.Split(documentFile);

            Assert.IsNotNull(outputDocuments);
            Assert.AreEqual(2, outputDocuments.Count);

            Directory.Delete(outputPath, true);
        }

        [TestMethod, ExpectedException(typeof(ArgumentNullException))]
        public void ShouldTransformerThrowExceptionWithInvalidXmlDocuments()
        {
            string outputPath = Path.GetFullPath("HtmlOutput");

            DocumentSplitter splitter = new DocumentSplitter()
            {
                OutputPath = outputPath
            };

            IDictionary<string, XmlDocument> outputDocuments = splitter.Split(null);
        }

        [TestMethod]
        [DeploymentItem(@"TestFolder\WordDoc")]
        public void ShouldCreateImagesDirectory()
        {
            string outputPath = Path.GetFullPath("HtmlOutput");
            string documentFile = Path.GetFullPath("WordDoc\\Overview.docx");
            string imageDirectory = "images";

            Directory.CreateDirectory(outputPath);

            DocumentSplitter splitter = new DocumentSplitter()
            {
                OutputPath = outputPath
            };

            IDictionary<string, XmlDocument> outputDocuments = splitter.Split(documentFile);

            Assert.IsTrue(Directory.Exists(Path.Combine(outputPath, imageDirectory)));

            Directory.Delete(outputPath, true);
        }
    }
}
