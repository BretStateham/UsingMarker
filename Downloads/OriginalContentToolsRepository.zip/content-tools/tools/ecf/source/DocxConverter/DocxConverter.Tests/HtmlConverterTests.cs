﻿namespace DocxConverter.Tests
{
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.IO;
    using System.Xml;
    using System.Xml.XPath;
    using Microsoft.Practices.DocxConverter;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class HtmlConverterTests
    {
        [TestMethod]
        [DeploymentItem(@"TestFolder")]
        public void ShouldGenerateHtmlDocument()
        {
            string documentFile = Path.GetFullPath("WordDoc\\Overview.docx");
            string outputDir = Path.GetFullPath("WordDoc");
            string xslPath = Path.GetFullPath("Transformation\\xsl");

            MockDocumentSplitter splitter = new MockDocumentSplitter();
            MockDocumentTransformer transformer = new MockDocumentTransformer();
            HtmlConverter htmlConverter = new HtmlConverter(splitter, transformer);

            Collection<string> topics = htmlConverter.Convert(documentFile, xslPath, outputDir, string.Empty, string.Empty, new string[] { ".svn" });

            Assert.AreEqual(1, topics.Count);
            Assert.IsTrue(File.Exists(topics[0]));
        }

        [TestMethod]
        [DeploymentItem(@"TestFolder")]
        public void ShouldGenerateSingleHtmlDocument()
        {
            string documentFile = Path.GetFullPath("WordDoc\\Lab.docx");
            string outputDir = Path.GetFullPath("WordDoc");
            string xslPath = Path.GetFullPath("Transformation\\xsl");

            DocumentSplitter splitter = new DocumentSplitter();
            DocumentTransformer transformer = new DocumentTransformer();
            SingleHtmlConverter htmlConverter = new SingleHtmlConverter(splitter, transformer);

            string name = htmlConverter.Convert(documentFile, xslPath, outputDir, string.Empty, string.Empty, new string[] { ".svn" });

            Assert.AreEqual("DocSet_Default.html", name);
            Assert.IsTrue(File.Exists(Path.Combine(Path.GetFullPath("WordDoc\\html"), name)));
        }

        private class MockDocumentSplitter : DocumentSplitter
        {
            public override IDictionary<string, XmlDocument> Split(string documentName)
            {
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(Path.GetFullPath("XmlFiles\\default.xml"));

                IDictionary<string, XmlDocument> converted = new Dictionary<string, XmlDocument>();
                converted.Add("default", xmlDoc);

                return converted;
            }
        }

        private class MockDocumentTransformer : DocumentTransformer
        {
            public override IXPathNavigable Transform(IXPathNavigable document, string outputFile)
            {
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(Path.GetFullPath("HtmlFiles\\TransformedFile.html"));

                return xmlDoc;
            }
        }
    }
}
