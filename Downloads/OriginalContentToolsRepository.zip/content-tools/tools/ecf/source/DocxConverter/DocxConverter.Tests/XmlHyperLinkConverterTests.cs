// ===============================================================================
// Microsoft patterns & practices
// Documentation Tools - January 2008 
//-------------------------------------------------------------------------------
// Copyright �  Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//-------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ===============================================================================

namespace DocxConverter.Tests
{
    using System.IO;
    using System.Xml;
    using System.Xml.XPath;
    using Microsoft.Practices.DocxConverter;
    using Microsoft.Practices.DocxConverter.ElementConverters;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class XmlHyperLinkConverterTests : OpenXmlElementConvertersTests
    {
        [TestMethod]
        [DeploymentItem(@"DocxInput\StandardHyperlink.docx")]
        [DeploymentItem(@"OpenXmlInput\StandardHyperlink.xml")]
        public void ShouldConvertStandardHyperlink()
        {
            string documentName = Directory.GetCurrentDirectory() + "\\StandardHyperlink.docx";
            string imagesPath = "images";
            string imagesAbsolutePath = Directory.GetCurrentDirectory() + "\\" + imagesPath;
            string imagesFormat = ".png";
            Directory.CreateDirectory(imagesAbsolutePath);

            IReferenceResolver resolver = new OpenXmlReferenceResolver(documentName, imagesPath, imagesAbsolutePath, imagesFormat);

            XmlDocument document = new XmlDocument();
            document.Load("StandardHyperlink.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlBodyTextConverter converter = new XmlBodyTextConverter();
            converter.XmlConverterService = new XmlConverterService(resolver);
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<p>Look at <hlink xlink:type=\"simple\" xlink:show=\"new\" xlink:actuate=\"onRequest\" xlink:href=\"http://www.msn.com/?wl=true\" xmlns:xlink=\"http://www.w3.org/1999/xlink\">Here</hlink>.</p>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"DocxInput\BookmarkLink.docx")]
        [DeploymentItem(@"OpenXmlInput\BookmarkLink.xml")]
        public void ShouldConvertBookmarkLink()
        {
            string documentName = Directory.GetCurrentDirectory() + "\\BookmarkLink.docx";
            string imagesPath = "images";
            string imagesAbsolutePath = Directory.GetCurrentDirectory() + "\\" + imagesPath;
            string imagesFormat = ".png";
            Directory.CreateDirectory(imagesAbsolutePath);

            IReferenceResolver resolver = new OpenXmlReferenceResolver(documentName, imagesPath, imagesAbsolutePath, imagesFormat);

            XmlDocument document = new XmlDocument();
            document.Load("BookmarkLink.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlBodyTextConverter converter = new XmlBodyTextConverter();
            converter.XmlConverterService = new XmlConverterService(resolver);
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<p>Look at the <hlink xlink:type=\"simple\" xlink:show=\"new\" xlink:actuate=\"onRequest\" xlink:href=\"default.html#Title\" xmlns:xlink=\"http://www.w3.org/1999/xlink\">title</hlink>.</p>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\BookmarkedParagraph.xml")]
        public void ShouldConvertBookmarkedParagraph()
        {
            XmlDocument document = new XmlDocument();
            document.Load("BookmarkedParagraph.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlBodyTextConverter converter = new XmlBodyTextConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<a name=\"Title\" href=\"#\"><span /></a><p><b>Title</b></p>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\BookmarkedProcedureStart.xml")]
        public void ShouldConvertBookmarkedProcedureStart()
        {
            XmlDocument document = new XmlDocument();
            document.Load("BookmarkedProcedureStart.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlProcedureStartConverter converter = new XmlProcedureStartConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<a name=\"_Toc173660560\" href=\"#\"><span /></a><procedure><title>Task 1</title></procedure>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\TopicLink.xml")]
        public void ShouldConvertContentControlAsTopicLink_StandingAtPLevel()
        {
            XmlDocument document = new XmlDocument();
            document.Load("TopicLink.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlBodyTextConverter converter = new XmlBodyTextConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<p>Link to <hlink xlink:type=\"simple\" xlink:show=\"new\" xlink:actuate=\"onRequest\" xlink:href=\"5389605e-ba60-405a-b253-ef8969703f4e.html\" xmlns:xlink=\"http://www.w3.org/1999/xlink\">Topic 2</hlink>.</p>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\TopicLinkAtSDTLevel.xml")]
        public void ShouldConvertContentControlAsTopicLink_StandingAtSDTLevel()
        {
            XmlDocument document = new XmlDocument();
            document.Load("TopicLinkAtSDTLevel.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:sdt", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlBodyTextConverter converter = new XmlBodyTextConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<p><hlink xlink:type=\"simple\" xlink:show=\"new\" xlink:actuate=\"onRequest\" xlink:href=\"133fadf4-282d-42ef-9415-e969b5b1cf64.html\" xmlns:xlink=\"http://www.w3.org/1999/xlink\">Topic Link</hlink></p>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\ContentControlWithNoTagData.xml")]
        public void ShouldConvertContentControlAsNormalParagraph()
        {
            XmlDocument document = new XmlDocument();
            document.Load("ContentControlWithNoTagData.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlBodyTextConverter converter = new XmlBodyTextConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<p>This is a Content Control with no tag data.</p>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"DocxInput\TOC1.docx")]
        [DeploymentItem(@"OpenXmlInput\TOC1.xml")]
        public void ShouldConvertTOC1()
        {
            string documentName = Directory.GetCurrentDirectory() + "\\TOC1.docx";
            string imagesPath = "images";
            string imagesAbsolutePath = Directory.GetCurrentDirectory() + "\\" + imagesPath;
            string imagesFormat = ".png";
            Directory.CreateDirectory(imagesAbsolutePath);

            IReferenceResolver resolver = new OpenXmlReferenceResolver(documentName, imagesPath, imagesAbsolutePath, imagesFormat);

            XmlDocument document = new XmlDocument();
            document.Load("TOC1.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlHeading1Converter converter = new XmlHeading1Converter();
            converter.XmlConverterService = new XmlConverterService(resolver);
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<h1><hlink xlink:type=\"simple\" xlink:show=\"new\" xlink:actuate=\"onRequest\" xlink:href=\"637cffd9-ca51-4d46-9d0a-8befa4882071.html#_Toc186448807\" xmlns:xlink=\"http://www.w3.org/1999/xlink\">Overview</hlink></h1>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"DocxInput\TOC2.docx")]
        [DeploymentItem(@"OpenXmlInput\TOC2.xml")]
        public void ShouldConvertTOC2()
        {
            string documentName = Directory.GetCurrentDirectory() + "\\TOC2.docx";
            string imagesPath = "images";
            string imagesAbsolutePath = Directory.GetCurrentDirectory() + "\\" + imagesPath;
            string imagesFormat = ".png";
            Directory.CreateDirectory(imagesAbsolutePath);

            IReferenceResolver resolver = new OpenXmlReferenceResolver(documentName, imagesPath, imagesAbsolutePath, imagesFormat);

            XmlDocument document = new XmlDocument();
            document.Load("TOC2.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlBodyTextConverter converter = new XmlBodyTextConverter();
            converter.XmlConverterService = new XmlConverterService(resolver);
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<p><hlink xlink:type=\"simple\" xlink:show=\"new\" xlink:actuate=\"onRequest\" xlink:href=\"default.html#_Toc186424476\" xmlns:xlink=\"http://www.w3.org/1999/xlink\">Introduction</hlink></p>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"DocxInput\TOC3.docx")]
        [DeploymentItem(@"OpenXmlInput\TOC3.xml")]
        public void ShouldConvertTOC3()
        {
            string documentName = Directory.GetCurrentDirectory() + "\\TOC3.docx";
            string imagesPath = "images";
            string imagesAbsolutePath = Directory.GetCurrentDirectory() + "\\" + imagesPath;
            string imagesFormat = ".png";
            Directory.CreateDirectory(imagesAbsolutePath);

            IReferenceResolver resolver = new OpenXmlReferenceResolver(documentName, imagesPath, imagesAbsolutePath, imagesFormat);

            XmlDocument document = new XmlDocument();
            document.Load("TOC3.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlBodyTextConverter converter = new XmlBodyTextConverter();
            converter.XmlConverterService = new XmlConverterService(resolver);
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<p><hlink xlink:type=\"simple\" xlink:show=\"new\" xlink:actuate=\"onRequest\" xlink:href=\"default.html#_Toc186424594\" xmlns:xlink=\"http://www.w3.org/1999/xlink\">Exercise</hlink></p>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"DocxInput\TOCWithTwoLevels.docx")]
        [DeploymentItem(@"OpenXmlInput\TOCWithTwoLevels.xml")]
        public void ShouldConvertTOC2PointingToExternalBookmark()
        {
            string documentName = Directory.GetCurrentDirectory() + "\\TOCWithTwoLevels.docx";
            string imagesPath = "images";
            string imagesAbsolutePath = Directory.GetCurrentDirectory() + "\\" + imagesPath;
            string imagesFormat = ".png";
            Directory.CreateDirectory(imagesAbsolutePath);

            IReferenceResolver resolver = new OpenXmlReferenceResolver(documentName, imagesPath, imagesAbsolutePath, imagesFormat);
            var xmlConverterService = new XmlConverterService(resolver);

            XmlDocument document = new XmlDocument();
            document.Load("TOCWithTwoLevels.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p[w:pPr/w:pStyle[@w:val='TOC3']]", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlBodyTextConverter converter = new XmlBodyTextConverter();
            converter.XmlConverterService = xmlConverterService;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<p><hlink xlink:type=\"simple\" xlink:show=\"new\" xlink:actuate=\"onRequest\" xlink:href=\"34c34e52-fbaa-4e32-99d4-e52d6c512128.html#_Toc186610237\" xmlns:xlink=\"http://www.w3.org/1999/xlink\">Task 1</hlink></p>", actual);
        }
    }
}
