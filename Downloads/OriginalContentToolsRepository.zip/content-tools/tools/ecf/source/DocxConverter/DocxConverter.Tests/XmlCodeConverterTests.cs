// ===============================================================================
// Microsoft patterns & practices
// Documentation Tools - January 2008 
//-------------------------------------------------------------------------------
// Copyright �  Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//-------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ===============================================================================

namespace DocxConverter.Tests
{
    using System.Xml;
    using System.Xml.XPath;
    using Microsoft.Practices.DocxConverter;
    using Microsoft.Practices.DocxConverter.Converters;
    using Microsoft.Practices.DocxConverter.ElementConverters;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class XmlCodeConverterTests : OpenXmlElementConvertersTests
    {
        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\CodeAllEmpty.xml")]
        public void ShouldConvertCodeAllEmpty()
        {
            XmlDocument document = new XmlDocument();
            document.Load("CodeAllEmpty.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlCodeLanguageConverter converter = new XmlCodeLanguageConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 0;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<code language=\"\"><line /></code>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\CodeIndentedWithCodeNotIndentedBelow.xml")]
        public void ShouldConvertCode_CodeNotIndentedBelow()
        {
            XmlDocument document = new XmlDocument();
            document.Load("CodeIndentedWithCodeNotIndentedBelow.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlCodeLanguageConverter converter = new XmlCodeLanguageConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 1;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<code language=\"C#\"><line>{Insert code here}</line></code>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\CodeIndentSplitted.xml")]
        public void ShouldConvertCode_CodeIndentSplitted()
        {
            XmlDocument document = new XmlDocument();
            document.Load("CodeIndentSplitted.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlCodeLanguageConverter converter = new XmlCodeLanguageConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 1;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<code language=\"C#\"><line><b>    {Insert code here}</b> {Insert code here 2}</line></code>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\CodeIndentSplitted2.xml")]
        public void ShouldConvertCode_CodeIndentSplitted2()
        {
            XmlDocument document = new XmlDocument();
            document.Load("CodeIndentSplitted2.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlCodeLanguageConverter converter = new XmlCodeLanguageConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 1;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<code language=\"C#\"><line><b>    {Insert code here}</b></line></code>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\CodeNormal.xml")]
        public void ShouldConvertCode_CodeNormal()
        {
            XmlDocument document = new XmlDocument();
            document.Load("CodeNormal.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlCodeLanguageConverter converter = new XmlCodeLanguageConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 0;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<code language=\"C#\"><line>function foo()</line><line>{</line><line>   // add code here</line><line>}</line></code>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\CodeWithAnotherCodeBelow.xml")]
        public void ShouldConvertCode_AnotherCodeBellow()
        {
            XmlDocument document = new XmlDocument();
            document.Load("CodeWithAnotherCodeBelow.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlCodeLanguageConverter converter = new XmlCodeLanguageConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 0;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<code language=\"C#\"><line>{Insert code here}</line></code>", actual);
        }
        
        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\CodeWithBoldText.xml")]
        public void ShouldConvertCodeWithBoldText()
        {
            XmlDocument document = new XmlDocument();
            document.Load("CodeWithBoldText.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlCodeLanguageConverter converter = new XmlCodeLanguageConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 0;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<code language=\"C#\"><line>function foo()</line><line>{</line><line>   var i = 0;</line><line>   <b>var j = 1;</b></line><line>}</line></code>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\CodeWithCodeBlockEmpty.xml")]
        public void ShouldConvertCodeWithCodeBlockEmpty()
        {
            XmlDocument document = new XmlDocument();
            document.Load("CodeWithCodeBlockEmpty.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlCodeLanguageConverter converter = new XmlCodeLanguageConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 0;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<code language=\"C#\"><line /></code>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\CodeWithNoCodeBlock.xml")]
        public void ShouldConvertCodeWithCodeBlockEmpty_NoCodeBlock()
        {
            XmlDocument document = new XmlDocument();
            document.Load("CodeWithNoCodeBlock.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlCodeLanguageConverter converter = new XmlCodeLanguageConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 0;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<code language=\"C#\"><line /></code>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\CodeWithTwoCodeLanguages.xml")]
        public void ShouldConvertCodeWithCodeBlockEmpty_TwoCodeLanguages()
        {
            XmlDocument document = new XmlDocument();
            document.Load("CodeWithTwoCodeLanguages.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlCodeLanguageConverter converter = new XmlCodeLanguageConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 0;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<code language=\"C#\" />", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\CodeWithBlankLine.xml")]
        public void ShouldConvertCodeWithBlankLine()
        {
            XmlDocument document = new XmlDocument();
            document.Load("CodeWithBlankLine.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlCodeLanguageConverter converter = new XmlCodeLanguageConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 0;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<code language=\"C#\"><line>function foo()</line><line>{</line><line /><line>}</line></code>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\CodeWithNoCodeLanguage.xml")]
        public void ShouldConvertCodeLanguageEmpty_NoCodeLanguage()
        {
            XmlDocument document = new XmlDocument();
            document.Load("CodeWithNoCodeLanguage.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlCodeBlockConverter converter = new XmlCodeBlockConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 0;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<code language=\"\"><line>function foo()</line><line>{</line><line>   // add code here</line><line>}</line></code>", actual);
        }
    }
}
