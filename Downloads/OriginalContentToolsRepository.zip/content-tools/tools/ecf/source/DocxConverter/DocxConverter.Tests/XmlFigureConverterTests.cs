// ===============================================================================
// Microsoft patterns & practices
// Documentation Tools - January 2008 
//-------------------------------------------------------------------------------
// Copyright �  Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//-------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ===============================================================================

namespace DocxConverter.Tests
{
    using System.IO;
    using System.Xml;
    using System.Xml.XPath;
    using Microsoft.Practices.DocxConverter;
    using Microsoft.Practices.DocxConverter.ElementConverters;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class XmlFigureConverterTests : OpenXmlElementConvertersTests
    {
        [TestMethod]
        [DeploymentItem(@"DocxInput\Figure.docx")]
        [DeploymentItem(@"OpenXmlInput\Figure.xml")]
        public void ShouldConvertFigure()
        {
            string documentName = Directory.GetCurrentDirectory() + "\\Figure.docx";
            string imagesPath = "images";
            string imagesAbsolutePath = Directory.GetCurrentDirectory() + "\\" + imagesPath;
            string imagesFormat = ".png";
            Directory.CreateDirectory(imagesAbsolutePath);

            IReferenceResolver resolver = new OpenXmlReferenceResolver(documentName, imagesPath, imagesAbsolutePath, imagesFormat);

            XmlDocument document = new XmlDocument();
            document.Load("Figure.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlBodyTextConverter converter = new XmlBodyTextConverter();
            converter.XmlConverterService = new XmlConverterService(resolver);
            converter.Convert(iterator, this.Writer);

            string actual = this.GetConvertedStream();
            string fileName = Path.GetFileName(Directory.GetFiles(imagesAbsolutePath, "*.png")[0]);

            Assert.AreEqual("<p><img src=\"images\\" + fileName + "\" /></p>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\Figure.xml")]
        public void ShouldNotConvertFigure_ResolverIsNull()
        {
            XmlDocument document = new XmlDocument();
            document.Load("Figure.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlBodyTextConverter converter = new XmlBodyTextConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, this.Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<p><img src=\"rId7\" /></p>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\FigureNumber.xml")]
        public void ShouldConvertFigureNumber()
        {
            XmlDocument document = new XmlDocument();
            document.Load("FigureNumber.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlFigureNumberConverter converter = new XmlFigureNumberConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.XmlConverterService.ResetElementNumbers();
            converter.Convert(iterator, this.Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<figurenumber>Figure 1</figurenumber>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\FigureNumberEmpty.xml")]
        public void ShouldConvertFigureNumberEmpty()
        {
            XmlDocument document = new XmlDocument();
            document.Load("FigureNumberEmpty.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlFigureNumberConverter converter = new XmlFigureNumberConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, this.Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<br />", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\FigureCaption.xml")]
        public void ShouldConvertFigureCaption()
        {
            XmlDocument document = new XmlDocument();
            document.Load("FigureCaption.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlFigureCaptionConverter converter = new XmlFigureCaptionConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, this.Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<figurecaption>This is a figure caption</figurecaption>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\FigureCaptionEmpty.xml")]
        public void ShouldConvertFigureCaptionEmpty()
        {
            XmlDocument document = new XmlDocument();
            document.Load("FigureCaptionEmpty.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlFigureCaptionConverter converter = new XmlFigureCaptionConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, this.Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<br />", actual);
        }

        [TestMethod]
        [DeploymentItem(@"DocxInput\ReferenceToFigure.docx")]
        [DeploymentItem(@"OpenXmlInput\ReferenceToFigureTopic2.xml")]
        public void ShouldConvertReferenceToFigureReseted()
        {
            string documentName = Directory.GetCurrentDirectory() + "\\ReferenceToFigure.docx";
            string imagesPath = "images";
            string imagesAbsolutePath = Directory.GetCurrentDirectory() + "\\" + imagesPath;
            string imagesFormat = ".png";
            Directory.CreateDirectory(imagesAbsolutePath);

            IReferenceResolver resolver = new OpenXmlReferenceResolver(documentName, imagesPath, imagesAbsolutePath, imagesFormat);

            XmlDocument document = new XmlDocument();
            document.Load("ReferenceToFigureTopic2.xml");

            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p[w:pPr/w:pStyle[@w:val='ppBodyText']]", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlBodyTextConverter converter = new XmlBodyTextConverter();
            converter.XmlConverterService = new XmlConverterService(resolver);
            converter.XmlConverterService.ResetElementNumbers();
            converter.Convert(iterator, this.Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<p>Look at the Figure 1</p>", actual);
        }
    }
}
