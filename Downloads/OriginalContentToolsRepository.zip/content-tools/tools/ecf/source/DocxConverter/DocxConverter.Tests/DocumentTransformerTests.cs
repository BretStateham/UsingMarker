﻿namespace DocxConverter.Tests
{
    using System;
    using System.IO;
    using System.Xml;
    using System.Xml.XPath;
    using Microsoft.Practices.DocxConverter;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class DocumentTransformerTests
    {   
        [TestMethod]
        [DeploymentItem(@"TestFolder\Transformation")]
        [DeploymentItem(@"TestFolder\XmlFiles")]
        public void ShouldTransformXmlDocument()
        {
            string transformFile = Path.GetFullPath("Transformation\\xsl\\Domain.xsl");
            string configFile = Path.GetFullPath("Transformation\\xsl\\ppdocConfig.xml");

            XmlDocument xmlDocument = new XmlDocument();
            xmlDocument.Load(Path.GetFullPath("XmlFiles\\default.xml"));

            DocumentTransformer transformer = new DocumentTransformer()
            {
                TransformFile = transformFile, 
                ConfigFile = configFile
            };

            IXPathNavigable xmlOutput = transformer.Transform(xmlDocument, null);

            Assert.IsNotNull(xmlOutput);
        }

        [TestMethod, ExpectedException(typeof(ArgumentException))]
        public void ShouldTransformerThrowExceptionWithInvalidXmlDocuments()
        {
            string transformFile = Path.GetFullPath("Transformation\\xsl\\Domain.xsl");
            string configFile = Path.GetFullPath("Transformation\\xsl\\ppdocConfig.xml");

            XmlNode xmlNode = null;

            DocumentTransformer transformer = new DocumentTransformer()
            {
                TransformFile = transformFile, 
                ConfigFile = configFile
            };

            IXPathNavigable xmlOutput = transformer.Transform(xmlNode, null);
        }

        [TestMethod]
        public void ShouldTransformerGenerateOtputFile()
        {
            string transformFile = Path.GetFullPath("Transformation\\xsl\\Domain.xsl");
            string configFile = Path.GetFullPath("Transformation\\xsl\\ppdocConfig.xml");

            string outputFile = Path.GetFullPath("TransformedFile.html");

            XmlDocument xmlDocument = new XmlDocument();
            xmlDocument.Load(Path.GetFullPath("XmlFiles\\default.xml"));

            DocumentTransformer transformer = new DocumentTransformer()
            {
                TransformFile = transformFile,
                ConfigFile = configFile
            };

            IXPathNavigable xmlOutput = transformer.Transform(xmlDocument, outputFile);

            Assert.IsTrue(File.Exists(outputFile));

            File.Delete(outputFile);
        }
    }
}
