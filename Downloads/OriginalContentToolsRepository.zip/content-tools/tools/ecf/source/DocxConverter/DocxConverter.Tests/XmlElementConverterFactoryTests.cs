// ===============================================================================
// Microsoft patterns & practices
// Documentation Tools - January 2008 
//-------------------------------------------------------------------------------
// Copyright �  Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//-------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ===============================================================================

namespace DocxConverter.Tests
{
    using System;
    using System.Configuration;
    using System.Xml;
    using Microsoft.Practices.DocxConverter;
    using Microsoft.Practices.DocxConverter.Converters;
    using Microsoft.Practices.DocxConverter.ElementConverters;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class XmlElementConverterFactoryTests : OpenXmlElementConvertersTests
    {
        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\BodyText.xml")]
        public void ShouldFactoryCreateXmlBodyTextConverter()
        {
            XmlDocument openXmlInput = new XmlDocument();
            openXmlInput.Load("BodyText.xml");

            XmlNode node = openXmlInput.SelectSingleNode("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(openXmlInput));

            string configPath = "DocxConverter.Tests.dll.config";

            XmlElementConverterFactory factory = new XmlElementConverterFactory(OpenXmlHelper.GetNamespaceManager(openXmlInput), configPath);

            IConverter converter = factory.CreateConverter(node);

            Assert.AreEqual(converter.GetType().ToString(), typeof(XmlBodyTextConverter).ToString());
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\NumberList.xml")]
        public void ShouldFactoryCreateXmlNumberListConverter()
        {
            XmlDocument openXmlInput = new XmlDocument();
            openXmlInput.Load("NumberList.xml");

            XmlNode node = openXmlInput.SelectSingleNode("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(openXmlInput));

            string configPath = "DocxConverter.Tests.dll.config";

            XmlElementConverterFactory factory = new XmlElementConverterFactory(OpenXmlHelper.GetNamespaceManager(openXmlInput), configPath);

            IConverter converter = factory.CreateConverter(node);

            Assert.AreEqual(converter.GetType().ToString(), typeof(XmlNumberListConverter).ToString());
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\UnknownStyle.xml")]
        public void ShouldFactoryCreateXmlNullConverter_UnkwnownXmlElement()
        {
            XmlDocument openXmlInput = new XmlDocument();
            openXmlInput.Load("UnknownStyle.xml");

            XmlNode node = openXmlInput.SelectSingleNode("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(openXmlInput));
            
            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlElementConverterFactory factory = new XmlElementConverterFactory(OpenXmlHelper.GetNamespaceManager(openXmlInput), configPath);

            IConverter converter = factory.CreateConverter(node);

            Assert.AreEqual(converter.GetType().ToString(), typeof(XmlNullConverter).ToString());
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\TableWithNoHeaderOneColumnOneRowEmpty.xml")]
        public void ShouldFactoryCreateXmlTableConverter()
        {
            XmlDocument openXmlInput = new XmlDocument();
            openXmlInput.Load("TableWithNoHeaderOneColumnOneRowEmpty.xml");

            XmlNode node = openXmlInput.SelectSingleNode("descendant-or-self::w:tbl", OpenXmlHelper.GetNamespaceManager(openXmlInput));

            string configPath = "DocxConverter.Tests.dll.config";

            XmlElementConverterFactory factory = new XmlElementConverterFactory(OpenXmlHelper.GetNamespaceManager(openXmlInput), configPath);

            IConverter converter = factory.CreateConverter(node);

            Assert.AreEqual(converter.GetType().ToString(), typeof(XmlTableConverter).ToString());
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\TableWithNoStyle.xml")]
        public void ShouldFactoryCreateXmlTableConverter_TableWithNoStyle()
        {
            XmlDocument openXmlInput = new XmlDocument();
            openXmlInput.Load("TableWithNoStyle.xml");

            XmlNode node = openXmlInput.SelectSingleNode("descendant-or-self::w:tbl", OpenXmlHelper.GetNamespaceManager(openXmlInput));

            string configPath = "DocxConverter.Tests.dll.config";

            XmlElementConverterFactory factory = new XmlElementConverterFactory(OpenXmlHelper.GetNamespaceManager(openXmlInput), configPath);

            IConverter converter = factory.CreateConverter(node);

            Assert.AreEqual(converter.GetType().ToString(), typeof(XmlTableConverter).ToString());
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\TableWithTableGridStyle.xml")]
        public void ShouldFactoryCreateXmlTableConverter_TableWithTableGridStyle()
        {
            XmlDocument openXmlInput = new XmlDocument();
            openXmlInput.Load("TableWithTableGridStyle.xml");

            XmlNode node = openXmlInput.SelectSingleNode("descendant-or-self::w:tbl", OpenXmlHelper.GetNamespaceManager(openXmlInput));

            string configPath = "DocxConverter.Tests.dll.config";

            XmlElementConverterFactory factory = new XmlElementConverterFactory(OpenXmlHelper.GetNamespaceManager(openXmlInput), configPath);

            IConverter converter = factory.CreateConverter(node);

            Assert.AreEqual(converter.GetType().ToString(), typeof(XmlTableConverter).ToString());
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\TableWithHeaderOneColumnOneRowEmpty.xml")]
        public void ShouldFactoryCreateXmlTableWithHeaderConverter()
        {
            XmlDocument openXmlInput = new XmlDocument();
            openXmlInput.Load("TableWithHeaderOneColumnOneRowEmpty.xml");

            XmlNode node = openXmlInput.SelectSingleNode("descendant-or-self::w:tbl", OpenXmlHelper.GetNamespaceManager(openXmlInput));

            string configPath = "DocxConverter.Tests.dll.config";

            XmlElementConverterFactory factory = new XmlElementConverterFactory(OpenXmlHelper.GetNamespaceManager(openXmlInput), configPath);

            IConverter converter = factory.CreateConverter(node);

            Assert.AreEqual(converter.GetType().ToString(), typeof(XmlTableWithHeaderConverter).ToString());
        }

        [TestMethod]
        [ExpectedException(typeof(NotSupportedException), "Converter Factory error: Invalid type")]
        [DeploymentItem(@"OpenXmlInput\BodyText.xml")]
        public void ShouldFactoryGenerateExceptionTypeNotFound_WrongType()
        {
            XmlDocument openXmlInput = new XmlDocument();
            openXmlInput.Load("BodyText.xml");

            XmlNode node = openXmlInput.SelectSingleNode("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(openXmlInput));

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlElementConverterFactory factory = new XmlElementConverterFactory(OpenXmlHelper.GetNamespaceManager(openXmlInput), configPath, "converters/elementConvertersTest1");

            IConverter converter = factory.CreateConverter(node);
        }

        [TestMethod]
        [ExpectedException(typeof(NotSupportedException), "Converter Factory error: Invalid type")]
        [DeploymentItem(@"OpenXmlInput\BodyText.xml")]
        public void ShouldFactoryGenerateExceptionInvalidType_WrongAssembly()
        {
            XmlDocument openXmlInput = new XmlDocument();
            openXmlInput.Load("BodyText.xml");

            XmlNode node = openXmlInput.SelectSingleNode("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(openXmlInput));

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlElementConverterFactory factory = new XmlElementConverterFactory(OpenXmlHelper.GetNamespaceManager(openXmlInput), configPath, "converters/elementConvertersTest2");

            IConverter converter = factory.CreateConverter(node);
        }

        [TestMethod]
        [ExpectedException(typeof(NotSupportedException), "Converter Factory error: Invalid type")]
        [DeploymentItem(@"OpenXmlInput\BodyText.xml")]
        public void ShouldFactoryGenerateExceptionInvalidTypeParam_WrongTypeParam()
        {
            XmlDocument openXmlInput = new XmlDocument();
            openXmlInput.Load("BodyText.xml");

            XmlNode node = openXmlInput.SelectSingleNode("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(openXmlInput));

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlElementConverterFactory factory = new XmlElementConverterFactory(OpenXmlHelper.GetNamespaceManager(openXmlInput), configPath, "converters/elementConvertersTest3");

            IConverter converter = factory.CreateConverter(node);
        }

        [TestMethod]
        [ExpectedException(typeof(ConfigurationErrorsException), "Required attribute 'path' not found")]
        [DeploymentItem(@"OpenXmlInput\BodyText.xml")]
        public void ShouldFactoryGenerateExceptionInvalidTypeParam_MissingTypeParam()
        {
            XmlDocument openXmlInput = new XmlDocument();
            openXmlInput.Load("BodyText.xml");

            XmlNode node = openXmlInput.SelectSingleNode("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(openXmlInput));

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlElementConverterFactory factory = new XmlElementConverterFactory(OpenXmlHelper.GetNamespaceManager(openXmlInput), configPath, "converters/elementConvertersTest4");

            IConverter converter = factory.CreateConverter(node);
        }

        [TestMethod]
        [ExpectedException(typeof(NotSupportedException), "Converter Factory error: Specified type does not implement the converter interface")]
        [DeploymentItem(@"OpenXmlInput\BodyText.xml")]
        public void ShouldFactoryGenerateExceptionInterfaceNotImplemented()
        {
            XmlDocument openXmlInput = new XmlDocument();
            openXmlInput.Load("BodyText.xml");

            XmlNode node = openXmlInput.SelectSingleNode("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(openXmlInput));

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlElementConverterFactory factory = new XmlElementConverterFactory(OpenXmlHelper.GetNamespaceManager(openXmlInput), configPath, "converters/elementConvertersTest5");

            IConverter converter = factory.CreateConverter(node);
        }

        [TestMethod]
        [ExpectedException(typeof(ConfigurationErrorsException), "Plugin Configuration error: Configuration not found")]
        [DeploymentItem(@"OpenXmlInput\BodyText.xml")]
        public void ShouldFactoryGenerateExceptionConfigNotFound()
        {
            XmlDocument openXmlInput = new XmlDocument();
            openXmlInput.Load("BodyText.xml");

            XmlNode node = openXmlInput.SelectSingleNode("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(openXmlInput));

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlElementConverterFactory factory = new XmlElementConverterFactory(OpenXmlHelper.GetNamespaceManager(openXmlInput), "converters/sectionNotFound");

            IConverter converter = factory.CreateConverter(node);
        }

        [TestMethod]
        [ExpectedException(typeof(NotSupportedException), "Plugin Configuration error: Invalid path expression")]
        [DeploymentItem(@"OpenXmlInput\BodyText.xml")]
        public void ShouldFactoryGenerateExceptionInvalidPathExpression()
        {
            XmlDocument openXmlInput = new XmlDocument();
            openXmlInput.Load("BodyText.xml");

            XmlNode node = openXmlInput.SelectSingleNode("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(openXmlInput));

            string configPath = "DocxConverter.Tests.dll.config";

            XmlElementConverterFactory factory = new XmlElementConverterFactory(OpenXmlHelper.GetNamespaceManager(openXmlInput), configPath, "converters/elementConvertersTest6");

            IConverter converter = factory.CreateConverter(node);
        }

        [TestMethod]
        [ExpectedException(typeof(ConfigurationErrorsException), "Required attribute 'path' not found")]
        [DeploymentItem(@"OpenXmlInput\BodyText.xml")]
        public void ShouldFactoryGenerateExceptionInvalidTypeParam_MissingPathParam()
        {
            XmlDocument openXmlInput = new XmlDocument();
            openXmlInput.Load("BodyText.xml");

            XmlNode node = openXmlInput.SelectSingleNode("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(openXmlInput));

            XmlElementConverterFactory factory = new XmlElementConverterFactory(OpenXmlHelper.GetNamespaceManager(openXmlInput), "converters/elementConvertersTest7");

            IConverter converter = factory.CreateConverter(node);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\BodyText.xml")]
        public void ShouldGetIndentationLevel0ForBodyText()
        {
            XmlDocument openXmlInput = new XmlDocument();
            openXmlInput.Load("BodyText.xml");
            XmlNode bodyText = openXmlInput.SelectSingleNode("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(openXmlInput));

            XmlElementConverterFactory factory = new XmlElementConverterFactory(OpenXmlHelper.GetNamespaceManager(openXmlInput), "DocxConverter.Tests.dll.config");
            int level = factory.GetIndentationLevel(bodyText);

            Assert.AreEqual(0, level);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\BulletListsWithBodyTextIndentBetween.xml")]
        public void ShouldGetIndentationLevel1ForBodyTextIndent()
        {
            XmlDocument openXmlInput = new XmlDocument();
            openXmlInput.Load("BulletListsWithBodyTextIndentBetween.xml");
            XmlNode bodyTextIndent = openXmlInput.DocumentElement.FirstChild.ChildNodes[2];

            XmlElementConverterFactory factory = new XmlElementConverterFactory(OpenXmlHelper.GetNamespaceManager(openXmlInput), "DocxConverter.Tests.dll.config");
            int level = factory.GetIndentationLevel(bodyTextIndent);

            Assert.AreEqual(1, level);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\BulletListsWithBodyTextIndentBetween.xml")]
        public void ShouldGetXmlBodyTextConverterTypeForBodyTextIndent()
        {
            XmlDocument openXmlInput = new XmlDocument();
            openXmlInput.Load("BulletListsWithBodyTextIndentBetween.xml");
            XmlNode bodyTextIndent = openXmlInput.DocumentElement.FirstChild.ChildNodes[2];

            XmlElementConverterFactory factory = new XmlElementConverterFactory(OpenXmlHelper.GetNamespaceManager(openXmlInput), "DocxConverter.Tests.dll.config");
            Type type = factory.GetConverterType(bodyTextIndent);

            Assert.AreEqual(typeof(XmlBodyTextConverter), type);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\UnknownStyle.xml")]
        public void ShouldReturnNullForNonExistingConverter()
        {
            XmlDocument openXmlInput = new XmlDocument();
            openXmlInput.Load("UnknownStyle.xml");
            XmlNode unknownStyle = openXmlInput.DocumentElement.FirstChild.ChildNodes[0];

            XmlElementConverterFactory factory = new XmlElementConverterFactory(OpenXmlHelper.GetNamespaceManager(openXmlInput), "DocxConverter.Tests.dll.config");
            Type type = factory.GetConverterType(unknownStyle);

            Assert.IsNull(type);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\HOL1Style.xml")]
        public void ShouldFactoryCreateXmlHeading4ConverterForHol1Style()
        {
            XmlDocument openXmlInput = new XmlDocument();
            openXmlInput.Load("HOL1Style.xml");

            XmlNode node = openXmlInput.SelectSingleNode("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(openXmlInput));

            string configPath = "DocxConverter.Tests.dll.config";

            XmlElementConverterFactory factory = new XmlElementConverterFactory(OpenXmlHelper.GetNamespaceManager(openXmlInput), configPath);

            IConverter converter = factory.CreateConverter(node);

            Assert.AreEqual(converter.GetType().ToString(), typeof(XmlHeading4Converter).ToString());
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\HOLDescriptionStyle.xml")]
        public void ShouldFactoryCreateXmlHeading1ConverterForDescriptionStyle()
        {
            XmlDocument openXmlInput = new XmlDocument();
            openXmlInput.Load("HOLDescriptionStyle.xml");

            XmlNode node = openXmlInput.SelectSingleNode("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(openXmlInput));

            string configPath = "DocxConverter.Tests.dll.config";

            XmlElementConverterFactory factory = new XmlElementConverterFactory(OpenXmlHelper.GetNamespaceManager(openXmlInput), configPath);

            IConverter converter = factory.CreateConverter(node);

            Assert.AreEqual(converter.GetType().ToString(), typeof(XmlHeading1Converter).ToString());
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\BodyNoIndent.xml")]
        public void ShouldFactoryCreateXmlBodyTextConverterForBodyNoIndentStyle()
        {
            XmlDocument openXmlInput = new XmlDocument();
            openXmlInput.Load("BodyNoIndent.xml");

            XmlNode node = openXmlInput.SelectSingleNode("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(openXmlInput));

            string configPath = "DocxConverter.Tests.dll.config";

            XmlElementConverterFactory factory = new XmlElementConverterFactory(OpenXmlHelper.GetNamespaceManager(openXmlInput), configPath);

            IConverter converter = factory.CreateConverter(node);

            Assert.AreEqual(converter.GetType().ToString(), typeof(XmlBodyTextConverter).ToString());
        }
    }
}
