// ===============================================================================
// Microsoft patterns & practices
// Documentation Tools - January 2008 
//-------------------------------------------------------------------------------
// Copyright �  Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//-------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ===============================================================================

namespace DocxConverter.Tests
{
    using System.Xml;
    using System.Xml.XPath;
    using Microsoft.Practices.DocxConverter;
    using Microsoft.Practices.DocxConverter.ElementConverters;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class XmlHeadingConverterTests : OpenXmlElementConvertersTests
    {
        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\Heading1.xml")]
        public void ShouldConvertHeading1()
        {
            XmlDocument document = new XmlDocument();
            document.Load("Heading1.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlHeading1Converter converter = new XmlHeading1Converter();
            converter.XmlConverterService = new XmlConverterService(); 
            converter.Convert(iterator, this.Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<h1>This is heading 1</h1>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\Heading2.xml")]
        public void ShouldConvertHeading2()
        {
            XmlDocument document = new XmlDocument();
            document.Load("Heading2.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlHeading2Converter converter = new XmlHeading2Converter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, this.Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<h2>This is heading 2</h2>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\Heading3.xml")]
        public void ShouldConvertHeading3()
        {
            XmlDocument document = new XmlDocument();
            document.Load("Heading3.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlHeading3Converter converter = new XmlHeading3Converter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, this.Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<h3>This is heading 3</h3>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\Heading4.xml")]
        public void ShouldConvertHeading4()
        {
            XmlDocument document = new XmlDocument();
            document.Load("Heading4.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            XmlHeading4Converter converter = new XmlHeading4Converter();
            converter.XmlConverterService = new XmlConverterService();
            converter.Convert(iterator, this.Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<h4>This is heading 4</h4>", actual);
        }
    }
}
