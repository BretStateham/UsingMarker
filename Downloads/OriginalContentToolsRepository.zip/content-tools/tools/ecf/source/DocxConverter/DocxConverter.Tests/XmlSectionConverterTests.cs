// ===============================================================================
// Microsoft patterns & practices
// Documentation Tools - January 2008 
//-------------------------------------------------------------------------------
// Copyright �  Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//-------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ===============================================================================

namespace DocxConverter.Tests
{
    using System.Xml;
    using System.Xml.XPath;
    using Microsoft.Practices.DocxConverter;
    using Microsoft.Practices.DocxConverter.Converters;
    using Microsoft.Practices.DocxConverter.ElementConverters;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class XmlSectionConverterTests : OpenXmlElementConvertersTests
    {
        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\Section.xml")]
        public void ShouldConvertSection()
        {
            XmlDocument document = new XmlDocument();
            document.Load("Section.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlSectionConverter converter = new XmlSectionConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.XmlConverterService.ResetElementNumbers();
            converter.Convert(iterator, this.Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<section id=\"1\"><title>This is a Section</title><contents /></section>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\SectionEmpty.xml")]
        public void ShouldConvertSectionEmpty()
        {
            XmlDocument document = new XmlDocument();
            document.Load("SectionEmpty.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlSectionConverter converter = new XmlSectionConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.XmlConverterService.ResetElementNumbers();
            converter.Convert(iterator, this.Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<section id=\"1\"><title /><contents /></section>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\DocWithTwoSections.xml")]
        public void ShouldConvertSectionsWithConsecutiveIds()
        {
            XmlDocument openXmlInput = new XmlDocument();
            openXmlInput.Load("DocWithTwoSections.xml");

            XmlNode nodeStart = openXmlInput.SelectSingleNode(@"//w:body/*[1]", OpenXmlHelper.GetNamespaceManager(openXmlInput));

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            var xmlConverterService = new XmlConverterService();
            XmlDocument xmlOutput = OpenXmlProcessor.Convert(nodeStart, null, xmlConverterService);

            Assert.AreEqual<string>("<contents><section id=\"1\"><title>Section 1</title><contents /></section><section id=\"2\"><title>Section 2</title><contents /></section></contents>", xmlOutput.SelectSingleNode("descendant-or-self::contents").OuterXml);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\SectionFollowedByBodyTextAndOtherSection.xml")]
        public void ShouldConvertSectionWithBodyTextInside_OtherSectionAtEnd()
        {
            XmlDocument document = new XmlDocument();
            document.Load("SectionFollowedByBodyTextAndOtherSection.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlSectionConverter converter = new XmlSectionConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.XmlConverterService.ResetElementNumbers();
            converter.Convert(iterator, this.Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<section id=\"1\"><title>Section 1</title><contents><p>This is section 1</p></contents></section>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\SectionFollowedByBodyTextAndATopicAtEnd.xml")]
        public void ShouldConvertSectionWithBodyTextInside_TopicAtEnd()
        {
            XmlDocument document = new XmlDocument();
            document.Load("SectionFollowedByBodyTextAndATopicAtEnd.xml");
            XmlNode node = document.SelectSingleNode("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            XPathNavigator navigator = node.CreateNavigator();          
            XPathNodeIterator iterator = navigator.Select(".|following-sibling::*");
            iterator.MoveNext();

            var xmlConverterService = new XmlConverterService();
            xmlConverterService.ResetElementNumbers();
            xmlConverterService.EndNode = document.SelectSingleNode("descendant-or-self::w:sdt[w:sdtPr/w:alias[@w:val='Topic']]", OpenXmlHelper.GetNamespaceManager(document));

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlSectionConverter converter = new XmlSectionConverter();
            converter.XmlConverterService = xmlConverterService;
            converter.Convert(iterator, this.Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<section id=\"1\"><title>Section 1</title><contents><p>This is section 1</p></contents></section>", actual);
        }
    }
}
