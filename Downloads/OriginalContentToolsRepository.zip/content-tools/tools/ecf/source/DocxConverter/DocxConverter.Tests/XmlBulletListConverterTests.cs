// ===============================================================================
// Microsoft patterns & practices
// Documentation Tools - January 2008 
//-------------------------------------------------------------------------------
// Copyright �  Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//-------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ===============================================================================

namespace DocxConverter.Tests
{
    using System.Xml;
    using System.Xml.XPath;
    using Microsoft.Practices.DocxConverter;
    using Microsoft.Practices.DocxConverter.Converters;
    using Microsoft.Practices.DocxConverter.ElementConverters;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class XmlBulletListConverterTests : OpenXmlElementConvertersTests
    {
        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\BulletList.xml")]
        public void ShouldConvertBulletList()
        {
            XmlDocument document = new XmlDocument();
            document.Load("BulletList.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlBulletListConverter converter = new XmlBulletListConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 1;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<ul><step><title>Bullet list item 1.</title><contents /></step><step><title>Bullet list item 2.</title><contents /></step></ul>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\BulletListWithNoRunOrNoTextElement.xml")]
        public void ShouldConvertBulletListEmpty_NoRunOrNoTextElement()
        {
            XmlDocument document = new XmlDocument();
            document.Load("BulletListWithNoRunOrNoTextElement.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlBulletListConverter converter = new XmlBulletListConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 1;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<ul><step><br /><contents /></step><step><br /><contents /></step></ul>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\BulletListsWithListEnd.xml")]
        public void ShouldConvertBulletList_ListsSeparatedWithListEnd()
        {
            XmlDocument document = new XmlDocument();
            document.Load("BulletListsWithListEnd.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlBulletListConverter converter = new XmlBulletListConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 1;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<ul><step><title>List item A1.</title><contents /></step><step><title>List item A2.</title><contents /></step></ul>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\BulletListsWithBodyTextIndentBetween.xml")]
        public void ShouldConvertBulletListWithBodyTextIndentBetween()
        {
            XmlDocument document = new XmlDocument();
            document.Load("BulletListsWithBodyTextIndentBetween.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlBulletListConverter converter = new XmlBulletListConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 1;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<ul><step><title>List item A1.</title><contents /></step><step><title>List item A2.</title><contents><p>Some text.</p></contents></step><step><title>List item B1.</title><contents /></step><step><title>List item B2.</title><contents /></step></ul>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\BulletListWithBodyTextIndentAtTheEnd.xml")]
        public void ShouldConvertBulletListWithBodyTextIndentAtTheEnd()
        {
            XmlDocument document = new XmlDocument();
            document.Load("BulletListWithBodyTextIndentAtTheEnd.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;
        
            XmlBulletListConverter converter = new XmlBulletListConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 1;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<ul><step><title>Bullet list item 1.</title><contents /></step><step><title>Bullet list item 2.</title><contents><p>This is text</p></contents></step></ul>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\BulletList.xml")]
        public void ShouldConvertBulletListWithConversionErr_WrongNode()
        {
            XmlDocument document = new XmlDocument();
            document.Load("BulletList.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:r", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlBulletListConverter converter = new XmlBulletListConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 1;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<ul><step><title>Could not convert node</title><contents /></step></ul>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\BulletListWithNoListEndAndBodyTextNext.xml")]
        public void ShouldConvertBulletList_BodyStyleAtTheEnd()
        {
            XmlDocument document = new XmlDocument();
            document.Load("BulletListWithNoListEndAndBodyTextNext.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlBulletListConverter converter = new XmlBulletListConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 1;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<ul><step><title>List item A1.</title><contents /></step></ul>", actual);
        }

        [TestMethod]
        [DeploymentItem(@"OpenXmlInput\BulletListNestedLevelsWithInnerLevelBetween.xml")]
        public void ShouldConvertBulletListNestedLevelsWithInnerLevelBetween()
        {
            XmlDocument document = new XmlDocument();
            document.Load("BulletListNestedLevelsWithInnerLevelBetween.xml");
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator iterator = navigator.Select("descendant-or-self::w:p", OpenXmlHelper.GetNamespaceManager(document));
            iterator.MoveNext();

            string configPath = "DocxConverter.Tests.dll.config";
            ConverterFactory.ConfigurationPath = configPath;

            XmlBulletListConverter converter = new XmlBulletListConverter();
            converter.XmlConverterService = new XmlConverterService();
            converter.IndentationLevel = 1;
            converter.Convert(iterator, Writer);

            string actual = this.GetConvertedStream();

            Assert.AreEqual("<ul><step><title>List item 1.</title><contents><ul><step><title>List item a1.</title><contents /></step></ul></contents></step><step><title>List item 2.</title><contents /></step></ul>", actual);
        }
    }
}
