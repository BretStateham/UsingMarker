﻿namespace Microsoft.Dpe.Ecf.Core.Tests.Functional
{
    using System;
    using System.IO;
    using Microsoft.Dpe.Ecf.Core.Steps;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    [DeploymentItem(@"Resources\AddCopyrightHeaderStepFixture", "AddCopyrightHeaderStepFixture")]
    public class AddCopyrightHeaderStepFixture
    {
        [TestMethod]
        public void ExecuteShouldReadCopyrightHeader()
        {
            var step = new TestableAddCopyrightHeaderStep();
            var path = Path.GetFullPath("AddCopyrightHeaderStepFixture\\CopyrightWithCSharpComments.txt");

            step.HeaderFileName = path;
            step.FilePath = null;
            step.Execute();

            var header = File.ReadAllText(path);
            Assert.IsTrue(String.Compare(header, step.CopyrightHeader, StringComparison.OrdinalIgnoreCase) == 0);
        }

        [TestMethod]
        public void ExecuteShouldAddCSCopyrightHeader()
        {
            var copyrightPath = Path.GetFullPath("AddCopyrightHeaderStepFixture\\CopyrightWithCSharpComments.txt");
            var testClassPath = Path.GetFullPath("AddCopyrightHeaderStepFixture\\ExecuteShouldAddCSCopyrightHeader\\TestClass.cs");
            var filePath = Path.GetFullPath("AddCopyrightHeaderStepFixture\\ExecuteShouldAddCSCopyrightHeader");

            var step = new AddCopyrightHeaderStep();
            step.HeaderFileName = copyrightPath;
            step.FilePath = filePath;

            step.Execute();

            var header = File.ReadAllText(copyrightPath);
            var finalFile = File.ReadAllText(testClassPath);

            Assert.IsTrue(finalFile.StartsWith(header, StringComparison.OrdinalIgnoreCase));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ExecuteShouldThrowArgumentException()
        {
            var step = new AddCopyrightHeaderStep();
            step.HeaderFileName = "Invalid.File";
            step.FilePath = null;

            step.Execute();
        }

        [TestMethod]
        public void ExecuteShouldAddVBCopyrightHeaderIfCopyrightHasNoComments()
        {
            var copyrightPath = Path.GetFullPath("AddCopyrightHeaderStepFixture\\CopyrightWithNoComments.txt");
            var testClassPath = Path.GetFullPath("AddCopyrightHeaderStepFixture\\ExecuteShouldAddVBCopyrightHeaderIfCopyrightHasNoComments\\TestClass.vb");
            var filePath = Path.GetFullPath("AddCopyrightHeaderStepFixture\\ExecuteShouldAddVBCopyrightHeaderIfCopyrightHasNoComments");

            var step = new AddCopyrightHeaderStep();
            step.HeaderFileName = copyrightPath;
            step.FilePath = filePath;

            step.Execute();

            var header = File.ReadAllText(copyrightPath);
            var finalFile = File.ReadAllText(testClassPath);

            Assert.IsTrue(finalFile.StartsWith("' ", StringComparison.OrdinalIgnoreCase), "VB Header was not added correctly");
            Assert.IsFalse(finalFile.StartsWith("' '", StringComparison.OrdinalIgnoreCase), "VB Header was not added correctly");
        }

        [TestMethod]
        public void ExecuteShouldAddVBCopyrightHeaderIfCopyrightHasVBComments()
        {
            var copyrightPath = Path.GetFullPath("AddCopyrightHeaderStepFixture\\CopyrightWithVBComments.txt");
            var testClassPath = Path.GetFullPath("AddCopyrightHeaderStepFixture\\ExecuteShouldAddVBCopyrightHeaderIfCopyrightHasVBComments\\TestClass.vb");
            var filePath = Path.GetFullPath("AddCopyrightHeaderStepFixture\\ExecuteShouldAddVBCopyrightHeaderIfCopyrightHasVBComments");

            var step = new AddCopyrightHeaderStep();
            step.HeaderFileName = copyrightPath;
            step.FilePath = filePath;

            step.Execute();

            var header = File.ReadAllText(copyrightPath);
            var finalFile = File.ReadAllText(testClassPath);

            Assert.IsTrue(finalFile.StartsWith("' ", StringComparison.OrdinalIgnoreCase), "VB Header was not added correctly");
            Assert.IsFalse(finalFile.StartsWith("' '", StringComparison.OrdinalIgnoreCase), "VB Header was not added correctly");
        }

        [TestMethod]
        public void ExecuteShouldAddCSCopyrightHeaderIfCopyrightHasNoComments()
        {
            var copyrightPath = Path.GetFullPath("AddCopyrightHeaderStepFixture\\CopyrightWithNoComments.txt");
            var testClassPath = Path.GetFullPath("AddCopyrightHeaderStepFixture\\ExecuteShouldAddCSCopyrightHeaderIfCopyrightHasNoComments\\TestClass.cs");
            var filePath = Path.GetFullPath("AddCopyrightHeaderStepFixture\\ExecuteShouldAddCSCopyrightHeaderIfCopyrightHasNoComments");

            var step = new AddCopyrightHeaderStep();
            step.HeaderFileName = copyrightPath;
            step.FilePath = filePath;

            step.Execute();

            var header = File.ReadAllText(copyrightPath);
            var finalFile = File.ReadAllText(testClassPath);

            Assert.IsTrue(finalFile.StartsWith("// ", StringComparison.OrdinalIgnoreCase), "c# Header was not added correctly");
            Assert.IsFalse(finalFile.StartsWith("// /", StringComparison.OrdinalIgnoreCase), "c# Header was not added correctly");
        }

        [TestMethod]
        public void ExecuteShouldAddCSCopyrightHeaderIfCopyrightHasCSharpComments()
        {
            var copyrightPath = Path.GetFullPath("AddCopyrightHeaderStepFixture\\CopyrightWithCSharpComments.txt");
            var testClassPath = Path.GetFullPath("AddCopyrightHeaderStepFixture\\ExecuteShouldAddCSCopyrightHeaderIfCopyrightHasCSharpComments\\TestClass.cs");
            var filePath = Path.GetFullPath("AddCopyrightHeaderStepFixture\\ExecuteShouldAddCSCopyrightHeaderIfCopyrightHasCSharpComments");

            var step = new AddCopyrightHeaderStep();
            step.HeaderFileName = copyrightPath;
            step.FilePath = filePath;

            step.Execute();

            var header = File.ReadAllText(copyrightPath);
            var finalFile = File.ReadAllText(testClassPath);

            Assert.IsTrue(finalFile.StartsWith("// ", StringComparison.OrdinalIgnoreCase), "c# Header was not added correctly");
            Assert.IsFalse(finalFile.StartsWith("// /", StringComparison.OrdinalIgnoreCase), "c# Header was not added correctly");
        }
        
        [TestMethod]    
        public void ExecuteShouldNotAddDuplicatedCopyrightHeader()
        {
            var copyrightPath = Path.GetFullPath("AddCopyrightHeaderStepFixture\\ExecuteShouldNotAddDuplicatedCopyrightHeader\\Copyright.txt");
            var testClassPath = Path.GetFullPath("AddCopyrightHeaderStepFixture\\ExecuteShouldNotAddDuplicatedCopyrightHeader\\TestClassWithCopyright.cs");
            var filePath = Path.GetFullPath("AddCopyrightHeaderStepFixture\\ExecuteShouldNotAddDuplicatedCopyrightHeader");

            string originalTestClassTxt = File.ReadAllText(testClassPath); 
            Assert.IsTrue(originalTestClassTxt.StartsWith("//=="), "Test is reading the wrong file. File should start with // --, but is:\n" + originalTestClassTxt);

            var step = new AddCopyrightHeaderStep();
            step.HeaderFileName = copyrightPath;
            step.FilePath = filePath;

            step.Execute();

            var finalTestClassTxt = File.ReadAllText(testClassPath);

            Assert.AreEqual(originalTestClassTxt.Trim(), finalTestClassTxt);            
        }

        [TestMethod]
        public void ExecuteShouldNotModifyFiles()
        {
            var copyrightPath = Path.GetFullPath("AddCopyrightHeaderStepFixture\\CopyrightWithCSharpComments.txt");
            var testClassPath = Path.GetFullPath("AddCopyrightHeaderStepFixture\\ExecuteShouldNotModifyFiles\\TestClass.cs");

            var step = new AddCopyrightHeaderStep();
            step.HeaderFileName = copyrightPath;
            step.FilePath = null;

            step.Execute();

            var header = File.ReadAllText(copyrightPath);
            var finalFile = File.ReadAllText(testClassPath);

            Assert.IsFalse(finalFile.StartsWith("// ", StringComparison.OrdinalIgnoreCase), "c# Header should not be added");
            Assert.IsTrue(finalFile.StartsWith("namespace AddCopyrightHeaderStepFixture.ExecuteShouldNotModifyFiles.TestNameSpace", StringComparison.OrdinalIgnoreCase), "c# Header was not added correctly");
        }
        
        private class TestableAddCopyrightHeaderStep : AddCopyrightHeaderStep
        {
            public string CopyrightHeader 
            { 
                get; 
                set; 
            }

            protected override string ReadCopyrightFile(string path)
            {
                this.CopyrightHeader = base.ReadCopyrightFile(path);
                return this.CopyrightHeader;
            }
        }
    }
}
