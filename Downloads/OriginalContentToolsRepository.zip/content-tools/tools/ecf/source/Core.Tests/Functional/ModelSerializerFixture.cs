﻿namespace Microsoft.Dpe.Ecf.Core.Tests.Functional
{
    using System.IO;
    using Microsoft.Dpe.Ecf.Core.Tests.Mocks;
    using Microsoft.Dpe.Ecf.Model;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class ModelSerializerFixture
    {
        [TestMethod]
        public void ShouldSerializeToXMLStream()
        {
            Unit unit = MockFactory.CreateUnit();

            XMLModelSerializer<Unit> serializer = new XMLModelSerializer<Unit>();
            Stream streamUnit = serializer.Serialize(unit);

            Package package = MockFactory.CreatePackage(new string[] { "VisualSourceSafe", "TFSIntro" });

            XMLModelSerializer<Package> packageSerializer = new XMLModelSerializer<Package>();
            Stream streamPackage = packageSerializer.Serialize(package);

            Assert.IsTrue(streamUnit.Length > 0);
            Assert.IsTrue(streamPackage.Length > 0);
        }
    }
}
