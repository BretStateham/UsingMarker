﻿namespace Microsoft.Dpe.Ecf.Core.Tests
{
    using System;
    using Microsoft.Dpe.Ecf.Common;
    using Microsoft.Dpe.Ecf.Core.Steps;
    using Microsoft.Dpe.Ecf.Model;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class ReadMetadataStepFixture
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ExecuteShouldThrowArgumentExceptionForPackageNotFound()
        {
            ReadMetadataStep deserializeStep = new ReadMetadataStep
            {
                PackageXmlPath = "ReadMetadataStepFixture\\Packages\\MissingPackage.xml"
            };

            deserializeStep.Execute();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ExecuteShouldThrowArgumentExceptionForInvalidPackage()
        {
            ReadMetadataStep deserializeStep = new ReadMetadataStep
            {
                PackageXmlPath = string.Empty
            };

            deserializeStep.Execute();
        }

        [TestMethod]
        [ExpectedException(typeof(ContentFrameworkException))]
        public void ExecuteShouldThrowDocumentNotFound()
        {
            ReadMetadataStep deserializeStep = new ReadMetadataStep
            {
                PackageXmlPath = "ReadMetadataStepFixture\\Packages\\ExecuteShouldThrowDocumentNotFound_Package.xml"
            };

            deserializeStep.Execute();
        }

        [TestMethod]
        public void ExecuteDeserializePackage()
        {
            ReadMetadataStep deserializeStep = new ReadMetadataStep
            {
                PackageXmlPath = "ReadMetadataStepFixture\\Packages\\ExecuteDeserializePackage_Package.xml"
            };

            Package package = deserializeStep.Execute();

            // Test just not null. Correct deserialization is tests in deserialization fixtures
            Assert.IsNotNull(package);

            var lab = package.Units[0].Labs[0];

            Assert.IsFalse((lab.Document.ConversionType & ConversionType.Pdf) == ConversionType.Pdf);
            Assert.IsTrue((lab.Document.ConversionType & ConversionType.Html) == ConversionType.Html);
        }

        [TestMethod]
        public void ExecuteDeserializeUnicodePackage()
        {
            ReadMetadataStep deserializeStep = new ReadMetadataStep
            {
                PackageXmlPath = "ReadMetadataStepFixture\\Packages\\ExecuteDeserializeUnicodePackage_Package.xml"
            };

            Package package = deserializeStep.Execute();

            // Test just not null. Correct deserialization is tests in deserialization fixtures
            Assert.IsNotNull(package);
            Assert.IsTrue(package.Description.StartsWith("は、Visual Studio 2010および。NET Framework 4.0のトレーニングキット、プレゼンテーションが含まれて"));
            Assert.AreEqual("この項ではASP.NET 4.0の新機能の概要です。", package.Units[0].Description);
            Assert.AreEqual("掘り", package.Units[0].Labs[0].Description);
        }
    }
}
