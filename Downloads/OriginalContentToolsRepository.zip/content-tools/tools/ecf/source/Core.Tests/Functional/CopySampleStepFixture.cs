﻿namespace Microsoft.Dpe.Ecf.Core.Tests.Functional
{
    using System;
    using System.IO;
    using Microsoft.Dpe.Ecf.Core.Steps;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class CopySampleStepFixture
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ExecuteShouldThrowSampleNotFound()
        {
            CopySampleStep step = new CopySampleStep();
            step.SampleManifestsFilePath = "ConvertedDocuments\\inexistentXmlFile.xml";
            step.Execute();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ExecuteShouldThrowSampleNotSpecified()
        {
            CopySampleStep step = new CopySampleStep();
            step.Execute();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ExecuteShouldThrowOutputNotSpecified()
        {
            CopySampleStep step = new CopySampleStep();
            step.SampleManifestsFilePath = Path.GetFullPath(@"Content\Samples\SampleTest\Sample.xml");
            step.Execute();
        }

        [TestMethod]
        public void ShouldCopySampleWithoutAssets()
        {
            string outputFolder = "OutputForSampleTesting";

            CopySampleStep step = new CopySampleStep();
            step.SampleManifestsFilePath = Path.GetFullPath(@"Content\Samples\SampleTest\Sample.xml");
            step.OutputDirectory = Path.GetFullPath(outputFolder);

            step.Execute();

            // Directory structure
            string sampleFolder = Path.Combine(outputFolder, "Export_Points");
            string sourceFolder = Path.Combine(sampleFolder, "Source");
            string assetFolder = Path.Combine(outputFolder, "Assets");
            Assert.IsTrue(Directory.Exists(outputFolder));
            Assert.IsTrue(Directory.Exists(sampleFolder));
            Assert.IsFalse(Directory.Exists(assetFolder));

            // Delete resources crated
            Directory.Delete(outputFolder, true);
        }

        [TestMethod]
        public void ShouldCopyWithExcludePatter()
        {
            string outputFolder = "OutputForSampleTesting";

            CopySampleStep step = new CopySampleStep();
            step.SampleManifestsFilePath = Path.GetFullPath(@"Content\Samples\SampleTest\Sample.xml");
            step.OutputDirectory = Path.GetFullPath(outputFolder);
            step.Excludes = ".svn obj bin".Split(" ".ToCharArray());

            step.Execute();

            // Directory structure
            string sampleFolder = Path.Combine(outputFolder, "Export_Points");
            string sourceFolder = Path.Combine(sampleFolder, "Source");
            string binFolder = Path.Combine(sourceFolder, @"Demo\bin");
            string objFolder = Path.Combine(sourceFolder, @"Demo\obj");
            Assert.IsTrue(Directory.Exists(outputFolder));
            Assert.IsTrue(Directory.Exists(sampleFolder));
            Assert.IsFalse(Directory.Exists(binFolder));
            Assert.IsFalse(Directory.Exists(objFolder));
            Assert.IsFalse(Directory.Exists(Path.Combine(sampleFolder, ".svn")));

            // Delete resources crated
            Directory.Delete(outputFolder, true);
        }

        [TestMethod]
        public void ShouldCopyAssets()
        {
            string outputFolder = "OutputForSampleTesting";

            CopySampleStep step = new CopySampleStep();
            step.SampleManifestsFilePath = @"Content\Samples\SampleTest\Sample.xml";
            step.OutputDirectory = Path.GetFullPath(outputFolder);
            step.AssetDirectories = @"Assets1; Assets2";            

            step.Execute();

            // Directory structure
            string sampleFolder = Path.Combine(outputFolder, "Export_Points");
            string sourceFolder = Path.Combine(sampleFolder, "Source");
            string assetFolder = Path.Combine(sampleFolder, "Assets");            
            Assert.IsTrue(Directory.Exists(outputFolder));
            Assert.IsTrue(Directory.Exists(sampleFolder));            
            Assert.IsTrue(File.Exists(Path.Combine(assetFolder, "TextAsset2.txt")));
            Assert.IsTrue(Directory.Exists(Path.Combine(assetFolder, "Dir1")));

            // Delete resources crated
            Directory.Delete(outputFolder, true);
        }

        [TestMethod]
        public void ShouldCopyDependencyChecker()
        {
            string outputFolder = "OutputForSampleTesting";

            CopySampleStep step = new CopySampleStep();
            step.SampleManifestsFilePath = @"Content\Samples\SampleTest\Sample.xml";
            step.OutputDirectory = Path.GetFullPath(outputFolder);
            
            step.Execute();

            // Directory structure
            string sampleFolder = Path.Combine(outputFolder, "Export_Points");
            string startHere = Path.Combine(sampleFolder, "startHere.cmd");
            string dependencyCheckerFolder = Path.Combine(sampleFolder, "Assets\\DependencyChecker");
            Assert.IsTrue(Directory.Exists(dependencyCheckerFolder));            
            Assert.IsTrue(Directory.GetFiles(sampleFolder, "CheckDependencies.cmd", SearchOption.AllDirectories).Length > 0);

            // Delete resources crated
            Directory.Delete(outputFolder, true);
        }
    }
}
