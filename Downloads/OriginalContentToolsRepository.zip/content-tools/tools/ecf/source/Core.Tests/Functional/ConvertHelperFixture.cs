﻿namespace Microsoft.Dpe.Ecf.Core.Tests.Functional
{
    using System.IO;
    using Microsoft.Dpe.Ecf.Core.Helpers;
    using Microsoft.Dpe.Ecf.Core.Models;
    using Microsoft.Dpe.Ecf.Model;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    [DeploymentItem(@"Resources\ConvertHelperFixture", "ConvertHelperFixture")]
    public class ConvertHelperFixture
    {
        [TestMethod]
        public void ShouldConvertToPdf()
        {
            ConvertibleDocument document = new ConvertibleDocument();

            document.ConversionType = ConversionType.Pdf;
            document.RelativePath = "ConvertHelperFixture\\Overview.docx";

            ConvertHelper.Convert(document);

            Assert.IsTrue(File.Exists("ConvertHelperFixture\\Overview.pdf"));
        }

        [TestMethod]
        public void ShouldConvertToHtmlAndSinglePage()
        {
            if (File.Exists("Overview.html\\html\\docSet_Overview.html"))
            {
                File.Delete("Overview.html\\html\\docSet_Overview.html");
            }

            if (File.Exists("Overview.html\\html\\docSet_Default.html"))
            {
                File.Delete("Overview.html\\html\\docSet_Default.html");
            }

            ConvertibleDocument document = new ConvertibleDocument();

            document.ConversionType = ConversionType.Html | ConversionType.HtmlSinglePage;
            document.RelativePath = "Overview.docx";

            ConvertHelper.Convert(document);

            Assert.IsTrue(File.Exists("Overview.html\\html\\docSet_Overview.html"));
            Assert.IsTrue(File.Exists("Overview.html\\html\\docSet_Default.html"));
        }

        [TestMethod]
        public void ShouldConvertToHtmlAndSinglePage2()
        {
            if (File.Exists("Lab.html\\html\\docSet_Overview.html"))
            {
                File.Delete("Lab.html\\html\\docSet_Overview.html");
            }

            if (File.Exists("Lab.html\\html\\docSet_Default.html"))
            {
                File.Delete("Lab.html\\html\\docSet_Default.html");
            }

            ConvertibleDocument document = new ConvertibleDocument();

            document.ConversionType = ConversionType.Html | ConversionType.HtmlSinglePage;
            document.RelativePath = "Lab.docx";
            var xsl = @"..\..\..\..\Tools\resources\HtmlConversion\xsl";

            ConvertHelper.Convert(document, xsl);

            Assert.IsTrue(File.Exists("Lab.html\\html\\docSet_Lab.html"));
            Assert.IsTrue(File.Exists("Lab.html\\html\\docSet_Default.html"));
        }

        /// <summary>
        /// This test fragile because it is based on the count of temp files. 
        /// Becuase of this, it could fail if there is another process creating temp files while running the test.
        /// </summary>
        [TestMethod]
        public void ShouldDeleteTempFiles()
        {
            int initialTempFilesCount = CountTempFiles();

            if (File.Exists("Overview.html\\html\\docSet_Overview.html"))
            {
                File.Delete("Overview.html\\html\\docSet_Overview.html");
            }

            if (File.Exists("Overview.html\\html\\docSet_Default.html"))
            {
                File.Delete("Overview.html\\html\\docSet_Default.html");
            }

            ConvertibleDocument document = new ConvertibleDocument();

            document.ConversionType = ConversionType.Html | ConversionType.HtmlSinglePage;
            document.RelativePath = "Overview.docx";

            ConvertHelper.Convert(document, null, new DocToolsConfig("Overview", "Some feedback"));

            Assert.IsTrue(File.Exists("Overview.html\\html\\docSet_Overview.html"));
            Assert.IsTrue(File.Exists("Overview.html\\html\\docSet_Default.html"));

            Assert.AreEqual(initialTempFilesCount, CountTempFiles());
        }

        private static int CountTempFiles()
        {
            var files = Directory.GetFiles(Path.GetTempPath(), "tmp*.tmp");
            return files.Length;
        }
    }
}