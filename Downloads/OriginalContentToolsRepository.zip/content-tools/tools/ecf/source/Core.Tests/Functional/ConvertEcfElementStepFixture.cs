﻿namespace Microsoft.Dpe.Ecf.Core.Tests.Functional
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class ConvertEcfElementStepFixture
    {
        ////[TestMethod]
        ////public void ShouldConvertToPDF()
        ////{
        ////    var pkg = @"C:\OutputWP7c\temp\WP7TrainingCourse\PackageMSDN.xml";
        ////    var xsl = @"C:\ironwood-v3\managed\development\current\ECF\Tools\resources\MsdnConversion\xsl";
        ////    var conv = @"PDF";

        ////    var step = new ConvertEcfElementStep<Package>(pkg, xsl, true, conv);

        ////    step.Execute();
        ////}

        ////[TestMethod]
        ////public void ShouldConvertToHTML()
        ////{
        ////    var pkg = "Package\\package2.xml";
        ////    var xsl = @"..\..\..\..\Tools\resources\HtmlConversion\xsl";
        ////    var conv = @"HTML";

        ////    var step = new ConvertEcfElementStep<Package>(pkg, xsl, true, conv);

        ////    step.Execute();
        ////}
    }
}
