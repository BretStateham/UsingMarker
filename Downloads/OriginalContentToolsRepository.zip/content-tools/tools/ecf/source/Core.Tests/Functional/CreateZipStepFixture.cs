﻿namespace Microsoft.Dpe.Ecf.Core.Tests.Functional
{
    using System.IO;
    using Microsoft.Dpe.Ecf.Common.Helpers;
    using Microsoft.Dpe.Ecf.Core.Steps;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class CreateZipStepFixture
    {
        [TestMethod]
        public void ShouldZip()
        {
            string folderToZip = @"Content\Samples\SampleTest";
            string outputFolder = "outputFolderForTestingZip";
            string zipName = Path.Combine(outputFolder, "MyTesting.assetes1.zip");

            CreateZipStep step = new CreateZipStep();
            step.FolderToZip = folderToZip;            
            step.ZipFileName = zipName;

            step.Execute();

            Assert.IsTrue(Directory.Exists(outputFolder));
            Assert.IsTrue(File.Exists(zipName));

            // Delete created resources
            Directory.Delete(outputFolder, true);
        }     
   
        [TestMethod]
        public void ShouldZipWithExcludes()
        {
            string folderToZip = @"Content\Samples\SampleTest";
            string outputFolder = "outputFolderForTestingZip";
            string zipName = Path.Combine(outputFolder, "MyTesting.assetes1.zip");

            CreateZipStep step = new CreateZipStep();
            step.FolderToZip = folderToZip;
            step.ExcludeFile = "exclude.txt";          
            step.ZipFileName = zipName;

            step.Execute();

            Assert.IsTrue(Directory.Exists(outputFolder));
            Assert.IsTrue(File.Exists(zipName));

            // unzip
            ZipHelper.Unzip(zipName, outputFolder);

            Assert.IsFalse(Directory.Exists(Path.Combine(outputFolder, ".svn")));
            Assert.IsFalse(File.Exists(Path.Combine(outputFolder, "Comments.txt")));
            Assert.IsFalse(File.Exists(Path.Combine(outputFolder, "Sample.xml")));

            // Delete created resources
            Directory.Delete(outputFolder, true);
        }     
    }
}
