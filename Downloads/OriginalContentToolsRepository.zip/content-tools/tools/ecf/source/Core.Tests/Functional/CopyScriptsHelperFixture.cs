﻿namespace Microsoft.Dpe.Ecf.Core.Tests.Functional
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class CopyScriptsHelperFixture
    {
        [TestMethod]
        public void ShouldCopyScriptsToECFCache()
        {
        }

        [TestMethod]
        public void ShouldCopyScriptsToPackage()
        {
        }

        [TestMethod]
        public void ShouldCopyUpdateScriptsFromECFCache()
        {
        }
    }
}
