﻿namespace Microsoft.Dpe.Ecf.Core.Tests.Functional
{
    using System.IO;
    using Microsoft.Dpe.Ecf.Common;
    using Microsoft.Dpe.Ecf.Core.Helpers;
    using Microsoft.Dpe.Ecf.Core.Steps;
    using Microsoft.Dpe.Ecf.Model;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    [DeploymentItem(@"Resources\CopyPackageStepFixture", "CopyPackageStepFixture")]
    public class CopyPackageStepFixture
    {
        private static readonly string TestWorkingDirectory = Path.GetFullPath("CopyPackageStepFixture\\temp");

        [TestInitialize]
        public void TestInitialize()
        {
            if (Directory.Exists(TestWorkingDirectory))
            {
                Directory.Delete(TestWorkingDirectory, true);
            }
        }

        [TestMethod]
        public void ShouldCreateDirectories()
        {
            string packageFile = Path.GetFullPath("CopyPackageStepFixture\\Packages\\ShouldCreateDirectories_Package.xml");
            var helper = new MetadataHelper();
            var package = helper.ReadMetadata(packageFile);

            CopyPackageStep step = new CopyPackageStep
            {
                Metadata = package,
                ProcessDirectory = TestWorkingDirectory,
            };
            step.Execute();

            string packageDir = Path.Combine(step.ProcessDirectory, package.Id);
            string labsDir = Path.Combine(step.ProcessDirectory, package.Id + @"\Labs");
            string presentationsDir = Path.Combine(step.ProcessDirectory, package.Id + @"\Presentations");
            string demosDir = Path.Combine(step.ProcessDirectory, package.Id + @"\Demos");
            string samplesDir = Path.Combine(step.ProcessDirectory, package.Id + @"\Samples");
            string videosDir = Path.Combine(step.ProcessDirectory, package.Id + @"\Videos");
            string whitepapersDir = Path.Combine(step.ProcessDirectory, package.Id + @"\WhitePapers");

            Assert.IsTrue(Directory.Exists(labsDir));
            Assert.IsTrue(Directory.Exists(presentationsDir));
            Assert.IsTrue(Directory.Exists(demosDir));
            Assert.IsTrue(Directory.Exists(samplesDir));
            Assert.IsTrue(Directory.Exists(videosDir));
            Assert.IsTrue(Directory.Exists(whitepapersDir));

            Assert.IsTrue(File.Exists(Path.Combine(packageDir, "ShouldCreateDirectories_Package.xml")));
            Assert.IsTrue(File.Exists(Path.Combine(packageDir, "Overview.docx")));
            Assert.IsFalse(File.Exists(Path.Combine(packageDir, "Dummy.txt")));
            Assert.IsFalse(Directory.Exists(Path.Combine(packageDir, "DummyDir")));

            foreach (Unit unit in package.Units)
            {
                foreach (Lab lab in unit.Labs)
                {
                    string labDir = Path.Combine(labsDir, lab.OriginalName);
                    Assert.IsTrue(Directory.Exists(labDir));
                }

                foreach (Demo demo in unit.Demos)
                {
                    string demoDir = Path.Combine(demosDir, demo.OriginalName);
                    Assert.IsTrue(Directory.Exists(demoDir));
                }

                foreach (Sample sample in unit.Samples)
                {
                    string sampleDir = Path.Combine(samplesDir, sample.OriginalName);
                    Assert.IsTrue(Directory.Exists(sampleDir));
                }

                foreach (Presentation presentation in unit.Presentations)
                {
                    string presentationDir = Path.Combine(presentationsDir, presentation.OriginalName);
                    Assert.IsTrue(Directory.Exists(presentationDir));
                }

                foreach (Video video in unit.Videos)
                {
                    string videoDir = Path.Combine(videosDir, video.OriginalName);
                    Assert.IsTrue(Directory.Exists(videoDir));
                }

                foreach (Whitepaper whitepaper in unit.Whitepapers)
                {
                    string whitepaperDir = Path.Combine(whitepapersDir, whitepaper.OriginalName);
                    Assert.IsTrue(Directory.Exists(whitepaperDir));
                }
            }
        }

        [TestMethod]
        public void ShouldCopyPackageToWorkingDirectory()
        {
            string packageFile = Path.GetFullPath("CopyPackageStepFixture\\Packages\\ShouldCopyPackageToWorkingDirectory_Package.xml");
            var helper = new MetadataHelper();
            var package = helper.ReadMetadata(packageFile);

            CopyPackageStep step = new CopyPackageStep
            {
                Metadata = package,
                ProcessDirectory = TestWorkingDirectory,
            };
            step.Execute();

            Assert.IsTrue(File.Exists(Path.Combine(step.ProcessDirectory, "TestTrainingKit\\ShouldCopyPackageToWorkingDirectory_Package.xml")));
        }

        [TestMethod]
        public void ShouldCopyAssetsToWorkingDirectory()
        {
            string packageFile = Path.GetFullPath("CopyPackageStepFixture\\Packages\\ShouldCopyAssetsToWorkingDirectory_Package.xml");
            var helper = new MetadataHelper();
            var package = helper.ReadMetadata(packageFile);

            CopyPackageStep step = new CopyPackageStep
            {
                Metadata = package,
                Excludes = new string[] { ".svn", "*.obj", "excludeBin" },
                ProcessDirectory = TestWorkingDirectory,
                AssetDirectories = Path.GetFullPath("CopyPackageStepFixture\\Assets1")
            };
            step.Execute();

            string assetsDirectory = Path.Combine(step.ProcessDirectory, "TestTrainingKit\\Assets");
            string asset1File = Path.Combine(assetsDirectory, "TextAsset1.txt");
            string asset1bFile = Path.Combine(assetsDirectory, "Dir1\\TextAsset1b.txt");
            string assetExlucededFile1 = Path.Combine(assetsDirectory, "Dir1\\toBeExcluded.obj");
            string assetExlucededFile2 = Path.Combine(assetsDirectory, "Dir1\\excludeBin\\toBeExcluded.txt");
            string assetExlucededDir = Path.Combine(assetsDirectory, "Dir1\\excludeBin");

            // Check that step copied files
            Assert.IsTrue(Directory.Exists(assetsDirectory));
            Assert.IsTrue(File.Exists(asset1File));
            Assert.IsTrue(File.Exists(asset1bFile));

            // Check that step exluded files
            Assert.IsFalse(File.Exists(assetExlucededFile1));
            Assert.IsFalse(File.Exists(assetExlucededFile2));
            Assert.IsFalse(Directory.Exists(assetExlucededDir));
        }

        [TestMethod]
        public void ShouldCopyMultipleAssetsToWorkingDirectory()
        {
            string packageFile = Path.GetFullPath("CopyPackageStepFixture\\Packages\\ShouldCopyMultipleAssetsToWorkingDirectory_Package.xml");
            var helper = new MetadataHelper();
            var package = helper.ReadMetadata(packageFile);

            CopyPackageStep step = new CopyPackageStep
            {
                Metadata = package,
                Excludes = new string[] { ".svn", "*.obj", "excludeBin" },
                ProcessDirectory = TestWorkingDirectory,
                AssetDirectories = Path.GetFullPath("CopyPackageStepFixture\\Assets1") + ";" + Path.GetFullPath("CopyPackageStepFixture\\Assets2")
            };
            step.Execute();

            string assetsDirectory = Path.Combine(step.ProcessDirectory, "CopyPackageStepFixture\\TestTrainingKit\\Assets1");
            string asset1File = Path.Combine(assetsDirectory, "CopyPackageStepFixture\\TextAsset1.txt");
            string asset1bFile = Path.Combine(assetsDirectory, "CopyPackageStepFixture\\Dir1\\TextAsset1b.txt");

            string assetsDirectory2 = Path.Combine(step.ProcessDirectory, "CopyPackageStepFixture\\TestTrainingKit\\Assets2");
            string asset1File2 = Path.Combine(assetsDirectory, "TextAsset2.txt");
            string asset1bFile2 = Path.Combine(assetsDirectory, "Dir2\\TextAsset2b.txt");

            Assert.IsTrue(Directory.Exists(assetsDirectory));
            Assert.IsTrue(File.Exists(asset1File));
            Assert.IsTrue(File.Exists(asset1bFile));

            Assert.IsTrue(Directory.Exists(assetsDirectory2));
            Assert.IsTrue(File.Exists(asset1File2));
            Assert.IsTrue(File.Exists(asset1bFile2));
        }

        [TestMethod]
        public void ShouldExcludeFiles()
        {
            string packageFile = Path.GetFullPath("CopyPackageStepFixture\\Packages\\ShouldExcludeFiles_Package.xml");
            var helper = new MetadataHelper();
            var package = helper.ReadMetadata(packageFile);

            CopyPackageStep step = new CopyPackageStep
            {
                Metadata = package,
                Excludes = new string[] { ".svn", "*.obj", "excludeBin" },
                ProcessDirectory = TestWorkingDirectory,
            };
            step.Execute();

            Assert.IsTrue(Directory.Exists(step.ProcessDirectory));
            Assert.IsFalse(File.Exists(Path.Combine(step.ProcessDirectory, "TestTrainingKit\\Demos\\TestDemo\\Source\\toBeExcluded.obj")));
            Assert.IsTrue(File.Exists(Path.Combine(step.ProcessDirectory, "TestTrainingKit\\Demos\\TestDemo\\Source\\Dummy.txt")));
            Assert.IsFalse(File.Exists(Path.Combine(step.ProcessDirectory, "TestTrainingKit\\Labs\\TestLab\\Source\\toBeExcluded.obj")));
            Assert.IsTrue(File.Exists(Path.Combine(step.ProcessDirectory, "TestTrainingKit\\Labs\\TestLab\\Source\\Dummy.txt")));
        }

        [TestMethod]
        public void ShouldRemoveReadonlyAttributesInOverviewFile()
        {
            FileInfo fileInfo;
            string sourceFile = Path.GetFullPath("CopyPackageStepFixture\\Packages\\Overview.docx");

            /// Set the file attribute to readonly
            fileInfo = new FileInfo(sourceFile);
            fileInfo.IsReadOnly = true;

            string packageFile = Path.GetFullPath("CopyPackageStepFixture\\Packages\\ShouldRemoveReadonlyAttributesInOverviewFile_Package.xml");
            var helper = new MetadataHelper();
            var package = helper.ReadMetadata(packageFile);

            CopyPackageStep step = new CopyPackageStep
            {
                Metadata = package,
                ProcessDirectory = TestWorkingDirectory,
            };
            step.Execute();

            string targetFile = Path.Combine(step.ProcessDirectory, "TestTrainingKit\\Overview.docx");
            fileInfo = new FileInfo(targetFile);

            Assert.IsFalse(fileInfo.IsReadOnly);
        }

        [TestMethod]
        [ExpectedException(typeof(ContentFrameworkException))]
        public void ShouldFailWhenOverviewNotExists()
        {
            string packageFile = Path.GetFullPath("CopyPackageStepFixture\\Packages\\ShouldFailWhenOverviewNotExists_Package.xml");
            var helper = new MetadataHelper();
            var package = helper.ReadMetadata(packageFile);

            CopyPackageStep step = new CopyPackageStep
            {
                Metadata = package,
                ProcessDirectory = TestWorkingDirectory,
            };
            step.Execute();
        }

        [TestMethod]
        [Ignore]
        public void DevelopmentTest_IgnoreAlways()
        {
            string packageFile = Path.GetFullPath(@"C:\temp\BSDashboard\Packages\IdentityTK Long Long Long Long Long Long Long Long Long Long Long Long Long Long Long Long Long Long Long Long Long Long Long Long Long Long Long Long Long Long Long Long Long\Package.xml");
            var helper = new MetadataHelper();
            var package = helper.ReadMetadata(packageFile);

            CopyPackageStep step = new CopyPackageStep
            {
                Metadata = package,
                ProcessDirectory = @"C:\Output",
                ExcludeDependencyChecker = false,
                DependencyCheckerInScriptFolder = true,
            };

            step.Execute();
        }
    }
}