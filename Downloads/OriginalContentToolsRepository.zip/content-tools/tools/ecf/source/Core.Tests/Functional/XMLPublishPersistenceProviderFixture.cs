﻿namespace Microsoft.Dpe.Ecf.Core.Tests.Functional
{
    using System;
    using System.Collections.ObjectModel;
    using System.IO;
    using Microsoft.Dpe.Ecf.Core.Providers;
    using Microsoft.Dpe.Ecf.Model;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class XMLPublishPersistenceProviderFixture
    {
        [TestMethod]
        public void ShouldAddPostsToPersistedPosts()
        {
            Lab lab1 = new Lab() { Id = "EcfElementId1" };
            Lab lab2 = new Lab() { Id = "EcfElementId2" };
            PublishedElementsDictionaryKey key1 = new PublishedElementsDictionaryKey(lab1);
            PublishedElementsDictionaryKey key2 = new PublishedElementsDictionaryKey(lab2);
            string persitsFile = "publishedPostsTest.xml";
            XmlPublishPersistenceProvider persitenceProvider = new XmlPublishPersistenceProvider();
            persitenceProvider.PersistElementPosts(persitsFile, lab1, this.BuildMockPublishedPosts(), "http://www.test1.com/", "MyUser");

            IPublishedElementsDictionary originalPublishedPosts = persitenceProvider.GetPersistedElementPosts(persitsFile);

            Assert.AreEqual(1, originalPublishedPosts.Keys.Count);
            Assert.AreEqual(4, originalPublishedPosts[key1].Count);

            // add new post to a element
            Collection<PublishedPost> newPosts = this.BuildNewMockPublishedPosts();
            persitenceProvider.PersistElementPosts(persitsFile, lab2, newPosts, "http://www.test1.com/", "MyUser");

            // read new
            IPublishedElementsDictionary newPublishedPosts = persitenceProvider.GetPersistedElementPosts(persitsFile);
            Assert.AreEqual(2, newPublishedPosts.Keys.Count);
            Assert.AreEqual(3, newPublishedPosts[key2].Count);

            // Add posts to an already existing Element 
            persitenceProvider.PersistElementPosts(persitsFile, lab1, newPosts, "http://www.test1.com/", "MyUser");
            newPublishedPosts = persitenceProvider.GetPersistedElementPosts(persitsFile);
            Assert.AreEqual(2, newPublishedPosts.Keys.Count);
            Assert.AreEqual(3, newPublishedPosts[key1].Count);
            Assert.AreEqual(3, newPublishedPosts[key1].Count);

            // Delete created File
            File.Delete(persitsFile);
        }

        private Collection<PublishedPost> BuildNewMockPublishedPosts()
        {
            return new Collection<PublishedPost>() 
            {
                new PublishedPost("NewpostId1", new Uri("http://www.test1.com/New"), "New Title 1", false),
                new PublishedPost("NewpostId2", new Uri("http://www.test2.com/New"), "New Title 2", false),
                new PublishedPost("NewpostId3", new Uri("http://www.test3.com/New"), "New Title 3", false)                
            };
        }

        private Collection<PublishedPost> BuildMockPublishedPosts()
        {
            return new Collection<PublishedPost>() 
            {
                new PublishedPost("postId1", new Uri("http://www.test1.com"), "Title 1", false),
                new PublishedPost("postId2", new Uri("http://www.test2.com"), "Title 2", false),
                new PublishedPost("postId3", new Uri("http://www.test3.com"), "Title 3", false),
                new PublishedPost("postId4", new Uri("http://www.test4.com"), "Title 4", false)
            };
        }
    }
}
