﻿namespace Microsoft.Dpe.Ecf.Core.Tests.Functional
{
    using System.Collections.Generic;
    using System.IO;
    using Microsoft.Dpe.Ecf.Core.Helpers;
    using Microsoft.Dpe.Ecf.Core.Steps;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    [DeploymentItem(@"Resources\SiteTemplates", "SiteTemplates")]
    [DeploymentItem(@"Resources\CreateNavigationSiteStepFixture", "CreateNavigationSiteStepFixture")]
    public class CreateNavigationSiteStepFixture
    {
        [TestMethod]        
        public void ShouldCreateNavigationPages()
        {
            CreateNavigationSiteStep step = new CreateNavigationSiteStep();

            step.TemplatesDirectory = Path.GetFullPath("SiteTemplates");
            step.TemplateProperties = new Dictionary<string, object> { { "AssetsBaseAddress", string.Empty } };
            MetadataHelper helper = new MetadataHelper();
            step.Package = helper.ReadMetadataFromWorkingDirectory(Path.GetFullPath("CreateNavigationSiteStepFixture\\Package.xml"));
            step.PackagePath = Path.GetFullPath("CreateNavigationSiteStepFixture");
            step.IncludeTemplates = new string[] { "*.include.tt", "*.include.t4" };

            step.Execute();

            // Test the creation of the navigation pages
            Assert.IsTrue(File.Exists("CreateNavigationSiteStepFixture\\Labs.htm"));
            Assert.IsTrue(File.Exists("CreateNavigationSiteStepFixture\\SubFolder\\Demos.htm"));

            // Test existence of images and css directories
            Directory.Exists(Path.Combine(step.PackagePath, "CSS"));
            Directory.Exists(Path.Combine(step.PackagePath, "Images"));

            // Test inexistence of the template files in the Package directory
            Assert.IsTrue(!File.Exists("CreateNavigationSiteStepFixture\\Labs.tt"));
            Assert.IsTrue(!File.Exists("CreateNavigationSiteStepFixture\\SubDir\\Demos.tt"));
        }
    }
}