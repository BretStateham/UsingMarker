﻿namespace Microsoft.Dpe.Ecf.Core.Tests.Functional
{
    using System.IO;
    using System.Text;
    using Microsoft.Dpe.Ecf.Core.Helpers;
    using Microsoft.Dpe.Ecf.Core.Models;
    using Microsoft.Dpe.Ecf.Core.Steps;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    [DeploymentItem(@"Resources\CreateSelfExtractStepFixture", "CreateSelfExtractStepFixture")]
    [DeploymentItem(@"Resources\Tools", "Tools")]
    public class CreateSelfExtractStepFixture
    {
        [TestMethod]
        public void ShouldCreateSelfExtractPackage()
        {
            CopyPackageStep beginStep = new CopyPackageStep();

            string packageFile = Path.GetFullPath("CreateSelfExtractStepFixture\\Package\\Package.xml");

            // beginStep.PackageFile = Path.GetFullPath(packageFile);
            beginStep.Metadata = new MetadataHelper().ReadMetadata(packageFile);
            beginStep.ProcessDirectory = Path.GetFullPath("CreateSelfExtractStepFixture\\Temporal");

            beginStep.Excludes = new string[] { ".svn", "obj", "bin" };

            beginStep.Execute();

            var step = new CreateSelfExtractStep();

            step.Metadata = new SelfExtractMetadata()
            {
                LicenseAgreementFile = Path.GetFullPath("CreateSelfExtractStepFixture\\LicenseAgreement.txt"),
                ExcludeFiles = Path.GetFullPath("CreateSelfExtractStepFixture\\exclude.txt"),
                ImageFile = Path.GetFullPath("CreateSelfExtractStepFixture\\vertical.bmp"),
                Name = "Little_Pack",
                OutputDirectory = Path.GetFullPath("CreateSelfExtractStepFixture\\Output"),
                FolderToCompress = Path.GetDirectoryName("CreateSelfExtractStepFixture\\Package\\Package.xml")
            };

            step.Execute();

            Assert.IsTrue(File.Exists("CreateSelfExtractStepFixture\\Output\\Little_Pack.exe"));
        }

        [TestMethod]
        public void ShouldCreateSelfExtractFolder()
        {
            // Create exe
            var step = new CreateSelfExtractStep();

            step.Metadata = new SelfExtractMetadata()
            {
                LicenseAgreementFile = Path.GetFullPath("CreateSelfExtractStepFixture\\LicenseAgreement.txt"),
                ExcludeFiles = Path.GetFullPath("CreateSelfExtractStepFixture\\exclude.txt"),
                ImageFile = Path.GetFullPath("CreateSelfExtractStepFixture\\vertical.bmp"),
                Name = "Little_Pack",
                OutputDirectory = Path.GetFullPath("CreateSelfExtractStepFixture\\Output"),
                FolderToCompress = "CreateSelfExtractStepFixture\\Package"
            };

            step.Execute();

            Assert.IsTrue(File.Exists("CreateSelfExtractStepFixture\\Output\\Little_Pack.exe"));
        }

        [TestMethod]
        public void ShouldCreateSelfExtractSample()
        {
            // Create exe
            var step = new CreateSelfExtractStep();

            step.Metadata = new SelfExtractMetadata()
            {
                LicenseAgreementFile = Path.GetFullPath("CreateSelfExtractStepFixture\\LicenseAgreement.txt"),
                ExcludeFiles = Path.GetFullPath("CreateSelfExtractStepFixture\\exclude.txt"),
                ImageFile = Path.GetFullPath("CreateSelfExtractStepFixture\\vertical.bmp"),
                Name = "Little_Pack",
                OutputDirectory = Path.GetFullPath("CreateSelfExtractStepFixture\\Output"),
                FolderToCompress = Path.GetDirectoryName(@"CreateSelfExtractStepFixture\\Package\Package.xml")
            };

            step.Execute();

            Assert.IsTrue(File.Exists("CreateSelfExtractStepFixture\\Output\\Little_Pack.exe"));
        }

        [TestMethod]
        [Ignore]
        public void ShouldCreateCommentsFile()
        {
            CopyPackageStep beginStep = new CopyPackageStep();

            string packageFile = Path.GetFullPath("Package\\Package.xml");

            // beginStep.PackageFile = Path.GetFullPath(packageFile);
            beginStep.Metadata = new MetadataHelper().ReadMetadata(packageFile);
            beginStep.ProcessDirectory = Path.GetFullPath("Temp");

            beginStep.Excludes = new string[] { ".svn", "obj", "bin" };

            beginStep.Execute();

            var step = new CreateSelfExtractStep();

            step.Metadata = new SelfExtractMetadata()
            {
                LicenseAgreementFile = Path.GetFullPath("LicenseAgreement.txt"),
                ExcludeFiles = Path.GetFullPath("exclude.txt"),
                ImageFile = Path.GetFullPath("vertical.bmp"),
                Name = "Little_Pack",
                OutputDirectory = Path.GetFullPath("Output"),
            };

            step.Execute();

            string commentsPath = "Temporal\\VS10TrainingKit\\Comments.txt";
            Assert.IsTrue(File.Exists(commentsPath));
            string license = File.ReadAllText("LicenseAgreement.txt", Encoding.Default);
            string comments = File.ReadAllText(commentsPath, Encoding.Default);

            Assert.IsTrue(comments.Contains(license));
        }

        [TestMethod]        
        [Ignore]
        public void ShouldCreateSelfExtractPackageWithPages()
        {
            CopyPackageStep beginStep = new CopyPackageStep();

            string packageFile = Path.GetFullPath("Package\\Package.xml");

            // beginStep.PackageFile = Path.GetFullPath(packageFile);
            beginStep.Metadata = new MetadataHelper().ReadMetadata(packageFile);
            beginStep.ProcessDirectory = Path.GetFullPath("T");

            beginStep.Excludes = new string[] { ".svn", "obj", "bin" };

            beginStep.Execute();

            CreateNavigationSiteStep navStep = new CreateNavigationSiteStep();

            navStep.TemplatesDirectory = Path.GetFullPath("Templates");
            MetadataHelper helper = new MetadataHelper();
            navStep.Package = helper.ReadMetadataFromWorkingDirectory(Path.GetFullPath("T\\VS10TrainingKit\\Package.xml"));
            navStep.PackagePath = Path.GetFullPath("T\\VS10TrainingKit");

            navStep.Execute();

            var step = new CreateSelfExtractStep();

            step.Metadata = new SelfExtractMetadata()
            {
                LicenseAgreementFile = Path.GetFullPath("LicenseAgreement.txt"),
                ExcludeFiles = Path.GetFullPath("exclude.txt"),
                ImageFile = Path.GetFullPath("vertical.bmp"),
                Name = "Little_Pack",
                OutputDirectory = Path.GetFullPath("Output"),
            };

            step.Execute();

            Assert.IsTrue(File.Exists("Output\\Little_Pack.exe"));
        }
    }
}
