﻿namespace Microsoft.Dpe.Ecf.Core.Tests.Functional
{
    using System.IO;
    using Microsoft.Dpe.Ecf.Core.Steps;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class RemoveSourceControlBindingsStepFixture
    {
        [TestMethod]
        public void ShouldRemoveTfsFiles()
        {                       
            string sourceDir = Path.GetFullPath("Content\\Demos\\HasTFSBindings\\Source\\HasTFSBindings");                        
            string destDir = Path.GetFullPath("t3");
            Directory.CreateDirectory(destDir);
            File.Copy(Path.Combine(sourceDir, "HasTFSBindings.csproj.vspscc"), Path.Combine(destDir, "HasTFSBindings.csproj.vspscc"), true);
            File.Copy(Path.Combine(sourceDir, "Form1.cs"), Path.Combine(destDir, "Form1.cs"), true);

            RemoveSourceControlBindingsStep step = new RemoveSourceControlBindingsStep();
            step.WorkingDirectory = destDir;

            step.Execute();

            Assert.IsTrue(Directory.Exists(destDir));
            Assert.IsFalse(File.Exists(Path.Combine(destDir, "HasTFSBindings.csproj.vspscc")));
            Assert.IsTrue(File.Exists(Path.Combine(destDir, "Form1.cs")));

            Directory.Delete(destDir, true);
        }

        [TestMethod]
        public void ShouldCleanSolutions()
        {
            string sourceDir = Path.GetFullPath("Content\\Demos\\HasTFSBindings\\Source");
            string destDir = Path.GetFullPath("t3");
            Directory.CreateDirectory(destDir);
            File.Copy(Path.Combine(sourceDir, "HasTFSBindings.sln"), Path.Combine(destDir, "HasTFSBindings.sln"), true);
            
            RemoveSourceControlBindingsStep step = new RemoveSourceControlBindingsStep();
            step.WorkingDirectory = destDir;

            step.Execute();

            Assert.IsTrue(Directory.Exists(destDir));
            Assert.IsTrue(File.Exists(Path.Combine(destDir, "HasTFSBindings.sln")));
            string content = File.ReadAllText(Path.Combine(destDir, "HasTFSBindings.sln"));
            Assert.IsFalse(content.Contains("GlobalSection(TeamFoundationVersionControl)"));                            

            Directory.Delete(destDir, true);
        }

        [TestMethod]
        public void ShouldCleanProjects()
        {
            string sourceDir = Path.GetFullPath("Content\\Demos\\HasTFSBindings\\Source\\HasTFSBindings");
            string destDir = Path.GetFullPath("t3");
            Directory.CreateDirectory(destDir);
            File.Copy(Path.Combine(sourceDir, "HasTFSBindings.csproj"), Path.Combine(destDir, "HasTFSBindings.csproj"), true);

            RemoveSourceControlBindingsStep step = new RemoveSourceControlBindingsStep();
            step.WorkingDirectory = destDir;

            step.Execute();

            Assert.IsTrue(Directory.Exists(destDir));
            Assert.IsTrue(File.Exists(Path.Combine(destDir, "HasTFSBindings.csproj")));
            string content = File.ReadAllText(Path.Combine(destDir, "HasTFSBindings.csproj"));
            Assert.IsFalse(content.Contains("<SccProjectName>"));
            Assert.IsTrue(content.Contains("<SccProjectName />"));    

            Directory.Delete(destDir, true);
        }
    }
}
