﻿namespace Microsoft.Dpe.Ecf.Core.Tests.Functional
{
    using Microsoft.Dpe.Ecf.Core.Helpers;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class PathsHelperFixture
    {
        [TestMethod]
        public void ShouldGetRelativePath()
        {
            var directory = "C:\\temp\\tks\\packages\\vs2010tk\\";
            var toPath = "C:\\temp\\tks\\packages\\vs2010tk\\assets\\resources\\file.txt";
            var expected = "assets\\resources\\file.txt";
            var result = PathsHelper.RelativePathTo(directory, toPath);

            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        public void ShouldGetRelativePath2()
        {
            var directory = "C:\\temp\\tks\\packages\\vs2010tk";
            var toPath = "C:\\temp\\tks\\assets\\resources\\file.txt";
            var expected = "..\\..\\assets\\resources\\file.txt";
            var result = PathsHelper.RelativePathTo(directory, toPath);

            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        public void ShouldGetRelativePath3()
        {
            var directory = "C:\\temp\\tks\\packages\\vs2010tk\\";
            var toPath = "C:\\temp\\tks\\assets\\resources\\folder";
            var expected = "..\\..\\assets\\resources\\folder";
            var result = PathsHelper.RelativePathTo(directory, toPath);

            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        public void IsRootedShouldReturnTrue()
        {
            var path = "C:\\temp\\vs2010tk";

            Assert.IsTrue(PathsHelper.IsRootedPath(path));
        }

        [TestMethod]
        public void IsRootedShouldReturnFalse()
        {
            var path = "temp\\vs2010tk";

            Assert.IsFalse(PathsHelper.IsRootedPath(path));
        }

        [TestMethod]
        public void IsRootedShouldReturnFalse2()
        {
            var path = "\\temp\\vs2010tk";

            Assert.IsFalse(PathsHelper.IsRootedPath(path));
        }
    }
}
