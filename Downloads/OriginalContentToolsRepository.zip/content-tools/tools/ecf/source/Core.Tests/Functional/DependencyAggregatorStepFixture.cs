﻿namespace Microsoft.Dpe.Ecf.Core.Tests.Functional
{
    using System.IO;
    using System.Linq;
    using System.Xml.Linq;
    using Microsoft.Dpe.Ecf.Core.Steps;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    [DeploymentItem(@"Resources\DependencyAggregatorStepFixture", "DependencyAggregatorStepFixture")]
    public class DependencyAggregatorStepFixture
    {
        [TestMethod]
        public void Aggregate_ShouldCreateFolderForDependencyXmlFile()
        {
            var step = new DependencyAggregatorStep();
            step.SourceFolder = @"DependencyAggregatorStepFixture\SingleOs\SingleDependency";
            step.OutputPath = @"DependencyAggregatorStepFixture\InexistentFolder\SubFolder\Dependencies.xml";

            step.Execute();

            Assert.IsTrue(Directory.Exists(@"DependencyAggregatorStepFixture\InexistentFolder\SubFolder"));
            Assert.IsTrue(File.Exists(step.OutputPath));
        }

        [TestMethod]
        public void Execute_ShouldCreateEmptyDefaultTemplate_WhenNoDependenciesFoundInSource()
        {
            var step = new DependencyAggregatorStep();
            step.SourceFolder = @"DependencyAggregatorStepFixture\EmptyFolder";
            step.OutputPath = @"DependencyAggregatorStepFixture\Dependencies.xml";

            step.Execute();

            Assert.IsTrue(File.Exists(step.OutputPath));
            var doc = XDocument.Load(step.OutputPath);
            Assert.AreEqual(0, doc.Descendants("task").Count());
            Assert.AreEqual(0, doc.Descendants("dependency").Count());
        }

        [TestMethod]
        public void Execute_ShouldCreateSingleOsSingleDependency_WhenFoundInSingleFile()
        {
            var step = new DependencyAggregatorStep();
            step.SourceFolder = @"DependencyAggregatorStepFixture\SingleOs\SingleDependency";
            step.OutputPath = @"DependencyAggregatorStepFixture\Dependencies.xml";

            step.Execute();

            Assert.IsTrue(File.Exists(step.OutputPath));
            var doc = XDocument.Load(step.OutputPath);
            Assert.AreEqual(0, doc.Descendants("task").Count());
            Assert.AreEqual(1, doc.Descendants("os").Count());
            Assert.AreEqual(1, doc.Descendants("dependency").Count());
            Assert.AreEqual(1, doc.Descendants("dependency").Where(e => e.Attribute("title").Value.Equals("Microsoft Visual Studio 2010 Beta 2")).Count());
        }

        [TestMethod]
        public void Execute_ShouldCreateSingleOsTwoDependencies_WhenFoundInSingleFile()
        {
            var step = new DependencyAggregatorStep();
            step.SourceFolder = @"DependencyAggregatorStepFixture\SingleOs\TwoDependencies";
            step.OutputPath = @"DependencyAggregatorStepFixture\Dependencies.xml";

            step.Execute();

            Assert.IsTrue(File.Exists(step.OutputPath));
            var doc = XDocument.Load(step.OutputPath);
            Assert.AreEqual(0, doc.Descendants("task").Count());
            Assert.AreEqual(1, doc.Descendants("os").Count());
            Assert.AreEqual(2, doc.Descendants("dependency").Count());
            Assert.AreEqual(1, doc.Descendants("dependency").Where(e => e.Attribute("title").Value.Equals("Microsoft Visual Studio 2010 Beta 2")).Count());
            Assert.AreEqual(1, doc.Descendants("dependency").Where(e => e.Attribute("title").Value.Equals(".NET Framework 4.0")).Count());
        }

        [TestMethod]
        public void Execute_ShouldCreateTwoOsWithDependencies_WhenFoundInSingleFile()
        {
            var step = new DependencyAggregatorStep();
            step.SourceFolder = @"DependencyAggregatorStepFixture\TwoOs";
            step.OutputPath = @"DependencyAggregatorStepFixture\Dependencies.xml";

            step.Execute();

            Assert.IsTrue(File.Exists(step.OutputPath));
            var doc = XDocument.Load(step.OutputPath);
            Assert.AreEqual(0, doc.Descendants("task").Count());
            Assert.AreEqual(2, doc.Descendants("os").Count());
            Assert.AreEqual(3, doc.Descendants("dependency").Count());
        }

        [TestMethod]
        public void Execute_ShouldMergeSingleOsWithTwoDependencies_WhenFoundInDifferentFiles()
        {
            var step = new DependencyAggregatorStep();
            step.SourceFolder = @"DependencyAggregatorStepFixture\SingleOs";
            step.OutputPath = @"DependencyAggregatorStepFixture\Dependencies.xml";

            step.Execute();

            Assert.IsTrue(File.Exists(step.OutputPath));
            var doc = XDocument.Load(step.OutputPath);
            Assert.AreEqual(0, doc.Descendants("task").Count());
            Assert.AreEqual(1, doc.Descendants("os").Count());
            Assert.AreEqual(2, doc.Descendants("dependency").Count());
            Assert.AreEqual(1, doc.Descendants("dependency").Where(e => e.Attribute("title").Value.Equals("Microsoft Visual Studio 2010 Beta 2")).Count());
            Assert.AreEqual(1, doc.Descendants("dependency").Where(e => e.Attribute("title").Value.Equals(".NET Framework 4.0")).Count());
        }

        [TestMethod]
        public void Execute_ShouldCreateSingleTask_WhenFoundInSingleFile()
        {
            var step = new DependencyAggregatorStep();
            step.AggregateDeploymentTasks = true;
            step.SourceFolder = @"DependencyAggregatorStepFixture\Tasks\SingleTask";
            step.OutputPath = @"DependencyAggregatorStepFixture\Dependencies.xml";

            step.Execute();

            Assert.IsTrue(File.Exists(step.OutputPath));
            var doc = XDocument.Load(step.OutputPath);
            Assert.AreEqual(0, doc.Descendants("os").Count());
            Assert.AreEqual(0, doc.Descendants("dependency").Count());
            Assert.AreEqual(1, doc.Descendants("task").Count());
        }

        [TestMethod]
        public void Execute_ShouldMergeDifferentTasks_WhenFoundInDifferentFilesAndNotRepeatThem()
        {
            var step = new DependencyAggregatorStep();
            step.AggregateDeploymentTasks = true;
            step.SourceFolder = @"DependencyAggregatorStepFixture\Tasks";
            step.OutputPath = @"DependencyAggregatorStepFixture\Dependencies.xml";

            step.Execute();

            Assert.IsTrue(File.Exists(step.OutputPath));
            var doc = XDocument.Load(step.OutputPath);
            Assert.AreEqual(0, doc.Descendants("os").Count());
            Assert.AreEqual(0, doc.Descendants("dependency").Count());
            Assert.AreEqual(2, doc.Descendants("task").Count());
        }

        [TestMethod]
        public void Execute_ShouldMergeDifferentTasksAndRepeatTheLabSpecific_WhenFoundInDifferentFiles()
        {
            var labSpecificTask = "Launch the Visual Studio installer to install the code snippets";
            var step = new DependencyAggregatorStep();
            step.LabSpecificTasks = new string[] { labSpecificTask };
            step.AggregateDeploymentTasks = true;
            step.SourceFolder = @"DependencyAggregatorStepFixture\Tasks";
            step.OutputPath = @"DependencyAggregatorStepFixture\Dependencies.xml";

            step.Execute();

            Assert.IsTrue(File.Exists(step.OutputPath));
            var doc = XDocument.Load(step.OutputPath);
            Assert.AreEqual(0, doc.Descendants("os").Count());
            Assert.AreEqual(0, doc.Descendants("dependency").Count());
            Assert.AreEqual(3, doc.Descendants("task").Count());
            Assert.AreEqual(2, doc.Descendants("task").Where(t => t.Attribute("description").Value.Equals(labSpecificTask)).Count());
        }

        [TestMethod]
        public void Execute_ShouldUpdateDependencyPath_WhenUpdateScriptPathIsSet()
        {
            var step = new DependencyAggregatorStep();
            step.UpdateScriptToAbsolutePath = true;
            step.SourceFolder = @"DependencyAggregatorStepFixture\SingleOs\SingleDependency";
            step.OutputPath = @"DependencyAggregatorStepFixture\Dependencies.xml";

            var dependencyFolder = Path.GetFullPath(step.SourceFolder);
            var expectedScriptPath = Path.Combine(dependencyFolder, @"scripts\Dependencies\Check\CheckVS2010Beta2.ps1");

            step.Execute();

            Assert.IsTrue(File.Exists(step.OutputPath));
            var doc = XDocument.Load(step.OutputPath);
            var dependency = doc.Descendants("dependency").First(e => e.Attribute("title").Value.Equals("Microsoft Visual Studio 2010 Beta 2"));
            Assert.AreEqual(expectedScriptPath, dependency.Attribute("value").Value);
        }

        [TestMethod]
        public void Execute_ShouldUpdateTaskPath_WhenUpdateScriptPathIsSet()
        {
            var step = new DependencyAggregatorStep();
            step.UpdateScriptToAbsolutePath = true;
            step.AggregateDeploymentTasks = true;
            step.SourceFolder = @"DependencyAggregatorStepFixture\Tasks\SingleTask";
            step.OutputPath = @"DependencyAggregatorStepFixture\Dependencies.xml";

            var dependencyFolder = Path.GetFullPath(step.SourceFolder);
            var expectedScriptPath = Path.Combine(dependencyFolder, @"scripts\tasks\installVSCodeSnippets.cmd");

            step.Execute();

            Assert.IsTrue(File.Exists(step.OutputPath));
            var doc = XDocument.Load(step.OutputPath);
            var dependency = doc.Descendants("task").First(e => e.Attribute("description").Value.Equals("Launch the Visual Studio installer to install the code snippets"));
            Assert.AreEqual(expectedScriptPath, dependency.Attribute("scriptName").Value);
        }
    }
}
