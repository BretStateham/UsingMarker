﻿namespace Microsoft.Dpe.Ecf.Core.Tests.Mocks
{
    using System;
    using Microsoft.Dpe.Ecf.Core.Steps;

    public class MockAddCopyrightHeaderStep : AddCopyrightHeaderStep
    {
        public MockAddCopyrightHeaderStep()
        {
            this.IsReadCopyrightFileCalled = false;
            this.IsApplyHeaderToFileCalled = false;
        }

        public bool IsReadCopyrightFileCalled
        {
            get;
            set;
        }

        public bool IsApplyHeaderToFileCalled
        {
            get;
            set;
        }

        protected override string ReadCopyrightFile(string path)
        {
            this.IsReadCopyrightFileCalled = true;
            return String.Empty;
        }

        protected override void ApplyHeaderToFile(string header, string file)
        {
            this.IsApplyHeaderToFileCalled = true;
        }
    }
}
