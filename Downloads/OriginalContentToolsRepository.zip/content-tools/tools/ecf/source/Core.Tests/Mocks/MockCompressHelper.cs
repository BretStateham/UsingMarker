﻿namespace Microsoft.Dpe.Ecf.Core.Tests.Mocks
{
    using Microsoft.Dpe.Ecf.Core.Helpers;
    using Microsoft.Dpe.Ecf.Core.Models;

    public class MockCompressHelper : CompressHelper
    {
        public bool IsLoadToolCalled
        {
            get;
            set;
        }

        public bool IsGenerateSelfExtractCalled
        {
            get;
            set;
        }

        public override void LoadTool()
        {
            this.IsLoadToolCalled = true;
        }

        public override void GenerateSelfExtract(SelfExtractMetadata data)
        {
            this.IsGenerateSelfExtractCalled = true;
        }
    }
}
