﻿namespace Microsoft.Dpe.Ecf.Core.Tests.Mocks
{
    using Microsoft.Dpe.Ecf.Core.Steps;

    public class MockRemoveSourceControlBindingsStep : RemoveSourceControlBindingsStep
    {
        public bool IsDeleteTfsFilesCalled
        {
            get;
            set;
        }

        public bool IsCleanProjectsCalled
        {
            get;
            set;
        }

        public bool IsCleanSolutionsCalled
        {
            get;
            set;
        }

        protected override void DeleteSourceControlFiles()
        {
            this.IsDeleteTfsFilesCalled = true;
        }

        protected override void CleanProjects()
        {
            this.IsCleanProjectsCalled = true;
        }

        protected override void CleanSolutions()
        {
            this.IsCleanSolutionsCalled = true;
        }
    }
}
