﻿namespace Microsoft.Dpe.Ecf.Core.Tests.Mocks
{
    using System;
    using System.Configuration;

    public static class MockMetaWeblogData
    {
        private static string user;
        private static string pass;
        private static Uri url;
        private static bool isMock = true;

        public static string User
        {
            get
            {
                if (String.IsNullOrEmpty(user))
                {
                    user = ConfigurationManager.AppSettings["BlogEngineUser"];
                    if (String.IsNullOrEmpty(user))
                    {
                        // default value
                        user = "user";
                    }
                }

                return user;
            }
        }

        public static string Password
        {
            get
            {
                if (String.IsNullOrEmpty(pass))
                {
                    pass = ConfigurationManager.AppSettings["BlogEnginePassword"];
                    if (String.IsNullOrEmpty(pass))
                    {
                        // default value
                        pass = "pass";
                    }
                }

                return pass;
            }
        }

        public static Uri Url
        {
            get
            {
                if (url == null)
                {
                    string strUrl = ConfigurationManager.AppSettings["BlogEngineUrl"];
                    if (String.IsNullOrEmpty(strUrl))
                    {
                        // default value
                        url = new Uri("http://localhost:3233/blogger.aspx");
                    }
                    else
                    {
                        url = new Uri(strUrl);
                    }
                }

                return url;
            }
        }

        public static bool IsMockBlog
        {
            get
            {
                string mock = ConfigurationManager.AppSettings["IsMockBlog"];
                if (!String.IsNullOrEmpty(mock))
                {
                    if (!Boolean.TryParse(mock, out isMock))
                    {
                        isMock = false;
                    }
                }

                return isMock;
            }
        }
    }
}
