﻿namespace Microsoft.Dpe.Ecf.Core.Tests.Mocks
{
    using System.Linq;
    using Microsoft.Dpe.Ecf.Model;

    internal static class MockFactory
    {
        internal static Model.Unit CreateUnit()
        {
            Model.Unit unit = new Model.Unit()
            {
                Id = "pictureservices",
                Name = "Picture Services Sample",
                Overview = MockFactory.CreateOverview(),
                Description = "Picture Services is an amazing tool..."
            };

            unit.Presentations.Add(MockFactory.CreatePresentation());

            unit.Labs.Add(MockFactory.CreateLab());

            unit.Demos.Add(MockFactory.CreateDemo());

            unit.Links.Add(new Link("http://msdn.microsoft.com", "Microsoft Developers Network"));

            return unit;
        }

        /// <summary>
        /// Creates a Lab with the default document ".\Demos\ExportPoints\Docs\ExportPointsScript.docx"
        /// </summary>
        /// <returns></returns>
        internal static Demo CreateDemo()
        {
            return MockFactory.CreateDemo(@".\Demos\ExportPoints\Docs\ExportPointsScript.docx");
        }

        internal static Demo CreateDemo(string document)
        {
            return new Demo()
            {
                Title = "Export Points",
                Description = "Blah",
                Document = new ConvertibleDocument() { RelativePath = document },
                Source = @".\Demos\ExportPoints\Source",
                Version = "1.0.1",
                Author = MockFactory.CreateAuthor(),
            };
        }

        /// <summary>
        /// Creates a Lab with the default document ".\Labs\Digging\Docs\Digging.docx"
        /// </summary>
        /// <returns></returns>
        internal static Lab CreateLab()
        {
            return MockFactory.CreateLab(@".\Labs\Digging\Docs\Digging.docx");
        }

        internal static Lab CreateLab(string document)
        {
            return new Lab()
            {
                Title = "Digging into MEF",
                Description = "Blah",
                Document = new ConvertibleDocument() { RelativePath = document },
                Source = @".\Labs\Digging\Source",
                Version = "1.0.0",
                VirtualLab = "http://somewhere...",
                Author = MockFactory.CreateAuthor(),
            };
        }

        /// <summary>
        /// Creates a Presentation with the default document ".\Presentations\LapAroundMEF.pptx"
        /// </summary>
        /// <returns></returns>
        internal static Presentation CreatePresentation()
        {
            return MockFactory.CreatePresentation(@".\Presentations\LapAroundMEF.pptx");
        }

        internal static Presentation CreatePresentation(string document)
        {
            return new Presentation()
            {
                Author = MockFactory.CreateAuthor(),
                Description = "Blah",
                Document = new ConvertibleDocument() { RelativePath = document },
                Title = "Lap Around the Managed Extensibility Framework",
                Version = "1.0.0"
            };
        }

        /// <summary>
        /// Creates a Overview with the default document ".\Overview.docx"
        /// </summary>
        /// <returns></returns>
        internal static Overview CreateOverview()
        {
            return MockFactory.CreateOverview(@".\Overview.docx");
        }

        internal static Overview CreateOverview(string document)
        {
            return new Overview()
            {
                Title = "Title",
                Description = "description",
                Document = new ConvertibleDocument() { RelativePath = document },
                Version = "1.0",
                Author = MockFactory.CreateAuthor(),
            };
        }

        internal static Author CreateAuthor()
        {
            return new Author()
            {
                Name = "Jason Olson",
                Email = "jolson@microsoft.com",
                Blog = "http://www.managed-world.com"
            };
        }

        // TODO Review units are objects
        internal static Package CreatePackage(string[] units)
        {
            var package = new Package()
            {
                Name = "Package for Test",
                Id = "01",
                Description = "This is a mock package",
                Overview = MockFactory.CreateOverview(),
                Version = "May 11, Preview"
            };

            if (units != null)
            {
                foreach (var item in units)
                {
                    // add more properties to the unit mock
                    var unit = new Unit()
                    {
                        Name = item
                    };

                    package.Units.Add(unit);
                }
            }

            package.PrerequisitesGroups.Add(new PrerequisitesGroup() { Name = "Testing" });

            package.PrerequisitesGroups.First().Prerequisites.Add(new Prerequisite() { Name = "Windows Vista" });
            package.PrerequisitesGroups.First().Prerequisites.Add(new Prerequisite() { Name = "Microsoft WordPad" });

            return package;
        }
    }
}
