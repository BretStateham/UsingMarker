﻿namespace Microsoft.Dpe.Ecf.Core.Tests
{
    using System.CodeDom.Compiler;
    using System.Collections.Generic;
    using System.IO;
    using System.Text;
    using Microsoft.Dpe.Ecf.Core.Helpers;
    using Microsoft.Dpe.Ecf.Model;
    using Microsoft.Dpe.Ecf.TextTemplating;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class TextTemplatingHelperFixture
    {
        [TestMethod]
        public void ExecuteShouldCallProocessorExecuteForMultipleTemplates()
        {
            MockTemplateProcessor mockTemplateProcessor = new MockTemplateProcessor();
            var helper = new MockTextTemplatingHelper(mockTemplateProcessor);

            string templatesDirectory = Path.GetFullPath("SiteTemplates");

            helper.ProcessMultipleTemplates(templatesDirectory, null, string.Empty, null);

            Assert.IsTrue(mockTemplateProcessor.IsExecuteCalled);
        }

        [TestMethod]
        public void ExecuteShouldCallProcessorExecuteForSingleTemplate()
        {
            MockTemplateProcessor mockTemplateProcessor = new MockTemplateProcessor();
            var helper = new MockTextTemplatingHelper(mockTemplateProcessor);

            string templateFile = Path.GetFullPath("SiteTemplates\\Labs.tt");

            helper.ProcessSingleTemplate(templateFile, null);

            Assert.IsTrue(mockTemplateProcessor.IsExecuteCalled);
        }

        [TestMethod, ExpectedException(typeof(TextTemplatingException))]
        public void ExecuteShouldFailProcessingMultipleTemplates()
        {
            MockTemplateProcessor mockTemplateProcessor = new MockTemplateProcessor();
            mockTemplateProcessor.GenerateCompilationError = true;
            var helper = new MockTextTemplatingHelper(mockTemplateProcessor);

            string templatesDirectory = Path.GetFullPath("SiteTemplates");

            helper.ProcessMultipleTemplates(templatesDirectory, null, string.Empty, null);
        }

        [TestMethod, ExpectedException(typeof(TextTemplatingException))]
        public void ExecuteShouldFailProcessingSingleTemplate()
        {
            MockTemplateProcessor mockTemplateProcessor = new MockTemplateProcessor();
            mockTemplateProcessor.GenerateCompilationError = true;
            var helper = new MockTextTemplatingHelper(mockTemplateProcessor);

            string templateFile = Path.GetFullPath("SiteTemplates\\Labs.tt");

            helper.ProcessSingleTemplate(templateFile, null);
        }

        [TestMethod]
        public void VideoIncludeTemplateShouldNotFailIfAuthorMissing()
        {
            TextTemplatingHelper helper = new TextTemplatingHelper();
            string templateFile = Path.GetFullPath("SiteTemplates\\MainForVideoInclude.tt");
            var dic = new Dictionary<string, object>();
            dic["Package"] = new Package { Id = "id" };
            dic["AssetsBaseAddress"] = "AssetsBaseAddress";
            helper.ProcessSingleTemplate(templateFile, dic);
        }

        [TestMethod]
        public void LandingPageIncludeTemplateShouldOutputMessageIfVersionMissing()
        {
            TextTemplatingHelper helper = new TextTemplatingHelper();
            string templateFile = Path.GetFullPath("SiteTemplates\\MainForLandingPageInclude.tt");
            var dic = new Dictionary<string, object>();

            var package = new Package
            {
                Id = "id",
                Name = "PacakgeName",
                Description = "description",
                Location = Path.GetFullPath("SiteTemplates\\MainForLandingPageInclude.tt"),
                Version = "2.1",
                Overview = new Overview { }
            };

            dic["Package"] = package;
            dic["AssetsBaseAddress"] = "AssetsBaseAddress";
            helper.ProcessSingleTemplate(templateFile, dic);

            var outputFile = File.OpenText(Path.Combine(Path.GetDirectoryName(package.Location), "Default.htm"));
            bool result = outputFile.ReadToEnd().Contains("No version provided in metadata");
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void ExecuteShouldCallWritePage()
        {
            var helper = new MockTextTemplatingHelper(new MockTemplateProcessor());

            string templatesDirectory = Path.GetFullPath("SiteTemplates");

            helper.ProcessMultipleTemplates(templatesDirectory, null, string.Empty, null);

            Assert.IsTrue(helper.IsWriteContentPageCalled);
        }

        private class MockTextTemplatingHelper : TextTemplatingHelper
        {
            internal MockTextTemplatingHelper(SimpleTemplateProcessor templateProcessor)
                : base(templateProcessor)
            {
            }

            public bool IsWriteContentPageCalled
            {
                get;
                set;
            }

            protected override void WriteContentPage(string pagePath, string content)
            {
                this.IsWriteContentPageCalled = true;
            }
        }

        private class MockTemplateProcessor : SimpleTemplateProcessor
        {
            private CompilerErrorCollection errors;

            public bool IsExecuteCalled
            {
                get;
                set;
            }

            public bool GenerateCompilationError
            {
                get;
                set;
            }

            public override CompilerErrorCollection Errors
            {
                get
                {
                    return this.errors;
                }
            }

            public override string ErrorsString
            {
                get
                {
                    StringBuilder buffer = new StringBuilder();
                    foreach (CompilerError error in this.errors)
                    {
                        buffer.AppendLine(error.ToString());
                    }

                    return buffer.ToString();
                }
            }

            public override string Execute(Dictionary<string, object> properties, string templateFile)
            {
                this.IsExecuteCalled = true;

                this.errors = new CompilerErrorCollection();
                if (this.GenerateCompilationError)
                {
                    this.errors.Add(new CompilerError("InvalidTemplate", 1, 1, "001", "syntax error"));
                }

                return string.Empty;
            }
        }
    }
}
