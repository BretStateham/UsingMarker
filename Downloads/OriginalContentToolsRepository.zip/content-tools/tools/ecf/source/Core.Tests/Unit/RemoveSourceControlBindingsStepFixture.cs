﻿namespace Microsoft.Dpe.Ecf.Core.Tests
{
    using System.IO;
    using Microsoft.Dpe.Ecf.Core.Tests.Mocks;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class RemoveSourceControlBindingsStepFixture
    {
        [TestMethod]
        public void ExecuteShouldCallDeleteTfsFiles()
        {
            var mock = new MockRemoveSourceControlBindingsStep();

            mock.WorkingDirectory = Path.Combine(Directory.GetCurrentDirectory(), "Temp");
            mock.Execute();

            Assert.IsTrue(mock.IsDeleteTfsFilesCalled);
        }

        [TestMethod]
        public void ExecuteShouldCallCleanProjects()
        {
            var mock = new MockRemoveSourceControlBindingsStep();

            mock.WorkingDirectory = Path.Combine(Directory.GetCurrentDirectory(), "Temp");
            mock.Execute();

            Assert.IsTrue(mock.IsCleanProjectsCalled);
        }

        [TestMethod]
        public void ExecuteShouldCallCleanSolutions()
        {
            var mock = new MockRemoveSourceControlBindingsStep();

            mock.WorkingDirectory = Path.Combine(Directory.GetCurrentDirectory(), "Temp");
            mock.Execute();

            Assert.IsTrue(mock.IsCleanSolutionsCalled);
        }
    }
}
