﻿namespace Microsoft.Dpe.Ecf.Core.Tests
{
    using System;
    using System.IO;
    using Microsoft.Dpe.Ecf.Core.Helpers;
    using Microsoft.Dpe.Ecf.Core.Models;
    using Microsoft.Dpe.Ecf.Core.Steps;
    using Microsoft.Dpe.Ecf.Model;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;

    [TestClass]
    [DeploymentItem(@"Resources\CreateSelfExtractFixture", "CreateSelfExtractFixture")]
    public class CreateSelfExtractFixture
    {
        [TestInitialize]
        public void TestInitialize()
        {
            if (!Directory.Exists(@"CreateSelfExtractFixture\testfoldertocompress"))
            {
                Directory.CreateDirectory(@"CreateSelfExtractFixture\testfoldertocompress");
            }

            if (!Directory.Exists(@"CreateSelfExtractFixture\testoutputfolder"))
            {
                Directory.CreateDirectory(@"CreateSelfExtractFixture\testoutputfolder");
            }
        }

        [TestCleanup]
        public void TestCleanUp()
        {
            if (Directory.Exists(@"CreateSelfExtractFixture\testfoldertocompress"))
            {
                Directory.Delete(@"CreateSelfExtractFixture\testfoldertocompress", true);
            }

            if (Directory.Exists(@"CreateSelfExtractFixture\testoutputfolder"))
            {
                Directory.Delete(@"CreateSelfExtractFixture\testoutputfolder", true);
            }
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ExecuteShouldThrowExceptionWhenMetadataIsNull()
        {
            var mockCompressHelper = new Mock<CompressHelper>();
            var step = new CreateSelfExtractStep(mockCompressHelper.Object);

            step.Execute();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ExecuteShouldThrowExceptionWhenPackageLicenseAgreementFileDoesNotExists()
        {
            var mockCompressHelper = new Mock<CompressHelper>();
            var step = new CreateSelfExtractStep(mockCompressHelper.Object);

            step.Metadata = new SelfExtractMetadata
            {
                Package = new Package { LicenseAgreementFile = "inexistentfile.txt" }
            };

            step.Execute();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ExecuteShouldThrowExceptionWhenSampleLicenseAgreementFileDoesNotExists()
        {
            var mockCompressHelper = new Mock<CompressHelper>();
            var step = new CreateSelfExtractStep(mockCompressHelper.Object);

            step.Metadata = new SelfExtractMetadata
            {
                Sample = new Sample { LicenseAgreementFile = "inexistentfile.txt" }
            };

            step.Execute();
        }

        [TestMethod]
        public void ExecuteShouldCallLoadCompressToolOnce()
        {
            var mockCompressHelper = new Mock<CompressHelper>();
            var step = new CreateSelfExtractStep(mockCompressHelper.Object);

            step.Metadata = new SelfExtractMetadata();
            step.Execute();

            mockCompressHelper.Verify(
                mockHelper => mockHelper.LoadTool(), Times.Once());
        }

        [TestMethod]
        public void ExecuteShouldCallGenerateSelfExtractOnce()
        {
            var mockCompressHelper = new Mock<CompressHelper>();
            var step = new CreateSelfExtractStep(mockCompressHelper.Object);

            step.Metadata = new SelfExtractMetadata();
            step.Execute();

            mockCompressHelper.Verify(
                mockHelper => mockHelper.GenerateSelfExtract(step.Metadata), Times.Once());
        }

        [TestMethod]
        public void ExecuteShouldCreateCommentsFileForPackageLicenseAgreement()
        {
            var mockCompressHelper = new Mock<CompressHelper>();
            var step = new CreateSelfExtractStep(mockCompressHelper.Object);

            step.Metadata = new SelfExtractMetadata
            {
                Package = new Package
                {
                    Id = "testpackageid",
                    Name = "testpackagename",
                    LicenseAgreementFile = @"CreateSelfExtractFixture\LicenseAgreement.txt"
                },
                FolderToCompress = @"CreateSelfExtractFixture\testfoldertocompress"
            };
            var expectedCommentsFilename = @"CreateSelfExtractFixture\testfoldertocompress\Comments.txt";
            step.Execute();

            Assert.IsTrue(File.Exists(expectedCommentsFilename));
            Assert.AreEqual(expectedCommentsFilename, step.Metadata.LicenseAgreementFile);
        }

        [TestMethod]
        public void ExecuteShouldCreateCommentsFileForSampleLicenseAgreement()
        {
            var mockCompressHelper = new Mock<CompressHelper>();
            var step = new CreateSelfExtractStep(mockCompressHelper.Object);

            step.Metadata = new SelfExtractMetadata
            {
                Sample = new Sample
                {
                    Id = "testsampleid",
                    LicenseAgreementFile = @"CreateSelfExtractFixture\LicenseAgreement.txt"
                },
                FolderToCompress = @"CreateSelfExtractFixture\testfoldertocompress"
            };
            var expectedCommentsFilename = @"CreateSelfExtractFixture\testfoldertocompress\Comments.txt";
            step.Execute();

            Assert.IsTrue(File.Exists(expectedCommentsFilename));
            Assert.AreEqual(expectedCommentsFilename, step.Metadata.LicenseAgreementFile);
        }

        [TestMethod]
        public void ExecuteShouldCreateCommentsFileForCustomLicenseAgreement()
        {
            var mockCompressHelper = new Mock<CompressHelper>();
            var step = new CreateSelfExtractStep(mockCompressHelper.Object);

            step.Metadata = new SelfExtractMetadata
            {
                FolderToCompress = @"CreateSelfExtractFixture\testfoldertocompress",
                LicenseAgreementFile = @"CreateSelfExtractFixture\LicenseAgreement.txt"
            };
            var expectedCommentsFilename = @"CreateSelfExtractFixture\testfoldertocompress\Comments.txt";
            step.Execute();

            Assert.IsTrue(File.Exists(expectedCommentsFilename));
            Assert.AreEqual(expectedCommentsFilename, step.Metadata.LicenseAgreementFile);
        }

        [TestMethod]
        public void ExecuteShouldCreateShortcutWithIconInCommentsFile()
        {
            var mockCompressHelper = new Mock<CompressHelper>();
            var step = new CreateSelfExtractStep(mockCompressHelper.Object);

            step.Metadata = new SelfExtractMetadata
            {
                Package = new Package
                {
                    Id = "testpackageid",
                    Name = "testpackagename",
                    Description = "testdescription",
                    Icon = "testicon"
                },
                FolderToCompress = @"CreateSelfExtractFixture\testfoldertocompress",
                LicenseAgreementFile = @"CreateSelfExtractFixture\LicenseAgreement.txt",
                ShortcutFile = "testshortcutfile",
            };
            var expectedCommentsFilename = @"CreateSelfExtractFixture\testfoldertocompress\Comments.txt";
            var expectedShortcutLine = @"Shortcut=D, testshortcutfile, , ""testdescription"", ""testpackagename"", testicon";
            step.Execute();

            Assert.IsTrue(File.Exists(expectedCommentsFilename));
            var lines = File.ReadAllLines(@"CreateSelfExtractFixture\testfoldertocompress\Comments.txt");
            Assert.AreEqual(expectedShortcutLine, lines[5]);
        }

        [TestMethod]
        public void ExecuteShouldCreateDefaultStartCommandInCommentsFile()
        {
            var mockCompressHelper = new Mock<CompressHelper>();
            var step = new CreateSelfExtractStep(mockCompressHelper.Object);

            step.Metadata = new SelfExtractMetadata
            {
                FolderToCompress = @"CreateSelfExtractFixture\testfoldertocompress",
                LicenseAgreementFile = @"CreateSelfExtractFixture\LicenseAgreement.txt",
            };
            var expectedCommentsFilename = @"CreateSelfExtractFixture\testfoldertocompress\Comments.txt";
            var expectedStartCommand = @"Setup=explorer .\";
            step.Execute();

            Assert.IsTrue(File.Exists(expectedCommentsFilename));
            var lines = File.ReadAllLines(@"CreateSelfExtractFixture\testfoldertocompress\Comments.txt");
            Assert.AreEqual(expectedStartCommand, lines[4]);
        }

        [TestMethod]
        public void ExecuteShouldCreateCustomStartCommandInCommentsFile()
        {
            var mockCompressHelper = new Mock<CompressHelper>();
            var step = new CreateSelfExtractStep(mockCompressHelper.Object);

            step.Metadata = new SelfExtractMetadata
            {
                FolderToCompress = @"CreateSelfExtractFixture\testfoldertocompress",
                LicenseAgreementFile = @"CreateSelfExtractFixture\LicenseAgreement.txt",
                StartCommand = "teststartcommand",
            };
            var expectedCommentsFilename = @"CreateSelfExtractFixture\testfoldertocompress\Comments.txt";
            var expectedStartCommand = @"Setup=teststartcommand";
            step.Execute();

            Assert.IsTrue(File.Exists(expectedCommentsFilename));
            var lines = File.ReadAllLines(@"CreateSelfExtractFixture\testfoldertocompress\Comments.txt");
            Assert.AreEqual(expectedStartCommand, lines[4]);
        }

        [TestMethod]
        public void ExecuteShouldCreateDefaultHtmStartCommandInCommentsFile()
        {
            var mockCompressHelper = new Mock<CompressHelper>();
            var step = new CreateSelfExtractStep(mockCompressHelper.Object);

            step.Metadata = new SelfExtractMetadata
            {
                FolderToCompress = @"CreateSelfExtractFixture\testfoldertocompress",
                LicenseAgreementFile = @"CreateSelfExtractFixture\LicenseAgreement.txt",
            };
            var expectedCommentsFilename = @"CreateSelfExtractFixture\testfoldertocompress\Comments.txt";
            var expectedStartCommand = @"Setup=explorer default.htm";

            using (var dummy = File.Create(@"CreateSelfExtractFixture\testfoldertocompress\default.htm"))
            {
                // Nothing to do here, just creating an empty file to be deleted
            }

            step.Execute();

            Assert.IsTrue(File.Exists(expectedCommentsFilename));
            var lines = File.ReadAllLines(@"CreateSelfExtractFixture\testfoldertocompress\Comments.txt");
            Assert.AreEqual(expectedStartCommand, lines[4]);
        }

        [TestMethod]
        public void ExecuteShouldExludeMetadataNameFileFromOutputFolder()
        {
            var mockCompressHelper = new Mock<CompressHelper>();
            var step = new CreateSelfExtractStep(mockCompressHelper.Object);

            step.Metadata = new SelfExtractMetadata
            {
                OutputDirectory = @"CreateSelfExtractFixture\testoutputfolder",
                Name = "testoutputfile"
            };

            using (var dummy = File.Create(@"CreateSelfExtractFixture\testoutputfolder\testoutputfile"))
            {
                // Nothing to do here, just creating an empty file to be deleted
            }

            step.Execute();

            Assert.IsFalse(File.Exists(@"CreateSelfExtractFixture\testoutputfolder\testoutputfile"));
        }
    }
}