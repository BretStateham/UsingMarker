﻿namespace ContentFramework.Core.Tests.Unit
{
    using System;
    using System.IO;
    using Microsoft.Dpe.Ecf.Core.Helpers;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class CompressHelperFixture
    {
        [TestMethod]
        [DeploymentItem("Resources\\CompressHelperFixture", "CompressHelperFixture")]
        public void GetWinrarInstallPath_ShouldReturnInstalledWinrarPath()
        {
            var mockWinrarPath = Environment.ExpandEnvironmentVariables("%LocalAppData%\\CompressHelperFixture\\winrar.exe");
            var mockWinrarFolder = Path.GetDirectoryName(mockWinrarPath);
            if (!File.Exists(mockWinrarPath))
            {
                Directory.CreateDirectory(Path.GetDirectoryName(mockWinrarPath));
                File.Copy("CompressHelperFixture\\winrar.exe", mockWinrarPath, true);
            }

            var helper = new CompressHelper(
                winrarBundlePath: mockWinrarFolder,
                winrarInstallPath: "invalidpath",
                winrarWowInstallPath: "invalidpath");

            var winrarBundlePath = helper.GetWinrarInstallPath();
            Assert.AreEqual(mockWinrarPath, winrarBundlePath);

            helper = new CompressHelper(
                winrarBundlePath: "invalidpath",
                winrarInstallPath: mockWinrarFolder,
                winrarWowInstallPath: "invalidpath");

            var winrarInstallPath = helper.GetWinrarInstallPath();
            Assert.AreEqual(mockWinrarPath, winrarInstallPath);

            helper = new CompressHelper(
                winrarBundlePath: "invalidpath",
                winrarInstallPath: "invalidpath",
                winrarWowInstallPath: mockWinrarFolder);

            var winrarWowInstallPath = helper.GetWinrarInstallPath();
            Assert.AreEqual(mockWinrarPath, winrarWowInstallPath);

            helper = new CompressHelper(
                winrarBundlePath: "invalidpath",
                winrarInstallPath: "invalidpath",
                winrarWowInstallPath: "invalidpath");

            var nullPath = helper.GetWinrarInstallPath();
            Assert.IsNull(nullPath);

            if (File.Exists(mockWinrarPath))
            {
                File.Delete(mockWinrarPath);
            }
        }
    }
}
