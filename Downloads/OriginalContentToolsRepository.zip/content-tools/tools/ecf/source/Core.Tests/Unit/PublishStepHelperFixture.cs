﻿namespace Microsoft.Dpe.Ecf.Core.Tests
{
    using System;
    using System.Collections.Generic;
    using Microsoft.Dpe.Ecf.Core.Helpers;
    using Microsoft.Dpe.Ecf.Model;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class PublishStepHelperFixture
    {
        [TestMethod]
        public void ShouldChangeTopicLinks()
        {
            Dictionary<string, PublishedPost> dic = new Dictionary<string, PublishedPost>();
            dic.Add("Exercise1.html", new PublishedPost(Guid.NewGuid().ToString(), new Uri("http://tempuri/Exercise1.aspx"), "Exercise 1", false));
            dic.Add("Exercise2.html", new PublishedPost(Guid.NewGuid().ToString(), new Uri("http://tempuri/Exercise2.aspx"), "Exercise 2", false));

            string actualContent = PublishStepHelper.ChangeTopicLinks("<a href=\"Exercise1.html\">Exercise 1</a><a href=\"Exercise2.html\">Exercise 2</a>", dic);

            Assert.AreEqual("<a href=\"http://tempuri/Exercise1.aspx\">Exercise 1</a><a href=\"http://tempuri/Exercise2.aspx\">Exercise 2</a>", actualContent);
        }

        [TestMethod]
        public void ShouldChangeImagesLinks()
        {
            Dictionary<string, string> dic = new Dictionary<string, string>();
            dic.Add("sampleImage.jpg", "http://tempuri/sampleImage.jpg");

            string actualContent = PublishStepHelper.ChangeImagesLinks("<img src=\"images\\sampleImage.jpg\" />", "images", dic);

            Assert.AreEqual("<img src=\"http://tempuri/sampleImage.jpg\" />", actualContent);
        }

        [TestMethod]
        public void ShouldChangeLocalFilesLinks()
        {
            Dictionary<string, string> dic = new Dictionary<string, string>();
            dic.Add("note.gif", "http://tempuri/note.gif");

            string actualContent = PublishStepHelper.ChangeLocalFilesLinks("<img src=\"../local/note.gif\" />", dic);

            Assert.AreEqual("<img src=\"http://tempuri/note.gif\" />", actualContent);
        }
    }
}
