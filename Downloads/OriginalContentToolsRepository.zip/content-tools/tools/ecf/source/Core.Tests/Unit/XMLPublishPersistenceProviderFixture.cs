﻿namespace Microsoft.Dpe.Ecf.Core.Tests
{
    using System;
    using System.Collections.ObjectModel;
    using System.IO;
    using System.Linq;
    using Microsoft.Dpe.Ecf.Core.Providers;
    using Microsoft.Dpe.Ecf.Model;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class XMLPublishPersistenceProviderFixture
    {
        [TestMethod]
        public void ShouldPersistPublishedPosts()
        {
            Lab elementId = new Lab() { Id = "EcfElementId1" };
            Collection<PublishedPost> publishedPosts = this.BuildMockPublishedPosts();

            XmlPublishPersistenceProvider persitenceProvider = new XmlPublishPersistenceProvider();
            string persitsFile = "publishedPostsTest.xml";
            persitenceProvider.PersistElementPosts(persitsFile, elementId, publishedPosts, "http://www.test1.com/", "MyUser");

            Assert.IsTrue(File.Exists(persitsFile));
            Assert.IsTrue(File.ReadAllText(persitsFile).Length > 0);

            // Delete created File
            File.Delete(persitsFile);
        }

        [TestMethod]
        public void ShouldUnPersistPublishedPosts()
        {
            Lab elementId = new Lab { Id = "EcfElementId1" };
            
            XmlPublishPersistenceProvider persitenceProvider = new XmlPublishPersistenceProvider();
            Collection<PublishedPost> publishedPosts = persitenceProvider.GetPersistedElementPosts("publishedPosts.xml", elementId);

            Assert.AreEqual(4, publishedPosts.Count);
            Assert.AreEqual("postId1", publishedPosts.First().PostId);
            Assert.AreEqual("Title 1", publishedPosts.First().Title);
            Assert.AreEqual("http://www.test4.com/", publishedPosts.First().Link);
            Assert.AreEqual("http://www.test4.com/", publishedPosts.First().PostUri.ToString());
            Assert.AreEqual(true, publishedPosts.First().Obsolete);
            Assert.AreEqual(true, publishedPosts.First().Draft);
            Assert.AreEqual("postId4", publishedPosts[3].PostId);
            Assert.AreEqual(false, publishedPosts[3].Obsolete);
            Assert.IsNotNull(publishedPosts[3].LastModified);   
        }

        [TestMethod]
        public void ShouldFilterObsoletePosts()
        {
            Lab lab = new Lab { Id = "EcfElementId1" };

            // Fileter by true
            XmlPublishPersistenceProvider persitenceProvider = new XmlPublishPersistenceProvider();
            var publishedPosts = persitenceProvider.GetPersistedElementPosts("publishedPosts.xml").FilterObsoletePosts(true);

            var posts = publishedPosts[new PublishedElementsDictionaryKey(lab)];

            Assert.AreEqual(2, posts.Count);
            Assert.AreEqual(true, posts.First().Obsolete);

            // Fileter by false
            publishedPosts = PublishPersistenceProviderFactory.Instance.GetPersistedElementPosts("publishedPosts.xml").FilterObsoletePosts(false);

            posts = publishedPosts[new PublishedElementsDictionaryKey(lab)];

            Assert.AreEqual(2, posts.Count);
            Assert.AreEqual(false, posts.First().Obsolete);
        }

        [TestMethod]
        public void ShouldFilterDraftPosts()
        {
            Lab lab = new Lab { Id = "EcfElementId1" };

            // Filter by true
            XmlPublishPersistenceProvider persitenceProvider = new XmlPublishPersistenceProvider();
            var publishedPosts = PublishPersistenceProviderFactory.Instance.GetPersistedElementPosts("publishedPosts.xml").FilterDraftPosts(true);

            var posts = publishedPosts[new PublishedElementsDictionaryKey(lab)];

            Assert.AreEqual(3, posts.Count);
            Assert.AreEqual(true, posts.First().Draft);

            // Filter by false
            publishedPosts = persitenceProvider.GetPersistedElementPosts("publishedPosts.xml").FilterDraftPosts(false);

            posts = publishedPosts[new PublishedElementsDictionaryKey(lab)];

            Assert.AreEqual(1, posts.Count);
            Assert.AreEqual(false, posts.First().Draft);
        }

        [TestMethod]        
        public void ShouldNotFindElemnet()
        {
            Lab elementId = new Lab() { Id = "NotExistingKey" };

            XmlPublishPersistenceProvider persitenceProvider = new XmlPublishPersistenceProvider();
            Collection<PublishedPost> publishedPosts = persitenceProvider.GetPersistedElementPosts("publishedPosts.xml", elementId);

            Assert.AreEqual(0, publishedPosts.Count());
        }

        private Collection<PublishedPost> BuildMockPublishedPosts()
        {
            return new Collection<PublishedPost>() 
            {
                new PublishedPost("postId1", new Uri("http://www.test1.com"), "Title 1", false) { Obsolete = true },
                new PublishedPost("postId2", new Uri("http://www.test2.com"), "Title 2", false) { Obsolete = false },
                new PublishedPost("postId3", new Uri("http://www.test3.com"), "Title 3", false),
                new PublishedPost("postId4", new Uri("http://www.test4.com"), "Title 4", false)
            };
        }
    }
}
