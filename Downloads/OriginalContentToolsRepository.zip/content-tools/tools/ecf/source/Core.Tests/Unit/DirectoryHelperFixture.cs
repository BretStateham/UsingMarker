﻿namespace ContentFramework.Core.Tests.Unit
{
    using System.IO;
    using System.Linq;
    using Microsoft.Dpe.Ecf.Common.Helpers;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class DirectoryHelperFixture
    {
        [TestMethod]
        [DeploymentItem("Resources\\DirectoryHelperFixture", "DirectoryHelperFixture")]
        public void GetFileSystemEntriesFiltered_ExcludeSpecificFilesInRootFolder()
        {
            var excludes = new string[] { "test-file.xml" };
            var rootFolder = Path.GetFullPath("DirectoryHelperFixture\\test-folder");

            var files = DirectoryHelper.GetFileSystemEntriesFiltered(rootFolder, excludes);

            Assert.IsFalse(files.Contains(Path.Combine(rootFolder, "test-file.xml")));
            Assert.IsTrue(files.Contains(Path.Combine(rootFolder, ".svn\\test-file.xml")));
        }

        [TestMethod]
        [DeploymentItem("Resources\\DirectoryHelperFixture", "DirectoryHelperFixture")]
        public void GetFileSystemEntriesFiltered_ExcludePatternInAnyFolder()
        {
            var excludes = new string[] { "*.txt" };
            var rootFolder = Path.GetFullPath("DirectoryHelperFixture\\test-folder");

            var files = DirectoryHelper.GetFileSystemEntriesFiltered(rootFolder, excludes);

            Assert.IsTrue(files.Contains(Path.Combine(rootFolder, "test-file.png")));
            Assert.IsFalse(files.Contains(Path.Combine(rootFolder, "test-file.txt")));
            Assert.IsTrue(files.Contains(Path.Combine(rootFolder, "test-file.xml")));
            Assert.IsTrue(files.Contains(Path.Combine(rootFolder, ".svn\\test-file.png")));
            Assert.IsFalse(files.Contains(Path.Combine(rootFolder, ".svn\\test-file.txt")));
            Assert.IsTrue(files.Contains(Path.Combine(rootFolder, ".svn\\test-file.xml")));
        }

        [TestMethod]
        [DeploymentItem("Resources\\DirectoryHelperFixture", "DirectoryHelperFixture")]
        public void GetFileSystemEntriesFiltered_ExcludeAllFilesInSubFolder()
        {
            var excludes = new string[] { "*\\.svn\\*" };
            var rootFolder = Path.GetFullPath("DirectoryHelperFixture\\test-folder");

            var files = DirectoryHelper.GetFileSystemEntriesFiltered(rootFolder, excludes);

            Assert.IsTrue(files.Contains(Path.Combine(rootFolder, "test-file.png")));
            Assert.IsTrue(files.Contains(Path.Combine(rootFolder, "test-file.txt")));
            Assert.IsTrue(files.Contains(Path.Combine(rootFolder, "test-file.xml")));
            Assert.IsFalse(files.Contains(Path.Combine(rootFolder, ".svn\\test-file.png")));
            Assert.IsFalse(files.Contains(Path.Combine(rootFolder, ".svn\\test-file.txt")));
            Assert.IsFalse(files.Contains(Path.Combine(rootFolder, ".svn\\test-file.xml")));
            Assert.IsTrue(files.Contains(Path.Combine(rootFolder, "test-file.xml.html\\test-file.xml.html")));
            Assert.IsFalse(files.Contains(Path.Combine(rootFolder, "test-file.xml.html\\.svn\\test-file.png")));
            Assert.IsFalse(files.Contains(Path.Combine(rootFolder, "test-file.xml.html\\.svn\\test-file.txt")));
            Assert.IsFalse(files.Contains(Path.Combine(rootFolder, "test-file.xml.html\\.svn\\test-file.xml")));
        }

        [TestMethod]
        [DeploymentItem("Resources\\DirectoryHelperFixture", "DirectoryHelperFixture")]
        public void GetFileSystemEntriesFiltered_ExcludeAFolderButNotAllSubFolderWithSameName()
        {
            var excludes = new string[] { ".svn", ".svn\\*" };
            var rootFolder = Path.GetFullPath("DirectoryHelperFixture\\test-folder");

            var files = DirectoryHelper.GetFileSystemEntriesFiltered(rootFolder, excludes);

            Assert.IsFalse(files.Contains(Path.Combine(rootFolder, ".svn\\test-file.png")));
            Assert.IsFalse(files.Contains(Path.Combine(rootFolder, ".svn\\test-file.txt")));
            Assert.IsFalse(files.Contains(Path.Combine(rootFolder, ".svn\\test-file.xml")));
            Assert.IsTrue(files.Contains(Path.Combine(rootFolder, "test-file.xml.html\\.svn\\test-file.png")));
            Assert.IsTrue(files.Contains(Path.Combine(rootFolder, "test-file.xml.html\\.svn\\test-file.txt")));
            Assert.IsTrue(files.Contains(Path.Combine(rootFolder, "test-file.xml.html\\.svn\\test-file.xml")));
        }

        [TestMethod]
        [DeploymentItem("Resources\\DirectoryHelperFixture", "DirectoryHelperFixture")]
        public void GetFileSystemEntriesFiltered_ExcludeSpecificFilesInSubFolder()
        {
            var excludes = new string[] { "*\\.svn\\test-file.xml" };
            var rootFolder = Path.GetFullPath("DirectoryHelperFixture\\test-folder");

            var files = DirectoryHelper.GetFileSystemEntriesFiltered(rootFolder, excludes);

            Assert.IsTrue(files.Contains(Path.Combine(rootFolder, "test-file.png")));
            Assert.IsTrue(files.Contains(Path.Combine(rootFolder, "test-file.txt")));
            Assert.IsTrue(files.Contains(Path.Combine(rootFolder, "test-file.xml")));
            Assert.IsTrue(files.Contains(Path.Combine(rootFolder, ".svn\\test-file.png")));
            Assert.IsTrue(files.Contains(Path.Combine(rootFolder, ".svn\\test-file.txt")));
            Assert.IsFalse(files.Contains(Path.Combine(rootFolder, ".svn\\test-file.xml")));
        }

        [TestMethod]
        [DeploymentItem("Resources\\DirectoryHelperFixture", "DirectoryHelperFixture")]
        public void GetFileSystemEntriesFiltered_ExcludePatternInSubFolder()
        {
            var excludes = new string[] { "*\\.svn\\*.txt" };
            var rootFolder = Path.GetFullPath("DirectoryHelperFixture\\test-folder");

            var files = DirectoryHelper.GetFileSystemEntriesFiltered(rootFolder, excludes);

            Assert.IsTrue(files.Contains(Path.Combine(rootFolder, "test-file.png")));
            Assert.IsTrue(files.Contains(Path.Combine(rootFolder, "test-file.txt")));
            Assert.IsTrue(files.Contains(Path.Combine(rootFolder, "test-file.xml")));
            Assert.IsTrue(files.Contains(Path.Combine(rootFolder, ".svn\\test-file.png")));
            Assert.IsFalse(files.Contains(Path.Combine(rootFolder, ".svn\\test-file.txt")));
            Assert.IsTrue(files.Contains(Path.Combine(rootFolder, ".svn\\test-file.xml")));
        }

        [TestMethod]
        [DeploymentItem("Resources\\DirectoryHelperFixture", "DirectoryHelperFixture")]
        public void GetFileSystemEntriesFiltered_ExcludePatternDoesNotExcludeMultipleExtensionFile()
        {
            var excludes = new string[] { "*.xml" };
            var rootFolder = Path.GetFullPath("DirectoryHelperFixture\\test-folder");

            var files = DirectoryHelper.GetFileSystemEntriesFiltered(rootFolder, excludes);

            Assert.IsFalse(files.Contains(Path.Combine(rootFolder, "test-file.xml")));
            Assert.IsFalse(files.Contains(Path.Combine(rootFolder, ".svn\\test-file.xml")));
            Assert.IsTrue(files.Contains(Path.Combine(rootFolder, "test-file.xml.html\\test-file.xml.html")));
        }
    }
}
