﻿namespace Microsoft.Dpe.Ecf.Core.Tests
{
    using System;
    using System.IO;
    using Microsoft.Dpe.Ecf.Core.Steps;
    using Microsoft.Practices.DocxConverter;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    [DeploymentItem(@"Resources\\ConvertDocumentStepFixture", "ConvertDocumentStepFixture")]
    [DeploymentItem(@"Resources\\Formatting", "Formatting")]
    public class ConvertDocumentStepFixture
    {
        private string LastCreatedDirectory
        {
            get;
            set;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA1806:DoNotIgnoreMethodResults", MessageId = "ContentFramework.Core.Steps.ConvertDocumentStep", Justification = "Creating of instance is needed to generate Exception"), TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ExecuteShouldThrowArgumentException()
        {
            new ConvertDocumentStep("ConvertDocumentStepFixture\\Overview.docx.invalid", "Html");
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA1806:DoNotIgnoreMethodResults", MessageId = "ContentFramework.Core.Steps.ConvertDocumentStep", Justification = "Creating of instance is needed to generate Exception"), TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ExecuteShouldNotRecognizeConversionType()
        {
            new ConvertDocumentStep("ConvertDocumentStepFixture\\Overview.docx", "WEBLOG");
        }

        [TestMethod]
        public void ExecuteConvertToDefaultFolder()
        {
            ConvertDocumentStep convertionStep = new ConvertDocumentStep("ConvertDocumentStepFixture\\Overview.docx", "Html");

            convertionStep.Execute();
            string createdFile = "ConvertDocumentStepFixture\\Overview.html\\html\\DocSet_default.html";
            Assert.IsTrue(File.Exists(createdFile), "Overview File was not converted");

            // Prepare to delete resources
            this.LastCreatedDirectory = Path.GetDirectoryName(createdFile);
        }

        [TestMethod]
        public void ExecuteConvertToPdf()
        {
            ConvertDocumentStep convertionStep = new ConvertDocumentStep("ConvertDocumentStepFixture\\Overview.docx", "Pdf");

            convertionStep.Execute();
            string createdFile = "ConvertDocumentStepFixture\\Overview.pdf";
            Assert.IsTrue(File.Exists(createdFile), "Overview File was not converted");
        }

        [TestMethod]
        public void ShouldConvertDocumentWithoutDefault()
        {
            ConvertDocumentStep convertionStep = new ConvertDocumentStep("ConvertDocumentStepFixture\\Topic.docx", "Html");

            convertionStep.Execute();

            string[] files = Directory.GetFiles("ConvertDocumentStepFixture\\Topic.html\\html", "*.html");

            Assert.IsTrue(files.Length == 1);
            Assert.IsFalse(files[0].Contains("default"));
            
            // Prepare to delete resources
            this.LastCreatedDirectory = Path.GetDirectoryName(files[0]);
        }

        [TestMethod]
        public void ExecuteConvertDocInRelativePath()
        {
            ConvertDocumentStep convertionStep = new ConvertDocumentStep("ConvertDocumentStepFixture\\Labs\\Test\\Docs\\Test.docx", "Html");

            convertionStep.Execute();
            string createdFile = "ConvertDocumentStepFixture\\Labs\\Test\\Docs\\Test.html\\html\\DocSet_default.html";
            Assert.IsTrue(File.Exists(createdFile), "Test File was not converted");

            // Prepare to delete resources
            this.LastCreatedDirectory = Path.GetDirectoryName(createdFile);
        }

        [TestMethod]
        [Ignore]
        public void ExecuteConvertToDefaultFolderToMht()
        {
            ConvertDocumentStep convertionStep = new ConvertDocumentStep("ConvertDocumentStepFixture\\Overview.docx", "Mht");

            convertionStep.Execute();

            string createdFile = "ConvertDocumentStepFixture\\Overview.mht";
            Assert.IsTrue(File.Exists(createdFile), "Overview File was not converted");

            // Prepare to delete resources
            File.Delete(createdFile);
        }

        [TestMethod]
        public void ShouldConvertDocumentWithoutDefaultToMHT()
        {
            ConvertDocumentStep convertionStep = new ConvertDocumentStep("ConvertDocumentStepFixture\\Topic.docx", "Mht");

            convertionStep.Execute();

            string createdFile = "ConvertDocumentStepFixture\\Topic.mht";
            Assert.IsTrue(File.Exists(createdFile));

            // Prepare to delete resources
            File.Delete(createdFile);
        }

        [TestMethod]
        [Ignore]
        public void ExecuteConvertDocInRelativePathToMHT()
        {
            ConvertDocumentStep convertionStep = new ConvertDocumentStep("ConvertDocumentStepFixture\\Labs\\Test\\Docs\\Test.docx", "Mht");

            convertionStep.Execute();

            string createdFile = "ConvertDocumentStepFixture\\Labs\\Test\\Docs\\Test.mht";
            Assert.IsTrue(File.Exists(createdFile), "Test File was not converted");

            // Prepare to delete resources
            File.Delete(createdFile);
        }

        [TestMethod]
        [ExpectedException(typeof(SplitDocumentConverterException))]
        public void ShouldThowCustomExceptionConvertingLab()
        {
            ConvertDocumentStep convertionStep = new ConvertDocumentStep("ConvertDocumentStepFixture\\Labs\\VS2010\\Lab.docx", "Html");

            convertionStep.Execute();
            string createdFile = "ConvertDocumentStepFixture\\Labs\\Test\\Docs\\Lab.html\\DocSet_default.html";
            Assert.IsTrue(File.Exists(createdFile), "Overview File was not converted");

            // Prepare to delete resources
            // this.LastCreatedDirectory = Path.GetDirectoryName(createdFile);
        }

        [TestCleanup()]
        public void DeleteFolderCleanUp()
        {
            if (!String.IsNullOrEmpty(this.LastCreatedDirectory) && Directory.Exists(this.LastCreatedDirectory))
            {
                Directory.Delete(this.LastCreatedDirectory, true);
            }
        }
    }
}
