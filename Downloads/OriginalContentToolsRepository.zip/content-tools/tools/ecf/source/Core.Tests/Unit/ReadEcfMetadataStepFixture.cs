﻿namespace Microsoft.Dpe.Ecf.Core.Tests
{
    using System;
    using System.IO;
    using System.Linq;
    using Microsoft.Dpe.Ecf.Core.Steps;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class ReadEcfMetadataStepFixture
    {
        [TestMethod]
        public void Execute_ShouldReturnDefaultInstance_WhenContentIsNullOrEmpty()
        {
            var ecfPath = Environment.GetEnvironmentVariable("ECF");
            var step = new ReadEcfMetadataStep();
            step.EcfMetadataContent = null;

            var instance = step.Execute();

            Assert.IsNotNull(instance);
            Assert.AreEqual("Assets", instance.AssetsDirectory);
            Assert.AreEqual(Path.Combine(ecfPath, @"Resources\Copyright.txt"), instance.CopyrightHeaderTemplate);
            Assert.AreEqual(".svn obj bin *.user _ReSharper* *.suo .git", instance.ExcludeFilePattern);

            Assert.IsNotNull(instance.Conversion);
            Assert.AreEqual(Path.Combine(ecfPath, @"Resources\HtmlConversion\xsl"), instance.Conversion.XsltDirectory);

            Assert.IsNotNull(instance.NavigationPages);
            Assert.AreEqual("*.include.t4 *.include.tt", instance.NavigationPages.IncludeFilePattern);
            Assert.AreEqual("unit.htm", instance.NavigationPages.CleanupFilePattern);
            Assert.AreEqual(@"Resources\NavigationPagesTemplates", instance.NavigationPages.TemplatesDirectory);

            Assert.IsNotNull(instance.SelfExtract);
            Assert.AreEqual(Path.Combine(ecfPath, @"Resources\LicenseAgreement.txt"), instance.SelfExtract.LicenseFile);
            Assert.AreEqual(Path.Combine(ecfPath, @"Resources\vertical.bmp"), instance.SelfExtract.ImageFile);
            Assert.AreEqual(Path.Combine(ecfPath, @"Resources\Exclude.txt"), instance.SelfExtract.ExcludesFile);
            Assert.AreEqual(@"Default.htm", instance.SelfExtract.ShortcutFile);

            Assert.IsNotNull(instance.DependencyCheckerAggregator);
            Assert.IsFalse(instance.DependencyCheckerAggregator.AggregateDeploymentTasks);
            Assert.IsFalse(instance.DependencyCheckerAggregator.UpdateScriptToAbsolutePath);
            Assert.AreEqual(@"Assets\Setup\Dependencies.dep", instance.DependencyCheckerAggregator.OutputDependenciesFile);
            Assert.IsNotNull(instance.DependencyCheckerAggregator.LabSpecificTasks);
            Assert.AreEqual(2, instance.DependencyCheckerAggregator.LabSpecificTasks.Count);
            Assert.IsTrue(instance.DependencyCheckerAggregator.LabSpecificTasks.Any(
                task => task == "Create an alias for the AdventureWorksLT database"));
            Assert.IsTrue(instance.DependencyCheckerAggregator.LabSpecificTasks.Any(
                task => task == "Launch the Visual Studio installer to install the code snippets"));
            Assert.IsNotNull(instance.DependencyCheckerAggregator.ExcludeDependencies);
            Assert.AreEqual(1, instance.DependencyCheckerAggregator.ExcludeDependencies.Count);
            Assert.IsTrue(instance.DependencyCheckerAggregator.ExcludeDependencies.Any(
                dependency => dependency == "Dependency placeholder"));
        }
    }
}
