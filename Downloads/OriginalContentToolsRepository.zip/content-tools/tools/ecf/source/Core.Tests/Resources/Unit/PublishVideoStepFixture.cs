﻿namespace ContentFramework.Core.Tests
{
    using System;
    using System.IO;
    using ContentFramework.BlogPublisher;
    using ContentFramework.BlogPublisher.Helpers;
    using ContentFramework.BlogPublisher.Model;
    using ContentFramework.Core.Helpers;
    using ContentFramework.Core.Steps;
    using ContentFramework.Core.Tests.Mocks;
    using ContentFramework.Model;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class PublishVideoStepFixture
    {
        [ClassCleanup()]
        public static void ClassCleanUp()
        {
            if (MockMetaWeblogData.IsMockBlog)
            {
                WebServerHelper.StopWebServer();
            }
        }

        [ClassInitialize()]
        public static void ClassInitialize(TestContext context)
        {
            if (MockMetaWeblogData.IsMockBlog)
            {
                WebServerHelper.StartWebServer();
            }
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ExecuteShouldThrowVideoNotFound()
        {
            PublishVideoStep step = new PublishVideoStep(MockMetaWeblogData.Url, MockMetaWeblogData.User, MockMetaWeblogData.Password, false);
            step.VideoXmlFile = "ConvertedDocuments\\inexistentXmlFile.xml";

            step.Execute();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ExecuteShouldThrowPersistenceFileNotFound()
        {
            PublishVideoStep step = new PublishVideoStep(MockMetaWeblogData.Url, MockMetaWeblogData.User, MockMetaWeblogData.Password, false);
            step.VideoXmlFile = "Content\\Videos\\Maestro\\Video.xml";
            step.PersistedPostsFile = "ConvertedDocuments\\inexistentPersistenceFile.xml";

            step.Execute();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ExecuteShouldThrowVideoNotSpecified()
        {
            PublishVideoStep step = new PublishVideoStep(MockMetaWeblogData.Url, MockMetaWeblogData.User, MockMetaWeblogData.Password, false);
            step.VideoXmlFile = string.Empty;

            step.Execute();
        }        

        [TestMethod]        
        public void ShouldPublishVideoPostsContent()
        {
            // Create step
            PublishVideoStep step = new PublishVideoStep(MockMetaWeblogData.Url, MockMetaWeblogData.User, MockMetaWeblogData.Password, false);
            step.VideoXmlFile = "PublishVideo\\Video.xml";
            step.PostTemplateFile = "PublishVideo\\VideoPost.tt";

            // Publish Posts content
            PublishedPost publishedPost = step.Execute();

            MetaWeblogHelper helper = new MetaWeblogHelper(MockMetaWeblogData.Url.ToString());

            Post post = helper.GetPost(publishedPost.PostId, MockMetaWeblogData.User, MockMetaWeblogData.Password);           

            // Delete Post
            Assert.IsTrue(helper.DeletePost(String.Empty, publishedPost.PostId, MockMetaWeblogData.User, MockMetaWeblogData.Password, false));

            // Check the posted content
            Assert.IsTrue(post.description.Contains("Here we dig into the architecture and design of the Maestro"));

            // Check the post title
            Assert.AreEqual(publishedPost.Title, post.title);

            // Delete Persistence File
            Assert.IsTrue(File.Exists(step.PersistenceFile));
            File.Delete(step.PersistenceFile);
        }

        [TestMethod]
        public void ShouldUpdateVideoPostsContent()
        {
            // Create step
            PublishVideoStep step = new PublishVideoStep(MockMetaWeblogData.Url, MockMetaWeblogData.User, MockMetaWeblogData.Password, false);
            step.PostTemplateFile = "PublishVideo\\VideoPost.tt";

            // Publish original video
            step.VideoXmlFile = "PublishVideo\\Video.xml";
            PublishedPost originalPublishedPost = step.Execute();

            // Re-Publish with updated Video
            step.VideoXmlFile = "PublishVideo\\UpdatedVideo.xml";
            step.PersistedPostsFile = step.PersistenceFile;            
            PublishedPost updatedPublishedPost = step.Execute();

            MetaWeblogHelper helper = new MetaWeblogHelper(MockMetaWeblogData.Url.ToString());
            
            Post post = helper.GetPost(updatedPublishedPost.PostId, MockMetaWeblogData.User, MockMetaWeblogData.Password);
            
            // Delete Post
            Assert.IsTrue(helper.DeletePost(String.Empty, updatedPublishedPost.PostId, MockMetaWeblogData.User, MockMetaWeblogData.Password, false));

            // Check that the same post has been updated
            Assert.AreEqual(originalPublishedPost.PostId, updatedPublishedPost.PostId);

            // Check the posted content
            Assert.IsTrue(post.description.Contains("Updated - Here we dig into the architecture and design of the Maestro"));

            // Delete Persistence File
            Assert.IsTrue(File.Exists(step.PersistenceFile));
            File.Delete(step.PersistenceFile);
        }

        [TestMethod]
        public void ShouldReturnMmsUrl()
        {
            Video video = new Video();
            video.VideoUrl = "http://tempuri.com/videos/somevideo.wmv";

            Assert.AreEqual("mms://tempuri.com/videos/somevideo.wmv", video.MmsUrl);
        }

        [TestMethod]
        public void ShouldReturnHttpUrl()
        {
            Video video = new Video();
            video.VideoUrl = "mms://tempuri.com/videos/somevideo.wmv";

            Assert.AreEqual("http://tempuri.com/videos/somevideo.wmv", video.HttpUrl);
        }
    }
}
