﻿namespace ContentFramework.Core.Tests
{
    using System;
    using System.CodeDom.Compiler;
    using System.Collections.Generic;
    using System.IO;
    using System.Text;
    using ContentFramework.Core.Helpers;
    using ContentFramework.Core.Steps;
    using ContentFramework.Core.Tests.Mocks;
    using ContentFramework.Model;
    using ContentFramework.TextTemplating;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class CreateNavigationSiteStepFixture
    {
        [TestMethod]
        public void ExecuteShouldCallReadPackageMetadata()
        {
            MockPackageHelper mockPackageHelper = new MockPackageHelper();
            var step = new MockCreateNavigationSiteStep(mockPackageHelper, new MockTextTemplatingHelper());

            step.TemplatesDirectory = Path.GetFullPath("SiteTemplates");
            step.PackageFile = Path.GetFullPath("Package\\Package.xml");

            step.Execute();

            Assert.IsTrue(mockPackageHelper.IsReadMetadataFromWorkingDirectoryCalled);
        }

        [TestMethod]
        public void ExecuteShouldCallProcessTemplates()
        {
            MockTextTemplatingHelper templatingHelper = new MockTextTemplatingHelper();
            var step = new MockCreateNavigationSiteStep(new MockPackageHelper(), templatingHelper);

            step.TemplatesDirectory = Path.GetFullPath("SiteTemplates");
            step.PackageFile = Path.GetFullPath("Package\\Package.xml");

            step.Execute();

            Assert.IsTrue(templatingHelper.IsProcessTemplatesCalled);
        }

        [TestMethod]
        public void ExecuteShouldCallCreateSupportDirectories()
        {
            var step = new MockCreateNavigationSiteStep(new MockPackageHelper(), new MockTextTemplatingHelper());

            step.TemplatesDirectory = Path.GetFullPath("SiteTemplates");
            step.PackageFile = Path.GetFullPath("Package\\Package.xml");

            step.Execute();

            Assert.IsTrue(step.IsCreateSupportDirectoriesCalled);
        }

        private class MockCreateNavigationSiteStep : CreateNavigationSiteStep
        {
            internal MockCreateNavigationSiteStep(MetadataHelper packageHelper, TextTemplatingHelper templatingHelper)
                : base(packageHelper, templatingHelper)
            {
            }

            public bool IsCreateSupportDirectoriesCalled
            {
                get;
                set;
            }

            protected override void CreateSupportDirectories()
            {
                this.IsCreateSupportDirectoriesCalled = true;
            }
        }

        private class MockPackageHelper : MetadataHelper
        {
            public bool IsReadMetadataFromWorkingDirectoryCalled
            {
                get;
                set;
            }

            public bool IsUpdateMetadataCalled
            {
                get;
                set;
            }

            public override Package ReadMetadataFromWorkingDirectory(string filePath)
            {
                this.IsReadMetadataFromWorkingDirectoryCalled = true;
                return MockFactory.CreatePackage(null);
            }

            public override void UpdateMetadata(Package package)
            {
                this.IsUpdateMetadataCalled = true;
            }
        }

        private class MockTextTemplatingHelper : TextTemplatingHelper
        {
            public bool IsProcessTemplatesCalled
            {
                get;
                set;
            }

            public override void ProcessMultipleTemplates(string filePath, Dictionary<string, object> properties, string outputDirectory, string[] includeTemplates)
            {
                this.IsProcessTemplatesCalled = true;
            }
        }
    }
}
