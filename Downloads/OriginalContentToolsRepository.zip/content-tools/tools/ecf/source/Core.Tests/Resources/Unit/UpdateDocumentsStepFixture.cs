﻿namespace ContentFramework.Core.Tests
{
    using System.IO;
    using ContentFramework.Core.Helpers;
    using ContentFramework.Core.Steps;
    using ContentFramework.Core.Tests.Mocks;
    using ContentFramework.Model;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class UpdateDocumentsStepFixture
    {   
        [TestMethod]
        public void ExecuteShouldCallPackageReadMetadata()
        {
            MockPackageHelper mockHelper = new MockPackageHelper();
            MockUnitHelper mockStep = new MockUnitHelper();

            UpdateDocumentsStep step = new UpdateDocumentsStep(mockHelper, mockStep);

            step.PackageFile = Path.GetFullPath("package.xml");
            step.Execute();

            Assert.IsTrue(mockHelper.IsReadMetadataFromWorkingDirectoryCalled);
        }

        [TestMethod]
        public void ExecuteShouldCallPackageUpdateMetadata()
        {
            var mockHelper = new MockPackageHelper();
            MockUnitHelper mockStep = new MockUnitHelper();

            UpdateDocumentsStep step = new UpdateDocumentsStep(mockHelper, mockStep);

            step.PackageFile = Path.GetFullPath("package.xml");
            step.Execute();

            Assert.IsTrue(mockHelper.IsUpdateMetadataCalled);
        }

        [TestMethod]
        public void ExecuteShouldCallUnitUpdateMetadata()
        {
            CopyPackageStep beginStep = new CopyPackageStep();

            string packageFile = "Package\\Package.xml";

            beginStep.PackageFile = Path.GetFullPath(packageFile);
            beginStep.ProcessDirectory = Path.GetFullPath("NavTemp");

            beginStep.Execute();

            var mockStep = new MockUnitHelper();
            var mockPackageHelper = new MockPackageHelper();
            mockPackageHelper.ReadShouldReturnUnits = true;

            UpdateDocumentsStep step = new UpdateDocumentsStep(mockPackageHelper, mockStep);

            step.PackageFile = Path.GetFullPath("NavTemp\\VS10TrainingKit\\Package.xml");
            step.Execute();

            Assert.IsTrue(mockStep.IsUpdateMetadataCalled);
        }
        
        private class MockPackageHelper : MetadataHelper
        {
            public bool IsReadMetadataFromWorkingDirectoryCalled
            {
                get;
                set;
            }

            public bool IsUpdateMetadataCalled
            {
                get;
                set;
            }

            public bool ReadShouldReturnUnits 
            { 
                get; 
                set; 
            }

            public override Package ReadMetadataFromWorkingDirectory(string filePath)
            {
                this.IsReadMetadataFromWorkingDirectoryCalled = true;
                Package package;

                if (this.ReadShouldReturnUnits)
                {
                    package = MockFactory.CreatePackage(new string[] { "SSDS" });
                }
                else
                {
                    package = MockFactory.CreatePackage(null);
                }

                return package;
            }

            public override void UpdateMetadata(Package package)
            {
                this.IsUpdateMetadataCalled = true;
            }
        }
    }
}
