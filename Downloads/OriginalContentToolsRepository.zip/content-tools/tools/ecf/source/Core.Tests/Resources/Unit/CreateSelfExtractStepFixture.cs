﻿namespace ContentFramework.Core.Tests
{
    using System;
    using System.IO;
    using ContentFramework.Core.Models;
    using ContentFramework.Core.Steps;
    using ContentFramework.Core.Tests.Mocks;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class CreateSelfExtractFixture
    {
        [TestMethod]
        public void ExecuteShouldCallReadPackageMetadata()
        {
            CopyPackageStep beginStep = new CopyPackageStep();

            string packageFile = "Package\\Package.xml";

            beginStep.PackageFile = Path.GetFullPath(packageFile);
            beginStep.ProcessDirectory = Path.GetFullPath("Temp");

            beginStep.Execute();

            var mock = new MockPackageHelper();
            var step = new CreateSelfExtractStep(mock, new MockCompressHelper());
            
            step.Metadata = new SelfExtractMetadata()
            {
                LicenseAgreementFile = String.Empty,
                ExcludeFiles = Path.GetFullPath("exclude.txt"),
                ImageFile = Path.GetFullPath("vertical.bmp"),
                Name = "Little_Pack",
                OutputDirectory = Path.GetFullPath("Output"),
                ManifestFile = Path.GetFullPath("Temp\\VS10TrainingKit\\Package.xml")
            };

            step.Execute();

            Assert.IsTrue(mock.IsReadMetadataFromWorkingDirectoryCalled);
        }

        [TestMethod]
        public void ExecuteShouldCallLoadCompressTool()
        {
            CopyPackageStep beginStep = new CopyPackageStep();

            string packageFile = "Package\\Package.xml";

            beginStep.PackageFile = Path.GetFullPath(packageFile);
            beginStep.ProcessDirectory = Path.GetFullPath("Temp2");

            beginStep.Execute();

            var mock = new MockCompressHelper();
            var step = new CreateSelfExtractStep(new MockPackageHelper(), mock);

            step.Metadata = new SelfExtractMetadata()
            {
                LicenseAgreementFile = String.Empty,
                ExcludeFiles = Path.GetFullPath("exclude.txt"),
                ImageFile = Path.GetFullPath("vertical.bmp"),
                Name = "Little_Pack",
                OutputDirectory = Path.GetFullPath("Output"),
                ManifestFile = Path.GetFullPath("Temp2\\VS10TrainingKit\\Package.xml")
            };

            step.Execute();

            Assert.IsTrue(mock.IsLoadToolCalled);
        }

        [TestMethod]
        public void ExecuteShouldCallGenerateSelfExtract()
        {
            CopyPackageStep beginStep = new CopyPackageStep();

            string packageFile = "Package\\Package.xml";

            beginStep.PackageFile = Path.GetFullPath(packageFile);
            beginStep.ProcessDirectory = Path.GetFullPath("Temp");

            beginStep.Execute();

            var mock = new MockCompressHelper();
            var step = new CreateSelfExtractStep(new MockPackageHelper(), mock);

            step.Metadata = new SelfExtractMetadata()
            {
                LicenseAgreementFile = String.Empty,
                ExcludeFiles = Path.GetFullPath("exclude.txt"),
                ImageFile = Path.GetFullPath("vertical.bmp"),
                Name = "Little_Pack",
                OutputDirectory = Path.GetFullPath("Output"),
                ManifestFile = Path.GetFullPath("Temp\\VS10TrainingKit\\Package.xml")
            };

            step.Execute();

            Assert.IsTrue(mock.IsGenerateSelfExtractCalled);
        }
    }
}
