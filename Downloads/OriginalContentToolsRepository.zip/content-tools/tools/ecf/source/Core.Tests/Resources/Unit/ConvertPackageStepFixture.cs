﻿namespace ContentFramework.Core.Tests
{
    using System;
    using System.IO;
    using ContentFramework.Core.Steps;
    using ContentFramework.Model;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class ConvertEcfElementStepFixture
    {
        private string LastCreatedDirectory
        {
            get;
            set;
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ExecuteShouldThrowPackageNotFound()
        {
            new ConvertEcfElementStep<Package>("Package\\package.xml.invalid");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ExecuteShouldThrowXsltNotFound()
        {
            new ConvertEcfElementStep<Package>("Package\\package.xml", "template.xslt.invalid");
        }

        [TestMethod]
        public void ExecuteConvertPackage()
        {
            // Copy Package Stuff
            CopyPackageStep beginStep = new CopyPackageStep();

            string packageFile = "Package\\Package.xml";

            beginStep.PackageFile = Path.GetFullPath(packageFile);
            beginStep.ProcessDirectory = Path.GetFullPath("ConvertionTempTests");

            beginStep.Execute();

            ConvertEcfElementStep<Package> convertionStep = new ConvertEcfElementStep<Package>("ConvertionTempTests\\VS10TrainingKit\\Package.xml");

            convertionStep.Execute();

            // Test for HTML conversions
            Assert.IsTrue(File.Exists("ConvertionTempTests\\VS10TrainingKit\\Overview.html\\html\\docSet_default.html"), "Package Overview not converted");
            Assert.IsTrue(File.Exists("ConvertionTempTests\\VS10TrainingKit\\Assets\\Overviews\\ASPNET4\\ASPNET4 Overview.html\\html\\docSet_default.html"), "Unit Overview not converted");
            Assert.IsTrue(File.Exists("ConvertionTempTests\\VS10TrainingKit\\Labs\\Test\\Docs\\setup.html\\html\\docSet_default.html"), "Lab Setup not converted");
            Assert.IsTrue(File.Exists("ConvertionTempTests\\VS10TrainingKit\\Labs\\Test\\Docs\\test.html\\html\\docSet_default.html"), "Lab Doc not converted");
            
            // Test for MHT conversions
            Assert.IsTrue(File.Exists("ConvertionTempTests\\VS10TrainingKit\\Labs\\IntroToWF4.0\\Lab.mht"), "Lab Doc not converted");
            Assert.IsTrue(File.Exists("ConvertionTempTests\\VS10TrainingKit\\Labs\\IntroToWF4.0\\Setup.mht"), "Setup Doc not converted");

            // Prepare to delete resources
            this.LastCreatedDirectory = "ConvertionTempTests";
        }

        [TestMethod]
        public void ExecuteConvertSample()
        {
            // Copy Package Stuff
            CopySampleStep beginStep = new CopySampleStep();

            string sampleFile = @"Content\Samples\SampleTest\Sample.xml";

            beginStep.SampleManifestsFilePath = Path.GetFullPath(sampleFile);
            beginStep.OutputDirectory = Path.GetFullPath("ConvertionTempTests");

            beginStep.Execute();

            ConvertEcfElementStep<Sample> convertionStep = new ConvertEcfElementStep<Sample>("ConvertionTempTests\\Export_Points\\Sample.xml");

            convertionStep.Execute();

            // Test for HTML conversions            
            Assert.IsTrue(File.Exists("ConvertionTempTests\\Export_Points\\Test.html\\html\\docSet_default.html"), "Lab Doc not converted");

            // Test for MHT conversions
            Assert.IsTrue(File.Exists("ConvertionTempTests\\Export_Points\\TestSetup.mht"), "Setup Doc not converted");

            // Prepare to delete resources
            this.LastCreatedDirectory = "ConvertionTempTests";
        }

        [TestCleanup()]
        public void DeleteFolderCleanUp()
        {
            if (!String.IsNullOrEmpty(this.LastCreatedDirectory) && Directory.Exists(this.LastCreatedDirectory))
            {
                Directory.Delete(this.LastCreatedDirectory, true);
            }
        }
    }
}
