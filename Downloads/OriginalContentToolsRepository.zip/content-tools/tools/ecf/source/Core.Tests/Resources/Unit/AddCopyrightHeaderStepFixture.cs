﻿namespace ContentFramework.Core.Tests
{
    using System;
    using System.IO;
    using ContentFramework.Core.Steps;
    using ContentFramework.Core.Tests.Mocks;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class AddCopyrightHeaderStepFixture
    {
        [TestMethod]
        public void ExecuteShouldCallReadCopyrightFile()
        {
            MockAddCopyrightHeaderStep step = new MockAddCopyrightHeaderStep();
            step.Execute(Path.GetFullPath("Copyright.txt"), new string[] { });

            Assert.IsTrue(step.IsReadCopyrightFileCalled);
        }

        [TestMethod]
        public void ExecuteShouldCallApplyHeaders()
        {
            MockAddCopyrightHeaderStep step = new MockAddCopyrightHeaderStep();
            step.Execute(Path.GetFullPath("Copyright.txt"), new string[] { "somefile.cs" });

            Assert.IsTrue(step.IsApplyHeaderToFileCalled);
        }

        [TestMethod, ExpectedException(typeof(ArgumentNullException))]
        public void ExecuteShouldThrowException()
        {
            AddCopyrightHeaderStep step = new AddCopyrightHeaderStep();
            step.Execute(String.Empty, new string[] { });
        }
    }
}