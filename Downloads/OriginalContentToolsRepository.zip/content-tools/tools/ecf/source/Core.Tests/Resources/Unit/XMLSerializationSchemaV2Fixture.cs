﻿namespace ContentFramework.Core.Tests
{
    using System.IO;
    using System.Linq;
    using System.Runtime.Serialization;
    using ContentFramework.Core.Helpers;
    using ContentFramework.Core.Tests.Mocks;
    using ContentFramework.Model;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary> 
    /// Summary description for XMLSerializationFixture
    /// 
    ///
    /// </summary>
    [TestClass]
    public class XMLSerializationSchemaV2Fixture
    {
        [TestMethod]
        public void ShouldXMLDeserializeNewSimplifiedPackage()
        {
            XMLModelSerializer<Package> serializer = new XMLModelSerializer<Package>();

            object obj;
            using (FileStream file = new FileStream("schemas-v2\\Package-newSimplified.xml", FileMode.Open))
            {
                obj = serializer.Deserialize(file);
            }

            Assert.IsNotNull(obj);
            Assert.IsInstanceOfType(obj, typeof(Package));

            Package package = (Package)obj;

            // Check it contains units
            Assert.IsNotNull(package.Units);
            Assert.AreEqual(5, package.Units.Count);

            // check it contains prerequisites
            Assert.IsNotNull(package.PrerequisitesGroups);
            Assert.AreEqual(3, package.PrerequisitesGroups.First().Prerequisites.Count);
        }

        [TestMethod]
        public void ShouldXMLDeserializeNewPackage()
        {
            XMLModelSerializer<Package> serializer = new XMLModelSerializer<Package>();

             object obj;
             using (FileStream file = new FileStream("schemas-v2\\Package-new.xml", FileMode.Open))
             {
                 obj = serializer.Deserialize(file);
             }

            Assert.IsNotNull(obj);
            Assert.IsInstanceOfType(obj, typeof(Package));
            this.ShouldXMLDeserializeNewPackage((Package)obj);
        }

        [TestMethod]
        public void ShouldXMLDeserializeNewLab()
        {
            XMLModelSerializer<Lab> serializer = new XMLModelSerializer<Lab>();

            object obj;
            using (FileStream file = new FileStream("schemas-v2\\Lab-new.xml", FileMode.Open))
            {
               obj = serializer.Deserialize(file);
            }

            Assert.IsNotNull(obj);
            Assert.IsInstanceOfType(obj, typeof(Lab));

            Lab lab = (Lab)obj;

            Assert.IsNotNull(lab.Description);
            Assert.IsNotNull(lab.Document);
            Assert.IsNotNull(lab.Title);
            Assert.IsNotNull(lab.Version);
            Assert.IsNotNull(lab.Setup);
            Assert.IsNotNull(lab.Source);
            Assert.IsNotNull(lab.DependencyChecker);
            Assert.IsNotNull(lab.VirtualLab);
            Assert.IsNotNull(lab.Author);
            Assert.IsNotNull(lab.Author.Blog);
            Assert.IsNotNull(lab.Author.Email);
            Assert.IsNotNull(lab.Author.Name);
            Assert.IsNotNull(lab.Feedback);
        }

        [TestMethod]
        public void ShouldXMLDeserializeNewPresentation()
        {
            XMLModelSerializer<Presentation> serializer = new XMLModelSerializer<Presentation>();

            object obj = serializer.Deserialize(new FileStream("schemas-v2\\Presentation-new.xml", FileMode.Open));

            Assert.IsNotNull(obj);
            Assert.IsInstanceOfType(obj, typeof(Presentation));

            Presentation presentation = (Presentation)obj;

            Assert.IsNotNull(presentation.Description);
            Assert.IsNotNull(presentation.Author);
            Assert.IsNotNull(presentation.Author.Blog);
            Assert.IsNotNull(presentation.Author.Email);
            Assert.IsNotNull(presentation.Author.Name);
            Assert.IsNotNull(presentation.Document);
            Assert.IsNotNull(presentation.Title);
            Assert.IsNotNull(presentation.Version);

            // Document
            Assert.IsNotNull(presentation.Document);
            Assert.IsNotNull(presentation.Document.RemoveSpeakerNotes);
            Assert.IsFalse(presentation.Document.RemoveSpeakerNotes); 
        }

        [TestMethod]
        public void ShouldXMLDeserializeNewSample()
        {
            XMLModelSerializer<Sample> serializer = new XMLModelSerializer<Sample>();

            object obj = serializer.Deserialize(new FileStream("schemas-v2\\Sample-new.xml", FileMode.Open));

            Assert.IsNotNull(obj);
            Assert.IsInstanceOfType(obj, typeof(Sample));

            Sample sample = (Sample)obj;

            Assert.IsNotNull(sample.Description);
            Assert.IsNotNull(sample.Author);
            Assert.IsNotNull(sample.Author.Blog);
            Assert.IsNotNull(sample.Author.Email);
            Assert.IsNotNull(sample.Author.Name);
            Assert.IsNotNull(sample.Setup);
            Assert.IsNotNull(sample.Document);
            Assert.IsNotNull(sample.DependencyChecker);
            Assert.IsNotNull(sample.Title);
            Assert.IsNotNull(sample.Version);
        }

        [TestMethod]
        public void ShouldXMLDeserializeNewDemo()
        {
            XMLModelSerializer<Demo> serializer = new XMLModelSerializer<Demo>();

            object obj;
            using (FileStream file = new FileStream("schemas-v2\\Demo-new.xml", FileMode.Open))
            {
                obj = serializer.Deserialize(file);
            }

            Assert.IsNotNull(obj);
            Assert.IsInstanceOfType(obj, typeof(Demo));

            Demo demo = (Demo)obj;

            Assert.IsNotNull(demo.Description);
            Assert.IsNotNull(demo.Author);
            Assert.IsNotNull(demo.Author.Blog);
            Assert.IsNotNull(demo.Author.Email);
            Assert.IsNotNull(demo.Author.Name);
            Assert.IsNotNull(demo.Document);
            Assert.IsNotNull(demo.DependencyChecker);
            Assert.IsNotNull(demo.Setup);
            Assert.IsNotNull(demo.Title);
            Assert.IsNotNull(demo.Version);
        }

        [TestMethod]
        public void ShouldXMLSerializeToStream()
        {
            Unit unit = MockFactory.CreateUnit();

            XMLModelSerializer<Unit> serializer = new XMLModelSerializer<Unit>();
            Stream streamUnit = serializer.Serialize(unit);

            Package package = MockFactory.CreatePackage(new string[] { "VisualSourceSafe", "TFSIntro" });

            XMLModelSerializer<Package> packageSerializer = new XMLModelSerializer<Package>();
            Stream streamPackage = packageSerializer.Serialize(package);

            Assert.IsTrue(streamUnit.Length > 0);
            Assert.IsTrue(streamPackage.Length > 0);
        }

        [TestMethod]
        public void ShouldXMLDeserializeSerializeAndReserializePackage()
        {
            XMLModelSerializer<Package> serializer = new XMLModelSerializer<Package>();

            // Deserialize
            object obj;
            using (FileStream stream = new FileStream("schemas-v2\\Package-new.xml", FileMode.Open))
            {
                obj = serializer.Deserialize(stream);
            }

            Assert.IsNotNull(obj);
            Assert.IsInstanceOfType(obj, typeof(Package));

            Package package = (Package)obj;

            // Serialize
            XMLModelSerializer<Package> packageSerializer = new XMLModelSerializer<Package>();
            MemoryStream memoryStream = (MemoryStream)packageSerializer.Serialize(package);
            byte[] data = memoryStream.ToArray();

            using (FileStream writeStream = new FileStream("schemas-v2\\Package-new-serialized.xml", FileMode.Create, FileAccess.Write))
            {
                writeStream.Write(data, 0, data.Length);
                writeStream.Close();
            }

            // Re-Deserialize
            object objRemaked = serializer.Deserialize(new FileStream("schemas-v2\\Package-new-serialized.xml", FileMode.Open));

            Assert.IsNotNull(objRemaked);
            Assert.IsInstanceOfType(objRemaked, typeof(Package));

            Package packageRemaked = (Package)objRemaked;

            // run test for this package
            this.ShouldXMLDeserializeNewPackage(packageRemaked);
        }

        [TestMethod]
        public void ShouldDeserializeConversionTypeAttribute()
        {
            XMLModelSerializer<Demo> serializer = new XMLModelSerializer<Demo>();

            object obj;
            using (FileStream file = new FileStream("schemas-v2\\Demo-new.xml", FileMode.Open))
            {
                obj = serializer.Deserialize(file);
            }

            Assert.IsNotNull(obj);
            Assert.IsInstanceOfType(obj, typeof(Demo));

            XMLModelSerializer<Lab> labSerializer = new XMLModelSerializer<Lab>();

            object labObj;
            using (FileStream file = new FileStream("schemas-v2\\Lab-new.xml", FileMode.Open))
            {
                labObj = labSerializer.Deserialize(file);
            }

            Assert.IsNotNull(labObj);
            Assert.IsInstanceOfType(labObj, typeof(Lab));

            // Test for HTML Convertion Type
            Demo demo = (Demo) obj;
            Assert.AreEqual(ConversionType.Html, demo.Document.ConversionType, "Wrong document type Deserialized");
            Assert.AreEqual("Demos\\ExportPoints\\Docs\\ExportPointsScript.docx", demo.Document.RelativePath, "Wrong Path deserialized");
            Assert.AreEqual("Docs\\Setup.docx", demo.Setup.RelativePath, "Wrong Path deserialized");
            Assert.AreEqual(ConversionType.Html, demo.Setup.ConversionType, "Wrong Path deserialized");

            // Test for MHT Convertion Type
            Lab lab = (Lab)labObj;
            Assert.AreEqual(ConversionType.Mht, lab.Document.ConversionType, "Wrong document type Deserialized");
            Assert.AreEqual("Docs\\Digging.docx", lab.Document.RelativePath, "Wrong Path deserialized");            
        }

        [TestMethod]
        public void ShouldDeserializeCustomPropertiesInDemo()
        {
            XMLModelSerializer<Demo> serializer = new XMLModelSerializer<Demo>();

            object obj;
            using (FileStream file = new FileStream("schemas-v2\\Demo-new.xml", FileMode.Open))
            {
                obj = serializer.Deserialize(file);
            }

            Assert.IsNotNull(obj);
            Assert.IsInstanceOfType(obj, typeof(Demo));

            Demo demo = (Demo) obj;

            Assert.AreEqual("someValue", demo.CustomProperties["something"]);
            Assert.AreEqual("OtherValue", demo.CustomProperties["Common"]);            
        }

        [TestMethod]
        public void ShouldDeserializeCustomPropertiesInPackage()
        {
            XMLModelSerializer<Package> serializer = new XMLModelSerializer<Package>();

            object obj;
            using (FileStream file = new FileStream("schemas-v2\\Package-new.xml", FileMode.Open))
            {
                obj = serializer.Deserialize(file);
            }

            Assert.IsNotNull(obj);
            Assert.IsInstanceOfType(obj, typeof(Package));

            Package package = (Package)obj;

            Assert.AreEqual("SomeValue", package.CustomProperties["SomeName"]);
            Assert.AreEqual("SomeValue2", package.CustomProperties["SomeName2"]);
            
            // in units
            Assert.AreEqual("SomeValueForUnit", package.Units.First().CustomProperties["SomeNameForUnit"]);
            Assert.AreEqual("SomeValueForUnit4", package.Units.First().CustomProperties["SomeNameForUnit4"]);            
        }

        [TestMethod]
        public void ShouldDeserializeIds()
        {
            // Deserialize Hole Package
            MetadataHelper packageHelper = new MetadataHelper();
            Package package = packageHelper.ReadMetadata("Package\\package.xml");
            
            // Package & Unit
            Assert.AreEqual("VS10TrainingKit", package.Id);
            Unit firstUnit = package.Units.First();
            Assert.AreEqual("ASPNET4", firstUnit.Id);

            // Labs & Demos            
            Assert.AreEqual("Export_Points", firstUnit.Demos.First().Id);
            Assert.AreEqual("Introduction_to_Workflow_4.0", firstUnit.Labs.First().Id);            
        }

        [TestMethod]
        [ExpectedException(typeof(SerializationException))]
        public void ShouldThrowSerializationException()
        {
            try
            {
                // Deserialize Hole Package
                MetadataHelper packageHelper = new MetadataHelper();
                Package package = packageHelper.ReadMetadata("schemas-v2\\MalFormedPackage.xml");
            }
            catch (SerializationException e)
            {
                Assert.IsTrue(e.Message.Contains(":\\")); // Check message includes full path of file
                throw;
            }            
        }

        private void ShouldXMLDeserializeNewPackage(Package package)
        {
            // Package Properties
            Assert.IsNotNull(package.Id);
            Assert.IsNotNull(package.Name);
            Assert.IsNotNull(package.Description);
            Assert.IsNotNull(package.Overview);

            // Prerequisites
            Assert.AreEqual(2, package.PrerequisitesGroups.Count);
            PrerequisitesGroup firstGroup = package.PrerequisitesGroups.First();
            Assert.AreEqual(3, firstGroup.Prerequisites.Count);
            Assert.AreEqual(1, firstGroup.Order);
            Assert.AreEqual("Microsoft Windows Vista or Windows Server 2008", firstGroup.Prerequisites.First().Name);
            
            // Units
            Assert.IsNotNull(package.Units);
            Assert.AreEqual(5, package.Units.Count);
                        
            Unit unit = (Unit)package.Units[0];

            Assert.IsNotNull(unit.Overview);

            Assert.IsNotNull(unit.LabDirectories);
            Assert.IsNotNull(unit.PresentationDirectories);
            Assert.IsNotNull(unit.DemoDirectories);
            Assert.IsNotNull(unit.SampleDirectories);

            Assert.AreEqual(2, unit.LabDirectories.Count);
            Assert.AreEqual(2, unit.PresentationDirectories.Count);
            Assert.AreEqual(2, unit.DemoDirectories.Count);
            Assert.AreEqual(1, unit.SampleDirectories.Count);
            Assert.AreEqual(2, unit.VideoDirectories.Count);

            // Lab contents
            Assert.AreEqual(unit.LabDirectories[0], "ASPNETAJAX");
            Assert.AreEqual(unit.LabDirectories[1], "ASPNETMVCDynamicData2");

            // Sample contents
            Assert.AreEqual(unit.SampleDirectories[0], "..\\Something\\Something");

            // Videos contents
            Assert.AreEqual(unit.VideoDirectories[0], "ASPNETAJAXVideo");
            Assert.AreEqual(unit.VideoDirectories[1], "ASPNETMVCDynamicData2Video");
            
            // Other Unit 
            Unit unit5 = (Unit)package.Units[4];
            Assert.AreEqual(unit5.Id, "Velocity");
            Assert.AreEqual(unit5.Overview.Author.Name, "Ray Ozzie");

            Assert.AreEqual(unit5.DemoDirectories.Count, 1);
            Assert.AreEqual(unit5.DemoDirectories[0], "Velocity");
        }
    }
}
