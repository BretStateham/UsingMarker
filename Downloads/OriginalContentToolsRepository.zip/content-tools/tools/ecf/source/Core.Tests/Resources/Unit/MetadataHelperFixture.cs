﻿namespace ContentFramework.Core.Tests
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;

    using ContentFramework.Core.Helpers;
    using ContentFramework.Model;

    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System.Text.RegularExpressions;

    /// <summary>
    /// Summary description for DataContractSerializationFixture
    /// </summary>
    [TestClass]
    public class MetadataHelperFixture
    {
        [TestMethod]
        public void ShouldDeserializeTestPackage()
        {
            MetadataHelper helper = new MetadataHelper();

            Package package = helper.ReadMetadata(@"Package\Package.Full.xml");

            Assert.IsNotNull(package);
            Assert.IsNotNull(package.Units);
            Assert.AreEqual(1, package.Units.Count);

            Unit unit = package.Units[0];

            Assert.IsNotNull(unit.LabDirectories);
            Assert.AreEqual(2, unit.LabDirectories.Count);

            Assert.IsFalse(package.DemoCount == 0);
            Assert.IsFalse(package.PresentationCount == 0);

            Assert.IsNotNull(unit.Labs);
            Assert.AreEqual(2, unit.Labs.Count);
            Assert.IsNotNull(unit.Labs[0].OriginalDirectory);

            Assert.IsNotNull(unit.DemoDirectories);
            Assert.AreEqual(2, unit.DemoDirectories.Count);

            Assert.IsNotNull(unit.Demos);
            Assert.AreEqual(2, unit.Demos.Count);
            Assert.IsNotNull(unit.Demos[0].OriginalDirectory);

            Assert.IsNotNull(unit.PresentationDirectories);
            Assert.AreEqual(1, unit.PresentationDirectories.Count);

            Assert.IsNotNull(unit.Presentations);
            Assert.AreEqual(1, unit.Presentations.Count);
            Assert.IsNotNull(unit.Presentations[0].OriginalDirectory);

            Assert.IsNotNull(unit.SampleDirectories);
            Assert.AreEqual(2, unit.SampleDirectories.Count);

            Assert.IsNotNull(unit.Samples);
            Assert.AreEqual(2, unit.Samples.Count);
            Assert.IsNotNull(unit.Samples[0].OriginalDirectory);

            // Videos
            Assert.IsNotNull(unit.VideoDirectories);
            Assert.AreEqual(2, unit.VideoDirectories.Count);

            Assert.IsNotNull(unit.Videos);
            Assert.AreEqual(2, unit.Videos.Count);
            Assert.IsNotNull(unit.Videos[0].VideoUrl);
            Assert.IsNotNull(unit.Videos[1].VideoUrl);
            Assert.IsNotNull(unit.Videos[1].Title);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ShouldDeserializeFailWithoutParameters()
        {
            MetadataHelper helper = new MetadataHelper();

            Package package = helper.ReadMetadata(null);

            Assert.IsNotNull(package);
        }

        [TestMethod]
        [ExpectedException(typeof(DirectoryNotFoundException))]
        public void ShouldDeserializeFailWithWrongPath()
        {
            MetadataHelper helper = new MetadataHelper();

            Package package = helper.ReadMetadata(@"NonExistingDirectory\Package.xml");

            Assert.IsNotNull(package);
        }

        [TestMethod]        
        public void ShouldDeserializeEachContentTypeFromReadEcf()
        {
            MetadataHelper helper = new MetadataHelper();

            EcfElement ecfElement = helper.ReadEcfElement(@"Package\Package.Full.xml");
            Assert.IsInstanceOfType(ecfElement, typeof(Package));

            ecfElement = helper.ReadEcfElement(@"Content\Samples\SampleTest\Sample.xml");
            Assert.IsInstanceOfType(ecfElement, typeof(Sample));

            ecfElement = helper.ReadEcfElement(@"Content\Labs\Test\Lab.xml");
            Assert.IsInstanceOfType(ecfElement, typeof(Lab));

            ecfElement = helper.ReadEcfElement(@"Content\Demos\ExportPoints\Demo.xml");
            Assert.IsInstanceOfType(ecfElement, typeof(Demo));

            ecfElement = helper.ReadEcfElement(@"Content\Presentations\LapAroundMEF\Presentation.xml");
            Assert.IsInstanceOfType(ecfElement, typeof(Presentation));

            ecfElement = helper.ReadEcfElement(@"Content\Videos\Maestro\Video.xml");
            Assert.IsInstanceOfType(ecfElement, typeof(Video));
        }

        [TestMethod]
        public void ShouldReplaceAssetPaths()
        {
            MetadataHelper helper = new MetadataHelper();

            var path = Path.GetFullPath("PackageResources.xml");
            var expected = File.ReadAllText(Path.GetFullPath("PackageAssets.xml"));
            
            helper.UpdateAssetPaths(path, "Resources\\");
            var result = File.ReadAllText(Path.GetFullPath("PackageResources.xml"));

            Assert.AreEqual(expected, result);
        }
    }
}
