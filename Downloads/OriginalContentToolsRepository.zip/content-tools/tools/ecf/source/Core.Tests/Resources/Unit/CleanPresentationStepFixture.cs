﻿namespace ContentFramework.Core.Tests
{
    using System;
    using System.IO;
    using System.Linq;
    using ContentFramework.Core.Steps;
    using DocumentFormat.OpenXml.Packaging;
    using DocumentFormat.OpenXml.Presentation;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class CleanPresentationStepFixture
    {
        [TestMethod]
        public void ShouldDeleteCommentsAndSpeakerNotesInPresentation()
        {
            string presentationFile = @".\Presentations\sampleDeck.pptx";

            CleanPresentationStep step = new CleanPresentationStep(presentationFile);
            step.Execute();

            CheckPresentationIsClean(presentationFile);
        }

        [TestMethod]
        public void ShouldDeleteCommentsAndSpeakerNotesInPackage()
        {
            string packageFile = @"PublishPackage\package.xml";

            CleanPresentationStep step = new CleanPresentationStep();
            step.PackageMetadataFile = packageFile;
            step.Execute();

            string presentationFile = @"PublishPackage\Presentations\Presentation1\LapAroundMEF1.pptx";

            CheckPresentationIsClean(presentationFile);
            bool shouldAssert = true;
            Exception exception = null;
            try
            {
                presentationFile = @"PublishPackage\Presentations\Presentation2\LapAroundMEF2.pptx";
                CheckPresentationIsClean(presentationFile);
            }
            catch (AssertFailedException e)
            {
                exception = e;
                shouldAssert = false;
            }

            Assert.IsFalse(shouldAssert, "presentation 2 was cleaned!", exception);
        }

        [TestMethod]
        [ExpectedException(typeof(FileNotFoundException))]
        public void ShouldFailWithWrongPresentationFile()
        {
            string presentationFile = @".\Presentations\non-existent.pptx";

            CleanPresentationStep step = new CleanPresentationStep(presentationFile);
            step.Execute();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ShouldFailWithEmptyPresentationFile()
        {
            CleanPresentationStep step = new CleanPresentationStep(String.Empty);
            step.Execute();
        }

        private static void CheckPresentationIsClean(string presentationFile)
        {
            using (PresentationDocument doc = PresentationDocument.Open(presentationFile, true))
            {
                if (doc.PresentationPart.GetPartsOfType<CommentAuthorsPart>().Count() > 0)
                {
                    // Get the authors part.
                    CommentAuthorsPart authorsPart = doc.PresentationPart.GetPartsOfType<CommentAuthorsPart>().First();

                    // Get the comment authors.
                    var commentAuthorList = authorsPart.CommentAuthorList.Elements<CommentAuthor>();

                    Assert.AreEqual(0, commentAuthorList.Count());
                }

                // Iterate through all the slides and get the slide parts.
                foreach (var slide in doc.PresentationPart.SlideParts)
                {
                    var slideNotesPart = slide.GetPartsOfType<NotesSlidePart>();

                    Assert.AreEqual(0, slideNotesPart.Count());
                }
            }
        }
    }
}
