﻿namespace ContentFramework.Core.Tests
{
    using System;
    using System.Collections.ObjectModel;
    using ContentFramework.Core.Models;
    using ContentFramework.Core.Steps;
    using ContentFramework.Core.Tests.Mocks;
    using ContentFramework.Model;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class PublishPackageStepFixture
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ExecuteShouldThrowPackageNotFound()
        {
            TestablePublishPackageStep step = new TestablePublishPackageStep(MockMetaWeblogData.Url, MockMetaWeblogData.User, MockMetaWeblogData.Password);
            step.PackageXmlFile = "ConvertedDocuments\\inexistentXmlFile.xml";

            step.Execute();
        }
        
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ExecuteShouldThrowPersistenceFileNotFound()
        {
            TestablePublishPackageStep step = new TestablePublishPackageStep(MockMetaWeblogData.Url, MockMetaWeblogData.User, MockMetaWeblogData.Password);
            step.PackageXmlFile = "ConvertedDocuments\\Lab\\Lab.xml";
            step.PersistedPostsFile = "ConvertedDocuments\\inexistentPersistenceFile.xml";

            step.Execute();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ExecuteShouldThrowXsltPathNotFound()
        {
            TestablePublishPackageStep step = new TestablePublishPackageStep(MockMetaWeblogData.Url, MockMetaWeblogData.User, MockMetaWeblogData.Password);
            step.PackageXmlFile = "ConvertedDocuments\\Lab\\Lab.xml";
            step.XsltPath = "ConvertedDocuments\\InexistentXsltFolder";

            step.Execute();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ExecuteShouldThrowTemplateFileNotFound()
        {
            TestablePublishPackageStep step = new TestablePublishPackageStep(MockMetaWeblogData.Url, MockMetaWeblogData.User, MockMetaWeblogData.Password);
            step.PackageXmlFile = "ConvertedDocuments\\inexistentXmlFile.xml";
            step.XsltPath = "ConvertedDocuments\\InexistentXsltFolder";
            step.PostLabTemplateFile = "ConvertedDocuments\\InexistentTemplateFile.tt";
            step.Execute();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ExecuteShouldThrowPackageNotSpecified()
        {
            TestablePublishPackageStep step = new TestablePublishPackageStep(MockMetaWeblogData.Url, MockMetaWeblogData.User, MockMetaWeblogData.Password);
            step.PackageXmlFile = string.Empty;

            step.Execute();
        }

        [TestMethod]        
        public void ExecuteCallPublishForEachLab()
        {
            string packageXmlFile = "PublishPackage\\Package.xml";

            TestablePublishPackageStep step = new TestablePublishPackageStep(MockMetaWeblogData.Url, MockMetaWeblogData.User, MockMetaWeblogData.Password);
            step.PackageXmlFile = packageXmlFile;

            step.Execute();

            Assert.AreEqual(3, step.AmoutOfLabsPublished);
        }

        [TestMethod]
        public void ExecuteCallPublishForEachPresentation()
        {
            string packageXmlFile = "PublishPackage\\Package.xml";

            TestablePublishPackageStep step = new TestablePublishPackageStep(MockMetaWeblogData.Url, MockMetaWeblogData.User, MockMetaWeblogData.Password);
            step.PackageXmlFile = packageXmlFile;

            step.Execute();

            Assert.AreEqual(4, step.AmoutOfPresentationsPublished);
        }

        [TestMethod]
        public void ExecuteCallPublishForEachVideo()
        {
            string packageXmlFile = "PublishPackage\\Package.xml";

            TestablePublishPackageStep step = new TestablePublishPackageStep(MockMetaWeblogData.Url, MockMetaWeblogData.User, MockMetaWeblogData.Password);
            step.PackageXmlFile = packageXmlFile;

            step.Execute();

            Assert.AreEqual(4, step.AmoutOfVideosPublished);
        }
        
        private class TestablePublishPackageStep : PublishPackageStep
        {
            public TestablePublishPackageStep(Uri url, string user, string password)
                : base(url, user, password, false)
            {
            }

            public int AmoutOfLabsPublished
            {
                get;
                set;
            }

            public int AmoutOfPresentationsPublished
            {
                get;
                set;
            }

            public int AmoutOfVideosPublished
            {
                get;
                set;
            }

            protected override void InitializeEmptyLabPosts(PublishLabStep publishLabStep)
            {
                this.AmoutOfLabsPublished++;
                base.InitializeEmptyLabPosts(new MockPublishLabStep());                
            }

            protected override void InitializeEmptyPresentationPosts(PublishPresentationStep publishLabStep)
            {
                this.AmoutOfPresentationsPublished++;
                base.InitializeEmptyPresentationPosts(new MockPublishPresentationStep());
            }

            protected override void InitializeEmptyVideoPosts(PublishVideoStep publishVideoStep)
            {
                this.AmoutOfVideosPublished++;
                base.InitializeEmptyVideoPosts(new MockPublishVideoStep());
            }

            protected override Collection<PublishedPost> PublishLabContents(PublishLabStep step)
            {
                return base.PublishLabContents(new MockPublishLabStep());
            }

            protected override PublishedPost PublishVideoContents(PublishVideoStep step)
            {
                return base.PublishVideoContents(new MockPublishVideoStep());
            }

            protected override PublishedPost PublishPresentationContents(PublishPresentationStep step)
            {
                return base.PublishPresentationContents(new MockPublishPresentationStep());
            }            
        }

        private class MockPublishLabStep : PublishLabStep
        {
            public MockPublishLabStep() : base(null)
            {
            }

            public override void InitializeEmptyPosts()
            {
                // DO Nothing
            }

            public override Collection<PublishedPost> PublishContents()
            {
                // DO Nothing 
                return new Collection<PublishedPost>();
            }
        }

        private class MockPublishPresentationStep : PublishPresentationStep
        {
            public MockPublishPresentationStep()
                : base(null)
            {
            }

            public override void InitializeEmptyPosts()
            {
                // DO Nothing                
            }

            public override PublishedPost PublishContents()
            {
                // DO Nothing 
                return new PublishedPost(null, null, null, true);
            }
        }

        private class MockPublishVideoStep : PublishVideoStep
        {
            public MockPublishVideoStep()
                : base(null)
            {
            }

            public override void InitializeEmptyPosts()
            {
                // DO Nothing                
            }

            public override PublishedPost PublishContents()
            {
                // DO Nothing 
                return new PublishedPost(null, null, null, true);
            }
        }
    }
}
