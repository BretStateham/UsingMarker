﻿namespace ContentFramework.Core.Tests
{
    using System;
    using System.IO;
    using ContentFramework.Core.Helpers;
    using ContentFramework.Core.Steps;
    using ContentFramework.Core.Tests.Mocks;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class PublishHtmlStepFixture
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ExecuteShouldThrowHtmlFileNotFound()
        {
            PublishHtmlStep step = new PublishHtmlStep(null);
            step.HtmlFile = "ConvertedDocuments\\inexistentHtmlFile.html";
            step.Execute();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ExecuteShouldThrowHtmlFileNotSpecified()
        {
            PublishHtmlStep step = new PublishHtmlStep(null);
            step.HtmlFile = string.Empty;
            step.Execute();
        }

        [TestMethod]        
        public void ShouldPublishHtmlContent()
        {
            // Create step
            MockPostPublisher mockPublisher = new MockPostPublisher(string.Empty, string.Empty, string.Empty, false);
            PublishHtmlStep step = new PublishHtmlStep(mockPublisher);
            
            step.HtmlFile = "htmlDocument.html";
            step.ImagesFolders = "images";

            step.Execute();

            Assert.AreEqual("Title", mockPublisher.PostTitle);
            Assert.AreEqual("<p>Hello World</p><img src=\"http://tempuri/sampleImage.jpg\" />", mockPublisher.PostContent);
        }
    }
}
