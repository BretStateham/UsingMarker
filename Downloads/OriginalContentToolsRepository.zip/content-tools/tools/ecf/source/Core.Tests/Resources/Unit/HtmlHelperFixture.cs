﻿namespace ContentFramework.Core.Tests
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using ContentFramework.Core.Helpers;
    using ContentFramework.Core.Models;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class HtmlHelperFixture
    {
        [TestMethod]
        public void ShouldGetText()
        {
            Assert.AreEqual("Only Text", HtmlHelper.GetInnerHtml("Only Text", String.Empty));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ShouldRaiseExceptionIfContentIsNull()
        {
            Assert.AreEqual(null, HtmlHelper.GetInnerHtml(null, String.Empty));
        }

        [TestMethod]
        public void ShouldGetBodyContent()
        {
            Assert.AreEqual("Only Text", HtmlHelper.GetBodyContent("<body>Only Text</body>"));
        }

        [TestMethod]
        public void ShouldGetTitleContent()
        {
            Assert.AreEqual("My Title", HtmlHelper.GetTitleContent("<html><head><title>My Title</title></head><body>Only Text</body>"));
        }
    }
}
