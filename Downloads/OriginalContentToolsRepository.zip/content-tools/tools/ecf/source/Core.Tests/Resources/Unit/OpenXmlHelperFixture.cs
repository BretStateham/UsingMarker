﻿namespace ContentFramework.Core.Tests
{
    using System.IO;
    using System.Linq;
    using ContentFramework.Core.Helpers;
    using DocumentFormat.OpenXml.Packaging;
    using DocumentFormat.OpenXml.Presentation;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class OpenXmlHelperFixture
    {
        [TestMethod]
        public void ShouldDeleteCommentsInPresentation()
        {
            string presentationFile = @".\Presentations\sampleDeck.pptx";

            OpenXmlHelper.RemoveCommentsFromPresentation(presentationFile);

            using (PresentationDocument doc = PresentationDocument.Open(presentationFile, true))
            {
                // Get the authors part.
                CommentAuthorsPart authorsPart = doc.PresentationPart.CommentAuthorsPart;

                if (authorsPart != null)
                {
                    // Get the comment authors.
                    var commentAuthorList = authorsPart.CommentAuthorList.Elements<CommentAuthor>();

                    Assert.AreEqual(0, commentAuthorList.Count());
                }
            }
        }

        [TestMethod]
        public void ShouldDeleteSpeakerNotesInPresentation()
        {
            string presentationFile = @".\Presentations\sampleDeck.pptx";

            OpenXmlHelper.RemoveSpeakerNotesFromPresentation(presentationFile);

            using (PresentationDocument doc = PresentationDocument.Open(presentationFile, true))
            {
                // Iterate through all the slides and get the slide parts.
                foreach (var slide in doc.PresentationPart.SlideParts)
                {
                    var slideNotesPart = slide.GetPartsOfType<NotesSlidePart>();

                    Assert.AreEqual(0, slideNotesPart.Count());
                }               
            }
        }

        [TestMethod]
        public void ShouldGetThumbnailFromPresentation()
        {
            string presentationFile = @".\Presentations\sampleDeck.pptx";

            string thumbnailPath = Path.Combine(Path.GetDirectoryName(presentationFile), Path.GetFileNameWithoutExtension(presentationFile) + "_pptx.jpg");

            OpenXmlHelper.SaveThumbnailFromPresentation(presentationFile, thumbnailPath);

            Assert.IsTrue(File.Exists(thumbnailPath));

            using (PresentationDocument doc = PresentationDocument.Open(presentationFile, true))
            {
                var thumbnailPart = doc.GetPartsOfType<ThumbnailPart>();

                var stream = doc.ThumbnailPart.GetStream();

                Assert.AreEqual(stream.Length, File.ReadAllBytes(thumbnailPath).Length);                
            }
        }

        [TestMethod]
        public void ShouldGetThumbnailFromPresentationSlide()
        {
            string presentationFile = @".\Presentations\sampleDeck.pptx";

            string thumbnailPath = Path.Combine(Path.GetDirectoryName(presentationFile), Path.GetFileNameWithoutExtension(presentationFile) + "_pptx.jpg");

            OpenXmlHelper.SaveThumbnailFromPresentation(presentationFile, 2, thumbnailPath);

            Assert.IsTrue(File.Exists(thumbnailPath));
            Assert.IsTrue(File.ReadAllBytes(thumbnailPath).Length > 3000);
        }
    }
}
