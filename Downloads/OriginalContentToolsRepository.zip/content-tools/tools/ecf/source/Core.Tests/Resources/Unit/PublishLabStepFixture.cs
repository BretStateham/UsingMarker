﻿namespace ContentFramework.Core.Tests
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using ContentFramework.BlogPublisher;
    using ContentFramework.BlogPublisher.Helpers;
    using ContentFramework.BlogPublisher.Model;
    using ContentFramework.Core.Helpers;
    using ContentFramework.Core.Steps;
    using ContentFramework.Core.Tests.Mocks;
    using ContentFramework.Model;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class PublishLabStepFixture
    {
        [ClassCleanup()]
        public static void ClassCleanUp()
        {
            if (MockMetaWeblogData.IsMockBlog)
            {
                WebServerHelper.StopWebServer();
            }
        }

        [ClassInitialize()]
        public static void ClassInitialize(TestContext context)
        {
            if (MockMetaWeblogData.IsMockBlog)
            {
                WebServerHelper.StartWebServer();
            }
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ExecuteShouldThrowLabNotFound()
        {
            TestablePublishLabStep step = new TestablePublishLabStep(MockMetaWeblogData.Url, MockMetaWeblogData.User, MockMetaWeblogData.Password);
            step.LabXmlFile = "ConvertedDocuments\\inexistentXmlFile.xml";

            step.Execute();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ExecuteShouldThrowPersistenceFileNotFound()
        {
            TestablePublishLabStep step = new TestablePublishLabStep(MockMetaWeblogData.Url, MockMetaWeblogData.User, MockMetaWeblogData.Password);
            step.LabXmlFile = "ConvertedDocuments\\Lab\\Lab.xml";
            step.PersistedPostsFile = "ConvertedDocuments\\inexistentPersistenceFile.xml";

            step.Execute();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ExecuteShouldThrowXsltPathNotFound()
        {
            TestablePublishLabStep step = new TestablePublishLabStep(MockMetaWeblogData.Url, MockMetaWeblogData.User, MockMetaWeblogData.Password);
            step.LabXmlFile = "ConvertedDocuments\\Lab\\Lab.xml";
            step.XsltPath = "ConvertedDocuments\\InexistentXsltFolder";

            step.Execute();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ExecuteShouldThrowLabNotSpecified()
        {
            TestablePublishLabStep step = new TestablePublishLabStep(MockMetaWeblogData.Url, MockMetaWeblogData.User, MockMetaWeblogData.Password);
            step.LabXmlFile = string.Empty;

            step.Execute();
        }

        [TestMethod]
        public void ShouldPublishEmptyPosts()
        {
            string labXmlFile = "ConvertedDocuments\\Lab\\Lab.xml";

            // Deserialize Lab
            MetadataHelper packageHelper = new MetadataHelper();
            Lab lab = packageHelper.ReadLab(labXmlFile); 

            // Create step
            TestablePublishLabStep step = new TestablePublishLabStep(MockMetaWeblogData.Url, MockMetaWeblogData.User, MockMetaWeblogData.Password);
            step.LabXmlFile = labXmlFile;

            DocumentTopic[] convertedTopics = new DocumentTopic[]
            {
               new DocumentTopic("ConvertedDocuments\\Lab\\Lab.html\\html\\docSet_default.html"), 
               new DocumentTopic("ConvertedDocuments\\Lab\\Lab.html\\html\\docSet_b285d31a-9cff-4c03-9af7-cbf53da0445e.html"),
               new DocumentTopic("ConvertedDocuments\\Lab\\Lab.html\\html\\docSet_64826467-7197-4a65-9537-9f4fbee63a1b.html") 
            };

            lab.Document.Topics.AddRange(convertedTopics);
            step.Lab = lab;

            // Publish empty posts
            step.CallInitializePosts();
            Dictionary<string, PublishedPost> postedPosts = step.GetPublishedPosts();

            // test things have been published
            Assert.AreEqual(3, postedPosts.Count);
            Assert.IsNotNull(postedPosts[convertedTopics[0].Location].PostId);
            Assert.IsNotNull(postedPosts[convertedTopics[0].Location].PostUri);
            Assert.IsNotNull(postedPosts[convertedTopics[1].Location].PostId);
            Assert.IsNotNull(postedPosts[convertedTopics[1].Location].PostUri);
            Assert.IsNotNull(postedPosts[convertedTopics[2].Location].PostId);
            Assert.IsNotNull(postedPosts[convertedTopics[2].Location].PostUri);

            // Delete posts
            MetaWeblogHelper helper = new MetaWeblogHelper(MockMetaWeblogData.Url.ToString());
            foreach (var value in postedPosts.Values)
            {
                // create the publisher
                Assert.IsTrue(helper.DeletePost(String.Empty, value.PostId, MockMetaWeblogData.User, MockMetaWeblogData.Password, false));                
            }
        }

        [TestMethod]        
        public void ShouldPublishPostsContent()
        {
            string labXmlFile = "ConvertedDocuments\\Lab\\Lab.xml";

            // Deserialize Lab
            MetadataHelper packageHelper = new MetadataHelper();
            Lab lab = packageHelper.ReadLab(labXmlFile);

            // Create step
            TestablePublishLabStep step = new TestablePublishLabStep(MockMetaWeblogData.Url, MockMetaWeblogData.User, MockMetaWeblogData.Password);
            step.LabXmlFile = labXmlFile;
            step.PostTemplateFile = "PublishLab\\DocumentPost.tt";

            DocumentTopic[] convertedTopics = new DocumentTopic[]
            {
               new DocumentTopic("ConvertedDocuments\\Lab\\Lab.html\\html\\docSet_default.html"), 
               new DocumentTopic("ConvertedDocuments\\Lab\\Lab.html\\html\\docSet_b285d31a-9cff-4c03-9af7-cbf53da0445e.html"),
               new DocumentTopic("ConvertedDocuments\\Lab\\Lab.html\\html\\docSet_64826467-7197-4a65-9537-9f4fbee63a1b.html") 
            };

            lab.Document.Topics.AddRange(convertedTopics);
            step.Lab = lab;

            // Publish empty posts
            step.CallInitializePosts();
            Dictionary<string, PublishedPost> postedPosts = step.GetPublishedPosts();

            step.CallPublishPostsContent(lab, postedPosts);

            MetaWeblogHelper helper = new MetaWeblogHelper(MockMetaWeblogData.Url.ToString());

            // Check the posted content
            bool contentPosted = true;
            foreach (string htmlFile in postedPosts.Keys)
            {
                Post post = helper.GetPost(postedPosts[htmlFile].PostId, MockMetaWeblogData.User, MockMetaWeblogData.Password);

                contentPosted &= post.description.Contains("Lorem ipsum");

                Assert.IsTrue(helper.DeletePost(String.Empty, postedPosts[htmlFile].PostId, MockMetaWeblogData.User, MockMetaWeblogData.Password, false));
            }

             Assert.IsTrue(contentPosted);
        }

        [TestMethod]
        public void ShouldGetPersistenceFileNameIncrementedByOne()
        {
            // Create step
            TestablePublishLabStep step = new TestablePublishLabStep(MockMetaWeblogData.Url, MockMetaWeblogData.User, MockMetaWeblogData.Password);
            step.LabXmlFile = "PublishedPosts\\Lab.xml";

            // find the number
            short number;
            string numberStr = Path.GetFileName(step.PersistenceFile);
            numberStr = numberStr.Substring("publishedPosts".Length, 1);
            Int16.TryParse(numberStr, out number);

            Assert.IsTrue(number >= 1, "Persistence file not created or bad name");           
        }

        [TestMethod]
        public void ShouldGetPersistenceFileNameFromPersistedPostsFileProperty()
        {
            // Create step
            TestablePublishLabStep step = new TestablePublishLabStep(MockMetaWeblogData.Url, MockMetaWeblogData.User, MockMetaWeblogData.Password);
            step.LabXmlFile = "PublishedPosts\\Lab.xml";
            step.PersistedPostsFile = "PublishedPosts\\publishedPosts.xml";

            Assert.AreEqual("PublishedPosts\\publishedPosts.xml", step.PersistenceFile);
        }
        
        private class TestablePublishLabStep : PublishLabStep
        {
            public TestablePublishLabStep(Uri url, string user, string password)
                : base(url, user, password, false)
            {
            }

            public TestablePublishLabStep(PostPublisher publisher)
                : base(publisher)
            {
            }

            public Dictionary<string, PublishedPost> GetPublishedPosts()
            {
                return this.PublishedPosts;
            }

            public void CallInitializePosts()
            {
                this.InitializePosts();
            }

            public void CallPublishPostsContent(Lab lab, Dictionary<string, PublishedPost> publishedPosts)
            {
                this.PublishPostsContent(lab, publishedPosts);
            }
        }
    }
}
