﻿namespace ContentFramework.Core.Tests
{
    using System;
    using System.IO;
    using ContentFramework.BlogPublisher;
    using ContentFramework.BlogPublisher.Helpers;
    using ContentFramework.BlogPublisher.Model;
    using ContentFramework.Core.Helpers;
    using ContentFramework.Core.Steps;
    using ContentFramework.Core.Tests.Mocks;
    using ContentFramework.Model;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class PublishPresentationStepFixture
    {
        [ClassCleanup()]
        public static void ClassCleanUp()
        {
            if (MockMetaWeblogData.IsMockBlog)
            {
                WebServerHelper.StopWebServer();
            }
        }

        [ClassInitialize()]
        public static void ClassInitialize(TestContext context)
        {
            if (MockMetaWeblogData.IsMockBlog)
            {
                WebServerHelper.StartWebServer();
            }
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ExecuteShouldThrowPresentationNotFound()
        {
            PublishPresentationStep step = new PublishPresentationStep(MockMetaWeblogData.Url, MockMetaWeblogData.User, MockMetaWeblogData.Password, false);
            step.PresentationXmlFile = "ConvertedDocuments\\inexistentXmlFile.xml";

            step.Execute();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ExecuteShouldThrowPersistenceFileNotFound()
        {
            PublishPresentationStep step = new PublishPresentationStep(MockMetaWeblogData.Url, MockMetaWeblogData.User, MockMetaWeblogData.Password, false);
            step.PresentationXmlFile = "PublishedPosts\\Presentation.xml";
            step.PersistedPostsFile = "ConvertedDocuments\\inexistentPersistenceFile.xml";

            step.Execute();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ExecuteShouldThrowPresentationNotSpecified()
        {
            PublishPresentationStep step = new PublishPresentationStep(MockMetaWeblogData.Url, MockMetaWeblogData.User, MockMetaWeblogData.Password, false);
            step.PresentationXmlFile = string.Empty;

            step.Execute();
        }        

        [TestMethod]        
        public void ShouldPublishPostsContent()
        {
            // Create step
            PublishPresentationStep step = new PublishPresentationStep(MockMetaWeblogData.Url, MockMetaWeblogData.User, MockMetaWeblogData.Password, false);
            step.PresentationXmlFile = "PublishPresentation\\Presentation.xml";
            step.PostTemplateFile = "PublishPresentation\\PresentationPost.tt";

            // Publish Posts content
            PublishedPost publishedPost = step.Execute();

            MetaWeblogHelper helper = new MetaWeblogHelper(MockMetaWeblogData.Url.ToString());

            Post post = helper.GetPost(publishedPost.PostId, MockMetaWeblogData.User, MockMetaWeblogData.Password);           

            // Delete Post
            Assert.IsTrue(helper.DeletePost(String.Empty, publishedPost.PostId, MockMetaWeblogData.User, MockMetaWeblogData.Password, false));

            // Check the posted content
            Assert.IsTrue(post.description.Contains("This is the Presentation Description"));

            // Check the post title
            Assert.AreEqual(publishedPost.Title, post.title);

            // Delete Persistence File
            Assert.IsTrue(File.Exists(step.PersistenceFile));
            File.Delete(step.PersistenceFile);
        }

        [TestMethod]
        public void ShouldUpdatePostsContent()
        {
            // Create step
            PublishPresentationStep step = new PublishPresentationStep(MockMetaWeblogData.Url, MockMetaWeblogData.User, MockMetaWeblogData.Password, false);
            step.PostTemplateFile = "PublishPresentation\\PresentationPost.tt";

            // Publish original presentation
            step.PresentationXmlFile = "PublishPresentation\\Presentation.xml";            
            PublishedPost originalPublishedPost = step.Execute();

            // Re-Publish with updated presentation
            step.PresentationXmlFile = "PublishPresentation\\UpdatedPresentation.xml";
            step.PersistedPostsFile = step.PersistenceFile;            
            PublishedPost updatedPublishedPost = step.Execute();

            MetaWeblogHelper helper = new MetaWeblogHelper(MockMetaWeblogData.Url.ToString());
            
            Post post = helper.GetPost(updatedPublishedPost.PostId, MockMetaWeblogData.User, MockMetaWeblogData.Password);
            
            // Delete Post
            Assert.IsTrue(helper.DeletePost(String.Empty, updatedPublishedPost.PostId, MockMetaWeblogData.User, MockMetaWeblogData.Password, false));

            // Check that the same post has been updated
            Assert.AreEqual(originalPublishedPost.PostId, updatedPublishedPost.PostId);

            // Check the posted content
            Assert.IsTrue(post.description.Contains("This is the Updated Presentation Description"));

            // Delete Persistence File
            Assert.IsTrue(File.Exists(step.PersistenceFile));
            File.Delete(step.PersistenceFile);
        }
    }
}
