﻿namespace ContentFramework.Core.Tests
{
    using System;
    using System.IO;
    using ContentFramework.Core.Steps;
    using Microsoft.Practices.DocxConverter;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class ConvertDocumentStepFixture
    {
        private string LastCreatedDirectory
        {
            get;
            set;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA1806:DoNotIgnoreMethodResults", MessageId = "ContentFramework.Core.Steps.ConvertDocumentStep", Justification = "Creating of instance is needed to generate Exception"), TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ExecuteShouldThrowArgumentException()
        {
            new ConvertDocumentStep("Overview.docx.invalid", "Html");
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA1806:DoNotIgnoreMethodResults", MessageId = "ContentFramework.Core.Steps.ConvertDocumentStep", Justification = "Creating of instance is needed to generate Exception"), TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ExecuteShouldNotRecognizeConversionType()
        {
             new ConvertDocumentStep("Overview.docx", "WEBLOG");
        }

        [TestMethod]
        public void ExecuteConvertToDefaultFolder()
        {
            ConvertDocumentStep convertionStep = new ConvertDocumentStep("Overview.docx", "Html");

            convertionStep.Execute();
            string createdFile = "Overview.html\\html\\DocSet_default.html";
            Assert.IsTrue(File.Exists(createdFile), "Overview File was not converted");

            // Prepare to delete resources
            this.LastCreatedDirectory = Path.GetDirectoryName(createdFile);
        }

        [TestMethod]
        public void ShouldConvertDocumentWithoutDefault()
        {
            ConvertDocumentStep convertionStep = new ConvertDocumentStep("Topic.docx", "Html");

            convertionStep.Execute();

            string[] files = Directory.GetFiles("Topic.html\\html", "*.html");

            Assert.IsTrue(files.Length == 1);
            Assert.IsFalse(files[0].Contains("default"));
            
            // Prepare to delete resources
            this.LastCreatedDirectory = Path.GetDirectoryName(files[0]);
        }

        [TestMethod]
        public void ExecuteConvertToCustomFolder()
        {
            ConvertDocumentStep convertionStep = new ConvertDocumentStep("Overview.docx", "Html", "Custom");

            convertionStep.Execute();
            string createdFile = "Custom\\html\\DocSet_default.html";
            Assert.IsTrue(File.Exists(createdFile), "Overview File was not converted");

            // Prepare to delete resources
            this.LastCreatedDirectory = Path.GetDirectoryName(createdFile);
        }

        [TestMethod]
        public void ExecuteConvertDocInRelativePath()
        {
            ConvertDocumentStep convertionStep = new ConvertDocumentStep("Content\\Labs\\Test\\Docs\\Test.docx", "Html", "Custom");

            convertionStep.Execute();
            string createdFile = "Content\\Labs\\Test\\Docs\\Custom\\html\\DocSet_default.html";
            Assert.IsTrue(File.Exists(createdFile), "Test File was not converted");

            // Prepare to delete resources
            this.LastCreatedDirectory = Path.GetDirectoryName(createdFile);
        }

        [TestMethod]
        public void ExecuteConvertToDefaultFolderToMht()
        {
            ConvertDocumentStep convertionStep = new ConvertDocumentStep("Overview.docx", "Mht");

            convertionStep.Execute();

            string createdFile = "Overview.mht";
            Assert.IsTrue(File.Exists(createdFile), "Overview File was not converted");

            // Prepare to delete resources
            File.Delete(createdFile);
        }

        [TestMethod]
        public void ShouldConvertDocumentWithoutDefaultToMHT()
        {
            ConvertDocumentStep convertionStep = new ConvertDocumentStep("Topic.docx", "Mht");

            convertionStep.Execute();

            string createdFile = "Topic.mht";
            Assert.IsTrue(File.Exists(createdFile));

            // Prepare to delete resources
            File.Delete(createdFile);
        }

        [TestMethod]
        public void ExecuteConvertToCustomFolderToMHT()
        {
            ConvertDocumentStep convertionStep = new ConvertDocumentStep("Overview.docx", "Mht", "Custom");

            convertionStep.Execute();

            string createdFile = "Custom\\Overview.mht";
            Assert.IsTrue(File.Exists(createdFile), "Overview File was not converted");

            // Prepare to delete resources            
            File.Delete(createdFile);
        }

        [TestMethod]
        public void ExecuteConvertDocInRelativePathToMHT()
        {
            ConvertDocumentStep convertionStep = new ConvertDocumentStep("Content\\Labs\\Test\\Docs\\Test.docx", "Mht", "Custom");

            convertionStep.Execute();

            string createdFile = "Content\\Labs\\Test\\Docs\\Custom\\Test.mht";
            Assert.IsTrue(File.Exists(createdFile), "Test File was not converted");

            // Prepare to delete resources
            File.Delete(createdFile);
        }

        [TestMethod]
        [ExpectedException(typeof(SplitDocumentConverterException))]
        public void ShouldThowCustomExceptionConvertingLab()
        {
            ConvertDocumentStep convertionStep = new ConvertDocumentStep("Content\\Labs\\VS2010\\Lab.docx", "Html", "Custom");

            convertionStep.Execute();
            string createdFile = "Content\\Labs\\Test\\Docs\\Custom\\html\\DocSet_default.html";
            Assert.IsTrue(File.Exists(createdFile), "Overview File was not converted");

            // Prepare to delete resources
            // this.LastCreatedDirectory = Path.GetDirectoryName(createdFile);
        }

        [TestCleanup()]
        public void DeleteFolderCleanUp()
        {
            if (!String.IsNullOrEmpty(this.LastCreatedDirectory) && Directory.Exists(this.LastCreatedDirectory))
            {
                Directory.Delete(this.LastCreatedDirectory, true);
            }
        }
    }
}
