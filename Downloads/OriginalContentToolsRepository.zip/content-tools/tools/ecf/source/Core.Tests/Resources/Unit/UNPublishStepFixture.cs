﻿namespace ContentFramework.Core.Tests
{
    using System.IO;
    using System.Linq;
    using ContentFramework.Core.Helpers;
    using ContentFramework.Core.Providers;
    using ContentFramework.Core.Steps;
    using ContentFramework.Core.Tests.Mocks;
    using ContentFramework.Model;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class UnpublishStepFixture
    {
        private string PersistenceFile
        {
            get;
            set;
        }

        [TestCleanup]
        public void DeletePostsAndPersistence()
        {
            if (File.Exists(this.PersistenceFile))
            {
                // Unpublish Posts
                UnpublishStep unpublishStep = new UnpublishStep(this.PersistenceFile, MockMetaWeblogData.Password);
                unpublishStep.All = true;
                unpublishStep.Execute();

                // delete persistenceFile            
                File.Delete(this.PersistenceFile);
            }
        }

        [TestMethod]
        public void ShouldUnPublishPosts()
        {
            string labXmlFile = "ConvertedDocuments\\Lab\\Lab.xml";
            
            // publish some posts           
            MetadataHelper packageHelper = new MetadataHelper();
            Lab lab = packageHelper.ReadLab(labXmlFile);           
            
            PublishLabStep step = new PublishLabStep(MockMetaWeblogData.Url, MockMetaWeblogData.User, MockMetaWeblogData.Password, false);
            step.LabXmlFile = labXmlFile;
            step.PostTemplateFile = "PublishLab\\DocumentPost.tt";
            step.Execute();

            this.PersistenceFile = step.PersistenceFile;

            // Unpublish Posts
            UnpublishStep unpublishStep = new UnpublishStep(this.PersistenceFile, MockMetaWeblogData.Password);
            unpublishStep.Execute();

            IPublishedElementsDictionary persistedStuff = PublishPersistenceProviderFactory.Instance.GetPersistedElementPosts(this.PersistenceFile);
            Assert.AreEqual(0, persistedStuff[persistedStuff.Keys.First()].Count);
        }

        [TestMethod]
        public void ShouldUnPublishOnlyDraftPosts()
        {
            string labXmlFile = "ConvertedDocuments\\Lab\\Lab.xml";
            
            // publish some posts           
            MetadataHelper packageHelper = new MetadataHelper();
            Lab lab = packageHelper.ReadLab(labXmlFile);

            PublishLabStep step = new PublishLabStep(MockMetaWeblogData.Url, MockMetaWeblogData.User, MockMetaWeblogData.Password, true);
            step.LabXmlFile = labXmlFile;
            step.PostTemplateFile = "PublishLab\\DocumentPost.tt";
            step.Execute();

            this.PersistenceFile = step.PersistenceFile;

            // Mark some Posts as Draft
            var persitedPosts = PublishPersistenceProviderFactory.Instance.GetPersistedElementPosts(this.PersistenceFile);
            var key = new PublishedElementsDictionaryKey(lab);
            persitedPosts[key].First().Draft = true;
            int originalAmountOfPosts = persitedPosts[key].Count;
            PublishPersistenceProviderFactory.Instance.PersistElementPosts(this.PersistenceFile, lab, persitedPosts[key], MockMetaWeblogData.Url.ToString(), MockMetaWeblogData.User);

            // Unpublish Posts
            UnpublishStep unpublishStep = new UnpublishStep(this.PersistenceFile, MockMetaWeblogData.Password);
            unpublishStep.Execute();

            IPublishedElementsDictionary persistedStuff = PublishPersistenceProviderFactory.Instance.GetPersistedElementPosts(this.PersistenceFile);
            Assert.AreEqual(originalAmountOfPosts - 1, persistedStuff[key].Count);           
        }

        [TestMethod]
        public void ShouldUnPublishObsoletePosts()
        {
            string labXmlFile = "ConvertedDocuments\\Lab\\Lab.xml";

            // publish some posts           
            MetadataHelper packageHelper = new MetadataHelper();
            Lab lab = packageHelper.ReadLab(labXmlFile);

            PublishLabStep step = new PublishLabStep(MockMetaWeblogData.Url, MockMetaWeblogData.User, MockMetaWeblogData.Password, true);
            step.LabXmlFile = labXmlFile;
            step.PostTemplateFile = "PublishLab\\DocumentPost.tt";
            step.Execute();

            this.PersistenceFile = step.PersistenceFile;

            // Mark some Posts as Obsolete
            var persitedPosts = PublishPersistenceProviderFactory.Instance.GetPersistedElementPosts(this.PersistenceFile);
            var key = new PublishedElementsDictionaryKey(lab);
            persitedPosts[key].First().Obsolete = true;
            int originalAmountOfPosts = persitedPosts[key].Count;
            PublishPersistenceProviderFactory.Instance.PersistElementPosts(this.PersistenceFile, lab, persitedPosts[key], MockMetaWeblogData.Url.ToString(), MockMetaWeblogData.User);
            
            // Unpublish Posts
            UnpublishStep unpublishStep = new UnpublishStep(this.PersistenceFile, MockMetaWeblogData.Password);
            unpublishStep.ObsoletesOnly = true;
            unpublishStep.Execute();

            IPublishedElementsDictionary persistedStuff = PublishPersistenceProviderFactory.Instance.GetPersistedElementPosts(this.PersistenceFile);
            Assert.AreEqual(originalAmountOfPosts - 1, persistedStuff[key].Count);
        }
    }
}
