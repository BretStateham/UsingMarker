﻿namespace ContentFramework.Core.Tests
{
    using System;
    using System.Collections.Generic;
    using ContentFramework.Model;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class LinkedListExtensionsFixture
    {
        [TestMethod]
        public void ShouldGetNextNode()
        {
            string[] words = { "the", "fox", "jumped", "over", "the", "dog" };
            LinkedList<string> sentence = new LinkedList<string>(words);

            string firstWord = sentence.First.Value;

            string secondWord = sentence.Next(firstWord);

            Assert.AreEqual("fox", secondWord);
        }

        [TestMethod]
        public void ShouldGetFirstNode()
        {
            string[] words = { "the", "fox", "jumped", "over", "the", "dog" };
            LinkedList<string> sentence = new LinkedList<string>(words);

            string firstWord = sentence.First.Value;

            string previousWord = sentence.Previous(firstWord);

            Assert.AreEqual(firstWord, previousWord);
        }

        [TestMethod]
        public void ShouldGetPreviousNode()
        {
            string[] words = { "the", "fox", "jumped", "over", "the", "dog" };
            LinkedList<string> sentence = new LinkedList<string>(words);

            string lastWord = sentence.Last.Value;

            string previousWord = sentence.Previous(lastWord);

            Assert.AreEqual("the", previousWord);
        }

        [TestMethod]
        public void ShouldGetLastNode()
        {
            string[] words = { "the", "fox", "jumped", "over", "the", "dog" };
            LinkedList<string> sentence = new LinkedList<string>(words);

            string lastWord = sentence.Last.Value;

            string nextWord = sentence.Next(lastWord);

            Assert.AreEqual(lastWord, nextWord);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void ShouldFailNextNode()
        {
            string[] words = { "the", "fox", "jumped", "over", "the", "dog" };
            LinkedList<string> sentence = new LinkedList<string>(words);                      

            string secondWord = sentence.Next("dummy");           
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void ShouldFailPreviousNode()
        {
            string[] words = { "the", "fox", "jumped", "over", "the", "dog" };
            LinkedList<string> sentence = new LinkedList<string>(words);                      

            string secondWord = sentence.Previous("dummy");           
        }

        [TestMethod]        
        public void ShouldPopulateListFromCollection()
        {
            LinkedList<string> sentence = new LinkedList<string>();
            string[] words = { "the", "fox", "jumped", "over", "the", "dog" };

            sentence.AddRange(words);

            string firstWord = sentence.First.Value;
            string lastWord = sentence.Last.Value;

            Assert.AreEqual(words.Length, sentence.Count);
            Assert.AreEqual("the", firstWord);
            Assert.AreEqual("dog", lastWord);
        }   
    }
}
