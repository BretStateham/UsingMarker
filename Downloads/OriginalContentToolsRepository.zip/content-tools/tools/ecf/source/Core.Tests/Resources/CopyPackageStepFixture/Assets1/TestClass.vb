﻿Namespace TestNameSpace

    Public Class TestClass



    End Class
End Namespace


