﻿namespace ContentFramework.Core.Tests
{
    using System;
    using System.IO;
    using System.Linq;
    using ContentFramework.Core.Helpers;
    using ContentFramework.Core.Providers;
    using ContentFramework.Core.Steps;
    using ContentFramework.Core.Tests.Mocks;
    using ContentFramework.Model;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class MarkAsPublishedStepFixture
    {
        private PublishLabStep Step
        {
            get;
            set;
        }

        [TestCleanup]
        public void DeletePostsAndPersistenceFile()
        {
            if (File.Exists(this.Step.PersistenceFile))
            {
                // Unpublish Posts
                UnpublishStep unpublishStep = new UnpublishStep(this.Step.PersistenceFile, MockMetaWeblogData.Password);
                unpublishStep.All = true;
                unpublishStep.Execute();

                // Delete Persistence
                File.Delete(this.Step.PersistenceFile);
            }
        }

        [TestMethod]
        [Ignore]
        public void ShouldMarkPostsAsPublished()
        {
            string labXmlFile = "ConvertedDocuments\\Lab\\Lab.xml";            

            // publish some posts           
            MetadataHelper packageHelper = new MetadataHelper();
            Lab lab = packageHelper.ReadLab(labXmlFile);
            this.Step = new PublishLabStep(MockMetaWeblogData.Url, MockMetaWeblogData.User, MockMetaWeblogData.Password, false);
            this.Step.LabXmlFile = labXmlFile;
            this.Step.PostTemplateFile = "PublishLab\\DocumentPost.tt";
            this.Step.Execute();

            // change status
            DateTime validationDate = DateTime.Now;
            MarkAsPublishedStep changeStep = new MarkAsPublishedStep(this.Step.PersistenceFile, "palouse");

            changeStep.Execute();

            IPublishedElementsDictionary persistedStuff = PublishPersistenceProviderFactory.Instance.GetPersistedElementPosts(this.Step.PersistenceFile);
            var firstKey = persistedStuff.Keys.First();
            Assert.IsFalse(persistedStuff[firstKey].First().Draft);
            Assert.IsTrue(persistedStuff[firstKey].First().LastModified >= validationDate);
        }

        [TestMethod]
        public void ShouldNotChangeObsoletePosts()
        {
            string labXmlFile = "ConvertedDocuments\\Lab\\Lab.xml";

            // publish some posts           
            MetadataHelper packageHelper = new MetadataHelper();
            Lab lab = packageHelper.ReadLab(labXmlFile);
            this.Step = new PublishLabStep(MockMetaWeblogData.Url, MockMetaWeblogData.User, MockMetaWeblogData.Password, false);
            this.Step.LabXmlFile = labXmlFile;
            this.Step.PostTemplateFile = "PublishLab\\DocumentPost.tt";
            this.Step.Execute();

            // Mark some Posts as Obsolete
            var persitedPosts = PublishPersistenceProviderFactory.Instance.GetPersistedElementPosts(this.Step.PersistenceFile);
            var key = new PublishedElementsDictionaryKey(lab);
            persitedPosts[key][0].Obsolete = true;
            int originalAmountOfPosts = persitedPosts[key].Count;
            PublishPersistenceProviderFactory.Instance.PersistElementPosts(this.Step.PersistenceFile, lab, persitedPosts[key], MockMetaWeblogData.Url.ToString(), MockMetaWeblogData.User);
            
            // change status
            DateTime validationDate = DateTime.Now;
            MarkAsPublishedStep changeStep = new MarkAsPublishedStep(this.Step.PersistenceFile, "palouse", true);
            changeStep.Execute();

            persitedPosts = PublishPersistenceProviderFactory.Instance.GetPersistedElementPosts(this.Step.PersistenceFile);
            Assert.IsTrue(persitedPosts[key][0].Draft);
            Assert.IsFalse(persitedPosts[key][1].Draft);            
        }
    }
}
