﻿namespace Microsoft.Dpe.Ecf.Common
{
    using System;
    using System.Text;

    public class ContentFrameworkException : Exception
    {
        public ContentFrameworkException()
        {
        }

        public ContentFrameworkException(string message, string hint)
            : base(message)
        {
            this.Hint = hint;
        }

        public ContentFrameworkException(string message, Exception innerException, string hint)
            : base(message, innerException)
        {
            this.Hint = hint;
        }

        public ContentFrameworkException(Exception innerException, string hint)
            : base(string.Empty, innerException)
        {
            this.Hint = hint;
        }

        public string Hint 
        { 
            get;
            set;
        }

        public override string ToString()
        {
            var message = new StringBuilder();

            if (!string.IsNullOrEmpty(this.Message))
            {
                message.AppendLine(this.Message);
                message.AppendLine();
            }

            if (this.InnerException != null)
            {
                message.AppendLine("INNER EXCEPTION: ");
                message.AppendLine(this.InnerException.Message);
                message.AppendLine();
            }

            if (!string.IsNullOrEmpty(this.Hint))
            {
                message.AppendLine("HINT: ");
                message.AppendLine(this.Hint);
                message.AppendLine();
            }

            ////if (!string.IsNullOrEmpty(this.StackTrace))
            ////{
            ////    message.AppendLine("STACK TRACE: ");
            ////    message.AppendLine(this.StackTrace);
            ////    message.AppendLine();
            ////}
            ////else if (this.InnerException != null && !string.IsNullOrEmpty(this.InnerException.StackTrace))
            ////{
            ////    message.AppendLine("STACK TRACE: ");
            ////    message.AppendLine(this.InnerException.StackTrace);
            ////    message.AppendLine();
            ////}
            
            return message.ToString();
        }
    }
}
