﻿namespace Microsoft.Dpe.Ecf.Common
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Reflection;
    using System.Runtime.Remoting.Messaging;
    using System.Xml.Linq;
    using Microsoft.Dpe.Ecf.Common.Logging;

    public enum LogLevel
    {
        Off = 0,
        Error = 1,
        Warning = 2,
        Information = 3,
        Debug = 4
    }

    public static class Logger
    {
        private const string CurrentSource = "current_source"; 
        
        private static LogLevel loggerLevel;
        private static List<IListener> listeners;
        private static string configFileName = "contentFramework.config";
        private static string configFilePath = GetDefaultConfigFile();

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1810:InitializeReferenceTypeStaticFieldsInline", Justification = "Intentionally")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes", Justification = "Intentionally")]
        static Logger()
        {
            IndentLevel = 0;

            SetDefaultConfiguration();

            if (File.Exists(configFilePath))
            {
                try
                {
                    ReadConfiguration();
                }
                catch
                {
                    SetDefaultConfiguration();
                }                
            }
        }

        public static int IndentLevel 
        { 
            get; 
            set;
        }

        public static void Log(LogLevel level, string message)
        {
            if (loggerLevel >= level)
            {
                InternalLog(level, message, IndentLevel);
            }
        }

        public static void IncreaseIndent()
        {
            IndentLevel++;
        }

        public static void DecreaseIndent()
        {
            IndentLevel--;

            if (IndentLevel < 0)
            {
                IndentLevel = 0;
            }
        }

        public static void Log(LogLevel level, Exception exception)
        {
            if (loggerLevel >= level)
            {
                InternalLog(level, exception.ToString(), IndentLevel);
            }
        }      

        public static void Log(LogLevel level, Exception exception, string message)
        {
            if (loggerLevel >= level)
            {
                InternalLog(level, String.Concat(message, System.Environment.NewLine, exception.ToString()), IndentLevel);
            }
        }

        public static void SetCurrentSource(string source)
        {
            CallContext.SetData(CurrentSource, source);
            foreach (IListener listener in listeners)
            {
                listener.RegisterSource(source);
            }
        }

        public static void SetDefaultConfiguration(IListener listener)
        {
            Logger.SetDefaultConfiguration(new IListener[] { listener });
        }

        public static void SetDefaultConfiguration(IListener[] defaultListeners)
        {
            loggerLevel = LogLevel.Debug;

            listeners = new List<IListener>();

            foreach (var listener in defaultListeners)
            {
                listeners.Add(listener);
            }
        }

        private static string GetCurrentSource()
        {
            return CallContext.GetData(CurrentSource) as string;
        }

        private static void InternalLog(LogLevel level, string message, int indent)
        {
            var source = GetCurrentSource();
            foreach (IListener listener in listeners)
            {
                listener.Log(level, message, indent, source);
            }
        }

        private static void ReadConfiguration()
        {
            XDocument doc = XDocument.Load(configFilePath);

            loggerLevel = (LogLevel)Enum.Parse(typeof(LogLevel), doc.Descendants("logger").First().Attribute("level").Value, true);

            var configListeners = doc.Descendants("logger").First().Descendants("listener");

            listeners = new List<IListener>();

            foreach (var listener in configListeners)
            {
                IListener instance = Activator.CreateInstance(Type.GetType(listener.Attribute("type").Value)) as IListener;

                if (instance != null)
                {
                    listeners.Add(instance);
                }
            }
        }

        private static void SetDefaultConfiguration()
        {
            SetDefaultConfiguration(new IListener[] { new ConsoleListener(), new TraceListener() });
        }

        private static string GetDefaultConfigFile()
        {
            return Path.GetFullPath(Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), configFileName));
        }
    }
}
