﻿namespace Microsoft.Dpe.Ecf.Common.Logging
{
    using System;

    public class ConsoleListener : IListener
    {
        public ConsoleListener()
        {            
        }

        public void RegisterSource(string source)
        {
        }

        public void Log(LogLevel level, string message, int indent, string source)
        {
            if (!string.IsNullOrEmpty(source))
            {
                message = string.Concat("[", source, "]", message);
            }

            this.Log(level, message, indent);
        }

        public void Log(LogLevel level, string message, int indent)
        {
            // Console listener only shows: Error, Warning and Information
            switch (level)
            {
                case LogLevel.Error:
                    LogError(message);
                    break;
                case LogLevel.Warning:
                    LogWarning(message);
                    break;
                case LogLevel.Information:
                    Console.WriteLine(message);
                    break;
            }
        }

        private static void LogError(string message)
        {
            ConsoleColor currentForegroundColor = Console.ForegroundColor;
            ConsoleColor currentBackgroundColor = Console.BackgroundColor;
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("Logging Exception...");
            Console.ForegroundColor = ConsoleColor.Red;

            Console.WriteLine(message);
            Console.WriteLine();

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("End Logging Exception.");
            Console.WriteLine();
            Console.ForegroundColor = currentForegroundColor;
            Console.BackgroundColor = currentBackgroundColor;
        }

        private static void LogWarning(string message)
        {
            ConsoleColor currentForegroundColor = Console.ForegroundColor;
            ConsoleColor currentBackgroundColor = Console.BackgroundColor;
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("WARNING: " + message);
            Console.ForegroundColor = currentForegroundColor;
            Console.BackgroundColor = currentBackgroundColor;
        }
    }
}
