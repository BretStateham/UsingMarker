﻿namespace Microsoft.Dpe.Ecf.Common.Logging
{
    using System;
    using System.Globalization;
    using System.Text;

    public class TraceListener : IListener
    {
        public void Log(LogLevel level, string message, int indent)
        {
            this.Log(level, message, indent, string.Empty);
        }

        public void Log(LogLevel level, string message, int indent, string source)
        {
            switch (level)
            {
                case LogLevel.Error:
                    LogError(message, indent, source);
                    break;
                case LogLevel.Warning:
                    LogWarning(message, indent, source);
                    break;
                case LogLevel.Information:
                case LogLevel.Debug:
                    LogMessage(message, indent, source);
                    break;
            }   
        }

        public void RegisterSource(string source)
        {
        }

        private static void LogMessage(string message, int indent, string source)
        {
            StringBuilder messageToLog = new StringBuilder();
            string tabs = new string(' ', indent * 2);

            messageToLog.Append(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff", CultureInfo.InvariantCulture) + ": ");
            messageToLog.Append(tabs);
            messageToLog.Append(message.Replace(Environment.NewLine, Environment.NewLine + tabs + "\t"));

            if (string.IsNullOrEmpty(source))
            {
                TraceUtility.Log(System.Diagnostics.TraceEventType.Information, messageToLog.ToString());
            }
            else
            {
                TraceUtility.Log(System.Diagnostics.TraceEventType.Information, source, messageToLog.ToString());
            }
        }

        private static void LogError(string message, int indent, string source)
        {
            StringBuilder messageToLog = new StringBuilder();
            string tabs = new string(' ', indent * 2);

            messageToLog.Append(tabs);
            messageToLog.AppendLine();
            messageToLog.AppendLine(DateTime.Now.ToString() + ": " + tabs + "--------------------- Logging Exception ---------------------");
            messageToLog.Append(DateTime.Now.ToString() + ": " + tabs);
            messageToLog.AppendLine(message.Replace(Environment.NewLine, Environment.NewLine + tabs + "\t"));
            messageToLog.AppendLine(DateTime.Now.ToString() + ": " + tabs + "------------------- End Logging Exception -------------------");
            messageToLog.AppendLine();

            if (string.IsNullOrEmpty(source))
            {
                TraceUtility.Log(System.Diagnostics.TraceEventType.Error, messageToLog.ToString());
            }
            else
            {
                TraceUtility.Log(System.Diagnostics.TraceEventType.Error, source, messageToLog.ToString());
            }
        }

        private static void LogWarning(string message, int indent, string source)
        {
            StringBuilder messageToLog = new StringBuilder();
            string tabs = new string(' ', indent * 2);

            messageToLog.Append(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff", CultureInfo.InvariantCulture) + ": ");
            messageToLog.Append(tabs);
            messageToLog.Append(message.Replace(Environment.NewLine, Environment.NewLine + tabs + "\t"));

            if (string.IsNullOrEmpty(source))
            {
                TraceUtility.Log(System.Diagnostics.TraceEventType.Warning, messageToLog.ToString());
            }
            else
            {
                TraceUtility.Log(System.Diagnostics.TraceEventType.Warning, source, messageToLog.ToString());
            }
        }
    }
}
