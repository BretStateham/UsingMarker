﻿namespace Microsoft.Dpe.Ecf.Common.Logging
{
    public interface IListener
    {
        void Log(LogLevel level, string message, int indent);

        void Log(LogLevel level, string message, int indent, string source);

        void RegisterSource(string source);
    }
}
