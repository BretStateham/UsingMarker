﻿namespace Microsoft.Dpe.Ecf.Common.Logging
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Globalization;
    using System.IO;
    using System.Reflection;
    using System.Text;

    public class FileListener : IListener
    {
        private static string logFileName = "log.txt";
        private static string logFilePath = GetDefaultLogFilePath();
        private static Dictionary<string, string> logFiles = new Dictionary<string, string>();

        public FileListener()
        {            
        }

        public void RegisterSource(string source)
        {
            logFiles[source] = string.Concat(source, "-", logFileName);
        }

        public void Log(LogLevel level, string message, int indent, string source)
        {
            switch (level)
            {
                case LogLevel.Error:
                    LogError(message, indent, source);
                    break;
                case LogLevel.Warning:
                    LogMessage("WARNING: " + message, indent, source);
                    break;
                case LogLevel.Information:
                case LogLevel.Debug:
                    LogMessage(message, indent, source);
                    break;
            }            
        }

        public void Log(LogLevel level, string message, int indent)
        {
            this.Log(level, message, indent, string.Empty);
        }

        private static string GetDefaultLogFilePath()
        {
            return Path.GetFullPath(logFileName);
        }

        private static string GetLogFilePath(string source)
        {
            if (string.IsNullOrEmpty(source) || !logFiles.ContainsKey(source))
            {
                return GetDefaultLogFilePath();
            }

            return Path.GetFullPath(logFiles[source]);
        }

        private static void LogMessage(string message, int indent, string source)
        {
            StringBuilder messageToLog = new StringBuilder();
            string tabs = new string(' ', indent * 2);

            messageToLog.Append(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff", CultureInfo.InvariantCulture) + ": ");
            messageToLog.Append(tabs);
            messageToLog.Append(message.Replace(Environment.NewLine, Environment.NewLine + tabs + "\t"));

            using (StreamWriter file = GetStream(source))
            {
                file.WriteLine(messageToLog.ToString());
            }
        }

        private static void LogError(string message, int indent, string source)
        {
            StringBuilder messageToLog = new StringBuilder();
            string tabs = new string(' ', indent * 2);

            messageToLog.Append(new string(' ', indent * 2));
            messageToLog.AppendLine();
            messageToLog.AppendLine(DateTime.Now.ToString() + ": " + tabs + "--------------------- Logging Exception ---------------------");
            messageToLog.Append(DateTime.Now.ToString() + ": " + tabs);
            messageToLog.AppendLine(message.Replace(Environment.NewLine, Environment.NewLine + tabs + "\t"));
            messageToLog.AppendLine(DateTime.Now.ToString() + ": " + tabs + "------------------- End Logging Exception -------------------");
            messageToLog.AppendLine();

            using (StreamWriter file = GetStream(source))
            {
                file.WriteLine(messageToLog.ToString());
            }          
        }

        private static StreamWriter GetStream(string source)
        {
            bool includeHeader = !File.Exists(GetLogFilePath(source));

            StreamWriter file = new StreamWriter(GetLogFilePath(source), true);

            if (includeHeader)
            {
                var asm = Assembly.GetExecutingAssembly();
                var asmVer = asm.GetName().Version.ToString();
                var fvi = FileVersionInfo.GetVersionInfo(asm.Location);
                var fileVer = fvi.ProductVersion;

                file.WriteLine("ECF Version: " + asmVer);
                file.WriteLine("ECF File Version: " + fileVer);
                file.WriteLine();
            }

            return file;
        }
    }
}
