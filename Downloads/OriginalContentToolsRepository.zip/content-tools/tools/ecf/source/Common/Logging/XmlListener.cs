﻿namespace Microsoft.Dpe.Ecf.Common.Logging
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Globalization;
    using System.IO;
    using System.Reflection;
    using System.Text;
    using System.Xml;

    public class XmlListener : IListener
    {
        private static string logFileName = "log.xml";
        private static string logFilePath = GetDefaultLogFilePath();
        private static Dictionary<string, string> logFiles = new Dictionary<string, string>();

        public XmlListener()
        {
        }

        public void RegisterSource(string source)
        {
            logFiles[source] = string.Concat(source, "-", logFileName);
        }

        public void Log(LogLevel level, string message, int indent)
        {
            this.Log(level, message, indent, string.Empty);
        }

        public void Log(LogLevel level, string message, int indent, string source) 
        {
            if (!File.Exists(GetLogFilePath(source)))
            {
                CreateLogFile(GetLogFilePath(source));
            }

            XmlDocument doc = new XmlDocument();
            doc.Load(GetLogFilePath(source));
            
            XmlElement logEl = (XmlElement)doc.SelectSingleNode("//Log");
            XmlElement entryEl = doc.CreateElement("Entry");
            XmlElement dateEl = doc.CreateElement("Date");
            XmlElement levelEl = doc.CreateElement("Level");
            XmlElement indentEl = doc.CreateElement("Indent");
            XmlElement msgEl = doc.CreateElement("Message");
            
            dateEl.InnerText = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff", CultureInfo.InvariantCulture);
            levelEl.InnerText = level.ToString();
            indentEl.InnerText = indent.ToString(CultureInfo.InvariantCulture);
            msgEl.InnerText = message.Trim();
            
            entryEl.AppendChild(dateEl);
            entryEl.AppendChild(levelEl);
            entryEl.AppendChild(indentEl);
            entryEl.AppendChild(msgEl);

            logEl.AppendChild(entryEl);

            doc.Save(GetLogFilePath(source));
        }

        private static string GetDefaultLogFilePath()
        {
            return Path.GetFullPath(logFileName);
        }

        private static string GetLogFilePath(string source)
        {
            if (string.IsNullOrEmpty(source) || !logFiles.ContainsKey(source))
            {
                return GetDefaultLogFilePath();
            }

            return Path.GetFullPath(logFiles[source]);
        }

        private static void CreateLogFile(string path)
        {
            string xslPath = Environment.ExpandEnvironmentVariables("%ECF%\\resources\\Logging\\Log.xsl");
            XmlWriter writer = new XmlTextWriter(path, Encoding.UTF8);
            writer.WriteProcessingInstruction("xml", "version='1.0' encoding='UTF-8'");
            writer.WriteProcessingInstruction("xml-stylesheet", "type=\"text/xsl\" href=\"" + xslPath + "\"");

            //// writer.WriteComment(" saved from url=(0014)about:internet ");
            //// <!-- saved from url=(0014)about:internet -->
            writer.WriteStartElement("Log");

            var asm = Assembly.GetExecutingAssembly();
            var asmVer = asm.GetName().Version.ToString();
            var fvi = FileVersionInfo.GetVersionInfo(asm.Location);
            var fileVer = fvi.ProductVersion;

            writer.WriteAttributeString("Version", asmVer);
            writer.WriteAttributeString("FileVersion", fileVer);
            writer.WriteEndElement();
            writer.Flush();
            writer.Close();
        }
    }
}
