﻿namespace Microsoft.Dpe.Ecf.Common.Logging
{
    using System;
    using System.Diagnostics;
    using System.Globalization;
    using Microsoft.Dpe.Ecf.Common.Properties;

    public static class TraceUtility
    {
            public const string TraceSourceName = "ContentFramework.Common.Logging";
            private static TraceSource traceSource = new TraceSource(TraceSourceName);

            internal static void Verbose(string label, string message)
            {
                Log(TraceEventType.Verbose, label, message);
            }

            internal static void Verbose(string format, params object[] args)
            {
                Log(TraceEventType.Verbose, string.Format(CultureInfo.CurrentCulture, format, args));
            }

            internal static void Verbose(string label, string format, params object[] args)
            {
                Verbose(label, string.Format(CultureInfo.CurrentCulture, format, args));
            }

            internal static void Info(string label, string message)
            {
                Log(TraceEventType.Information, label, message);
            }

            internal static void Info(string label, string format, params object[] args)
            {
                Info(label, string.Format(CultureInfo.CurrentCulture, format, args));
            }

            internal static void Warning(string label, string message)
            {
                Log(TraceEventType.Warning, label, message);
            }

            internal static void Warning(string label, string format, params object[] args)
            {
                Warning(label, string.Format(CultureInfo.CurrentCulture, format, args));
            }

            internal static void Error(string label, Exception ex)
            {
                Log(TraceEventType.Error, label, string.Format(CultureInfo.CurrentCulture, Resources.ExceptionLogTemplate, ex.GetType().ToString(), ex.ToString()));
            }

            internal static void Fatal(string label, Exception ex)
            {
                Log(TraceEventType.Critical, label, string.Format(CultureInfo.CurrentCulture, Resources.ExceptionLogTemplate, ex.GetType().ToString(), ex.ToString()));
            }

            internal static void Log(TraceEventType type, string label, string message)
            {
                traceSource.TraceData(type, 0, label, message);
            }

            internal static void Log(TraceEventType type, string label, string format, params object[] args)
            {
                Log(type, label, string.Format(CultureInfo.CurrentCulture, format, args));
            }

            internal static void Log(TraceEventType type, string message)
            {
                traceSource.TraceEvent(type, 0, message);
            }

            internal static void Log(TraceEventType type, string format, params object[] args)
            {
                Log(type, string.Format(CultureInfo.CurrentCulture, format, args));
            }
        }
}
