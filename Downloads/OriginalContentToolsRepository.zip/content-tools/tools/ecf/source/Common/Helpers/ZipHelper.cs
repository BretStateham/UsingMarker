﻿namespace Microsoft.Dpe.Ecf.Common.Helpers
{
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using Ionic.Zip;

    public static class ZipHelper
    {
        public static void ZipFolder(string folderToZip, string zipFileName)
        {
            using (ZipFile zip = new ZipFile(zipFileName))
            {
                zip.AddDirectory(folderToZip);

                zip.UseZip64WhenSaving = Zip64Option.AsNecessary;
                zip.Save();
            }
        }

        public static void ZipFolder(string folderToZip, string zipFileName, string[] excludes)
        {
            var filesToZip = GetFilesToZip(folderToZip, excludes);

            using (ZipFile zip = new ZipFile(zipFileName))
            {
                foreach (string file in filesToZip)
                {
                    string basePath = Path.GetFullPath(folderToZip);
                    string fileDirectoryPath = Path.GetFullPath(Path.GetDirectoryName(file));

                    string relativePath = string.Empty;
                    if (fileDirectoryPath.Length > basePath.Length)
                    {
                        relativePath = fileDirectoryPath.Substring(basePath.Length + 1);
                    }

                    zip.AddFile(file, relativePath);
                }

                zip.UseZip64WhenSaving = Zip64Option.AsNecessary;
                zip.Save();
            }
        }

        public static void ZipFile(string fileToZip, string zipFileName)
        {
            using (ZipFile zip = new ZipFile(zipFileName))
            {
                zip.AddFile(fileToZip);

                zip.UseZip64WhenSaving = Zip64Option.AsNecessary;
                zip.Save();
            }
        }

        public static void ZipFile(string fileToZip, string zipFileName, string relativePath)
        {
            using (ZipFile zip = new ZipFile(zipFileName))
            {
                zip.AddFile(fileToZip, relativePath);

                zip.UseZip64WhenSaving = Zip64Option.AsNecessary;
                zip.Save();
            }
        }

        public static void Unzip(string fileToUnzip, string targetDirectory)
        {
            using (ZipFile zip = Ionic.Zip.ZipFile.Read(fileToUnzip))
            {
                foreach (ZipEntry e in zip)
                {
                    e.Extract(targetDirectory);
                }
            }
        }

        private static IEnumerable<string> GetFilesToZip(string folderToZip, string[] excludes)
        {
            var filesAndFolders = DirectoryHelper.GetFileSystemEntriesFiltered(folderToZip, excludes)
                .Where(f => !Directory.Exists(f));

            return filesAndFolders;
        }
    }
}