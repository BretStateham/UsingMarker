﻿namespace Microsoft.Dpe.Ecf.Common.Helpers
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text.RegularExpressions;

    public static class DirectoryHelper
    {
        public static void CopyDirectory(string sourceDirectory, string destinationDirectory)
        {
            DirectoryHelper.CopyDirectory(sourceDirectory, destinationDirectory, null);
        }

        public static void CopyDirectory(string sourceDirectory, string destinationDirectory, string[] excludePatterns)
        {
            CopyDirectory(sourceDirectory, destinationDirectory, excludePatterns, null);
        }

        public static void CopyDirectory(string sourceDirectory, string destinationDirectory, string[] excludePatterns, string[] excludePaths)
        {
            Logger.Log(LogLevel.Debug, string.Format("Copy Directory from {0} to {1}", sourceDirectory, destinationDirectory));

            if (excludePatterns != null && excludePatterns.Length > 0)
            {
                Logger.Log(LogLevel.Debug, "Exclude Patterns:");
                Logger.IncreaseIndent();

                foreach (string excludePattern in excludePatterns)
                {
                    Logger.Log(LogLevel.Debug, excludePattern);
                }

                Logger.DecreaseIndent();
            }

            if (excludePaths != null && excludePaths.Length > 0)
            {
                Logger.Log(LogLevel.Debug, "Exclude Paths:");
                Logger.IncreaseIndent();

                foreach (string excludePath in excludePaths)
                {
                    Logger.Log(LogLevel.Debug, excludePath);
                }

                Logger.DecreaseIndent();
            }

            CheckPathTooLong(sourceDirectory);
            CheckPathTooLong(destinationDirectory);

            if (String.IsNullOrEmpty(sourceDirectory) || !Directory.Exists(sourceDirectory))
            {
                throw new ArgumentException("Source Directory was not found.");
            }

            if (String.IsNullOrEmpty(destinationDirectory))
            {
                throw new ArgumentException("Destination directory can not be empty.");
            }

            if (!Directory.Exists(destinationDirectory))
            {
                Logger.Log(LogLevel.Debug, string.Format("Creating Directory: {0}", destinationDirectory));
                Directory.CreateDirectory(destinationDirectory);
            }

            Logger.IncreaseIndent();

            foreach (string entry in DirectoryHelper.GetFileSystemEntriesFiltered(sourceDirectory, excludePatterns, SearchOption.TopDirectoryOnly))
            {
                var resolvedEntry = DirectoryHelper.ResolveRelativePaths(entry);
                CheckPathTooLong(resolvedEntry);

                if (excludePaths == null
                    || !excludePaths.Any(path => Path.GetFullPath(path).Equals(Path.GetFullPath(resolvedEntry), StringComparison.InvariantCultureIgnoreCase)))
                {
                    if (Directory.Exists(resolvedEntry))
                    {
                        var destDir = Path.Combine(destinationDirectory, Path.GetFileName(resolvedEntry));
                        CheckPathTooLong(destDir);

                        DirectoryHelper.CopyDirectory(resolvedEntry, destDir, excludePatterns);
                    }
                    else
                    {
                        string filePath = Path.Combine(destinationDirectory, Path.GetFileName(resolvedEntry));

                        CopyFile(resolvedEntry, filePath, true);
                    }
                }
            }

            Logger.DecreaseIndent();
        }

        public static void CopyFile(string sourceFile, string targetFile, bool clearReadOnly)
        {
            sourceFile = ResolveRelativePaths(sourceFile);
            targetFile = ResolveRelativePaths(targetFile);
            CheckPathTooLong(sourceFile);
            CheckPathTooLong(targetFile);

            Logger.Log(LogLevel.Debug, string.Format("Copy File from {0} to {1}", sourceFile, targetFile));
            Logger.Log(LogLevel.Debug, string.Format("Clear Read Only: {0}", clearReadOnly));

            File.Copy(sourceFile, targetFile, true);

            if (clearReadOnly)
            {
                FileAttributes atts = File.GetAttributes(targetFile);
                atts &= ~FileAttributes.ReadOnly;
                File.SetAttributes(targetFile, atts);
            }
        }

        public static string ResolveRelativePaths(string sourceFile)
        {
            Uri path = new Uri(sourceFile, UriKind.RelativeOrAbsolute);

            if (path.IsAbsoluteUri)
            {
                return path.LocalPath;
            }
            else
            {
                return ResolveNonRootedRelativePaths(sourceFile);
            }
        }

        public static string[] GetFileSystemEntriesFiltered(string sourceDirectory, string[] excludes, SearchOption searchOption = SearchOption.AllDirectories)
        {
            CheckPathTooLong(sourceDirectory);

            IEnumerable<string> filesAndFolders = Directory.GetDirectories(sourceDirectory, "*.*", searchOption)
                .Concat(Directory.GetFiles(sourceDirectory, "*.*", searchOption));

            if (excludes != null)
            {
                var sourceDirectoryFullPathLength = Path.GetFullPath(sourceDirectory).Length;
                var filesToExclude = filesAndFolders.Where(
                    f => excludes.Any(
                        pattern =>
                        {
                            // Remove the leading source directory from the path
                            return f.Substring(sourceDirectoryFullPathLength)
                                .MatchMask(pattern);
                        }));

                filesAndFolders = filesAndFolders.Where(
                    f => !filesToExclude.Any(
                        fte => f.Equals(fte, StringComparison.OrdinalIgnoreCase)));
            }

            return filesAndFolders.ToArray();
        }

        public static string RemoveInvalidPathChars(string path)
        {
            string ret = path;
            foreach (char invalidChar in Path.GetInvalidFileNameChars())
            {
                if (invalidChar != '*' && invalidChar != '?')
                {
                    ret = ret.Replace(invalidChar.ToString(), String.Empty);
                }
            }

            return ret;
        }

        public static string RemoveInvalidFileNameCharacters(string fileName)
        {
            string validFileName = fileName;

            foreach (char validFileChar in Path.GetInvalidFileNameChars())
            {
                validFileName = validFileName.Replace(validFileChar.ToString(), String.Empty);
            }

            if (validFileName.StartsWith(".", StringComparison.OrdinalIgnoreCase))
            {
                validFileName = validFileName.Remove(0, 1);
            }

            return validFileName;
        }

        public static void CheckPathTooLong(string path)
        {
            if (string.IsNullOrEmpty(path))
            {
                return;
            }

            try
            {
                var fullPath = Path.GetFullPath(path);

                if (fullPath.Length > 260)
                {
                    throw new PathTooLongException();
                }
            }
            catch (PathTooLongException)
            {
                throw new ContentFrameworkException("Path too long: " + path, "Use a smaller folder structure or create a symbolic link to the root folder of the package (i. e. MKLINK /D C:\\tk C:\\TFS\\PlatformEvangelism\\Content)");
            }
        }

        private static bool MatchMask(this string fileName, string fileMask)
        {
            // 1. ^: beggining of the string
            // 2. \\?: one or zero backslashes
            // 3. Escape backslashes in string (masks like *\.svn\* to exclude .svn folders)
            // 4. Escape periods in masks like *.xml => *[.]xml
            // 5. Replace star with period (any character allowed) and star (zero or more occurrences)
            // 6. Replace question mark with period (any character allowed once)
            // 7. $: the end of the string (this is to avoid matching *.xml on test.xml.html <- wrong match)
            Regex mask = new Regex(
                "^\\\\?" + fileMask.Replace("\\", "\\\\").Replace(".", "[.]").Replace("*", ".*").Replace("?", ".") + "$");
            return mask.IsMatch(fileName);
        }

        private static string ResolveNonRootedRelativePaths(string sourceFile)
        {
            var path = sourceFile.Replace("\\.\\", "\\");

            while (path.LastIndexOf("..\\") > 0)
            {
                path = Regex.Replace(path, @"([^\\.+]+\\\.\.\\)", string.Empty);
            }

            return path.Replace("..\\", string.Empty).Replace(".\\", string.Empty);
        }
    }
}