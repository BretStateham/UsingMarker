﻿namespace Microsoft.Dpe.Ecf.Common.Helpers
{
    using System.Collections.Generic;
    using System.IO;

    public class RecursiveSearchHelper
    {
        private List<string> fileList;
        private List<string> excludeList;

        public RecursiveSearchHelper()
        {
            this.fileList = new List<string>();
            this.excludeList = new List<string>();
        }

        public string[] GetFiles(string initialDirectory, string filePattern)
        {
            this.fileList.Clear();

            this.Search(initialDirectory, filePattern);

            return this.fileList.ToArray();
        }

        public string[] GetFiles(string initialDirectory, string[] filePatterns, string[] excludePatterns)
        {
            this.fileList.Clear();
            this.excludeList.Clear();

            foreach (string filePattern in filePatterns)
            {
                this.Search(initialDirectory, filePattern);
            }

            if (excludePatterns != null)
            {
                foreach (string excludePattern in excludePatterns)
                {
                    this.SearchExclude(initialDirectory, excludePattern);
                }
            }

            foreach (var file in this.excludeList)
            {
                this.fileList.RemoveAll(delegate(string s)
                {
                    return s == file;
                });
            }

            return this.fileList.ToArray();
        }

        private void Search(string initialDirectory, string filePattern)
        {
            foreach (string file in Directory.GetFiles(initialDirectory, filePattern))
            {
                if (!this.fileList.Contains(file))
                {
                    this.fileList.Add(file);
                }
            }

            if (!(Directory.GetDirectories(initialDirectory) == null))
            {
                foreach (string item in Directory.GetDirectories(initialDirectory))
                {
                    this.Search(item, filePattern);
                }
            }
        }

        private void SearchExclude(string initialDirectory, string excludePattern)
        {
            foreach (string file in Directory.GetFiles(initialDirectory, excludePattern))
            {
                if (!this.excludeList.Contains(file))
                {
                    this.excludeList.Add(file);
                }
            }

            if (!(Directory.GetDirectories(initialDirectory) == null))
            {
                foreach (string item in Directory.GetDirectories(initialDirectory))
                {
                    this.SearchExclude(item, excludePattern);
                }
            }
        }
    }
}
