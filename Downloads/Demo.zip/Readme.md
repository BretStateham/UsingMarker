﻿<a name="Title" />
# Demo Title #
---

<a name="Overview" />
## Overview ##

In this demo we will cover....

---

<a name="Setup" />
## Setup and Prerequisites ##

To successfully complete this demo you need:

- This thing
- That thing
- The other thing

---

<a name="Tasks" />
## Tasks ##

This demo is comprised of the following tasks:

- [Task 1](#Task1)
- [Task 2](#Task2) 
- [Task 3](#Task3)

--- 

<a name="Task1" />
## Task 1 ##

In this task we'll......

1. Do **This** using this code:

````C#
void Main() {
	int x = 1;
	int y = 2;
	int z = x + y;
	Console.WriteLine(z);
}
````
1. Do _That_ - I try to keep my screen shots to no bigger than 1024x768.  That is still bigger than what the Marker tool recommends, but it has worked well for me previously.  

	![01010demoimage](images/01010demoimage.png?raw=true "Demo Image")

1. Do ***The Other Thing***

	> **Note:** This is a note

--- 

<a name="Task2" />
## Task 2 ##


In this task we'll......

1. One

1. Two 

1. Three

--- 

<a name="Task3" />
## Task 3 ##


In this task we'll......

1. One

1. Two

1. Three

---

<a name="Summary" />
## Summary ##

In this demo we completed the following tasks:

- [Task 1](#Task1)
- [Task 2](#Task2) 
- [Task 3](#Task3)

